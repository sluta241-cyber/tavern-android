# Custom rules integration checks (v4.5.0)

## Implemented integration
- The existing campaign creation fields and labels are unchanged.
- `CustomRuleEngine` consolidates campaign rules, race mechanics, class mechanics, character level, and the selected content mode into one prompt block.
- The online and offline master prompts receive this block and an explicit priority order: campaign-specific rules first, D&D 5e 2014 second, clearly-labelled temporary ruling third.
- The action resolver uses explicit numeric DC overrides from `customRules` when the text clearly associates a DC with a check (e.g. `СЛ скрытности 17`, `СЛ для убеждения: 9`). Otherwise it retains its existing suggested DC.
- The content-mode selector and its strings are protected and unchanged.

## Smoke tests executed
- `СЛ скрытности 17` overrides the default stealth DC.
- `СЛ для убеждения: 9` overrides the default persuasion DC.
- An unrelated check does not inherit the persuasion DC.
- `ActionResolutionEngine` exposes the overridden DC for a stealth action.

## Boundaries
Free-text house rules are not all converted into executable mechanics automatically. Only unambiguous numeric DC forms are parsed mechanically; other custom rules and race/class features are supplied to the master as authoritative instructions. Arbitrary combat changes (for example custom critical ranges, spell costs, or damage formulas) still need explicit structured fields and tests before they can safely alter the combat engine.
