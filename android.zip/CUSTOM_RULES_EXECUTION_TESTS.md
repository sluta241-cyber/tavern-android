# Custom Rules Execution Tests — v47

## Executable non-combat checks
- `ActionResolutionEngine.executeCheck` resolves only explicit, classified checks.
- `Dnd5eRules.checkWithMode` rolls one d20 normally and two d20 for advantage/disadvantage, choosing the higher/lower respectively.
- The selected die plus ability modifier and proficiency bonus (when the skill is listed in `Campaign.skills`) is compared to the effective DC. Ability checks do not treat natural 1/20 as automatic failure/success.
- The offline master prints the actual roll and uses failed social checks to avoid granting the default trust increase.
- Unknown/custom prose remains prompt context and does not directly mutate character/world state.

## Manual regression cases
1. `пытаюсь убедить стражника` -> one roll; output shows total, DC and success/failure.
2. Rule `преимущество на проверку скрытности`, action `крадусь незаметно` -> two d20, higher selected.
3. Rule `помеха на проверку убеждения`, action `пытаюсь убедить стражника` -> two d20, lower selected.
4. Rule `СЛ скрытности 17`, action `крадусь незаметно` -> target DC 17.
5. A failed persuasion check must not grant the default trust increase.
6. `я не атакую, а предлагаю сделку` -> no combat attack is triggered.
7. An unclassified sentence -> no check is rolled.

## Scope limitations
This does not yet implement arbitrary natural-language abilities as effects, concentration, spell slots, or every D&D 5e action. The roll path covers classified non-combat checks. Full Android build/device tests remain separate.
