# Tavern v5.3.0 — Narrative logic audit

## Issues visible in the supplied screenshot
1. Player's peace statement did not receive a direct, believable response from the NPCs.
2. “Get ready for battle” was treated as generic atmosphere instead of a threat/declaration whose target and consequences must be clear.
3. The model emitted a raw world-state/debug block in normal narrative, breaking immersion.
4. The answer used generic sensory filler rather than advancing the current interaction.

## Changes
- Added deterministic `NarrativeTurnDirector` and integrated its per-turn contract into the online system prompt.
- Explicitly distinguish de-escalation, negotiation, threat/declaration, attack, question, observation, and unknown action.
- Clarify that threat/declaration is not automatically an attack and that de-escalation cannot trigger combat by itself.
- Require direct response to the player's words, a concrete NPC reaction grounded in known goals/state, and no raw world-state block unless requested.
- Disallow random catastrophe/filler event unless grounded in established scene state.
- Reduced online temperature to 0.62.

## Verification
- Narrative turn director: 5 smoke checks passed.
- NPC knowledge extractor: 14 smoke checks passed.
- Structural audit: 0 failures across 65 checks/notes.
- Relationship runner did not finish within the allotted command timeout; not counted as passed.
- Full Gradle build/APK and device test were not performed. Gradle wrapper script/JAR are absent.
- `modeBlock` exact source text remains unchanged.

## Remaining limitations
This is a prompt-and-deterministic-classification improvement, not a guarantee of high-quality prose across all LLMs. It applies to the online model path; offline mode remains template/heuristic-driven and needs a separate narrative rewrite. The model can still ignore instructions, and no post-generation semantic validator yet rejects off-contract replies.
