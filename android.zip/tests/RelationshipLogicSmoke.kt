import com.tavern.dnd.Campaign
import com.tavern.dnd.NpcRelationshipEngine

fun main() {
    val c = Campaign(id = "test", title = "test", worldName = "test", heroName = "hero", lastNpc = "трактирщик Борис")
    check(NpcRelationshipEngine.resolveMentionedNpc(c, "Я рассказал Борису, что дракон здесь.", "Борис кивает.") == "трактирщик Борис") {
        "Inflected active NPC name should resolve"
    }
    check(NpcRelationshipEngine.resolveMentionedNpc(c, "Я помог ребёнку.", "Марта улыбается.") == null) {
        "A non-active NPC mentioned only by generated narration must not receive relationship changes"
    }
    check(NpcRelationshipEngine.resolveMentionedNpc(c, "Я помог ему.", "Борис кивает.") == "трактирщик Борис") {
        "Active NPC may be resolved from its own reply when player uses a pronoun"
    }
    val delta = NpcRelationshipEngine.classify("Если бы я предал Бориса, он бы ушёл, но я помог ему.")
    check(delta.trust > 0 && delta.trust == 5) { "Earlier hypothetical must not suppress later completed help: $delta" }
    println("Relationship logic smoke tests: 4 passed")
}
