package com.tavern.dnd

fun main() {
    val c = Campaign(id="test", title="test", worldName="test", heroName="герой")
    c.lastNpc = "странник Бороны"
    val peace = NarrativeTurnDirector.analyze(c, "Вы мне не противники")
    check(peace.intent == NarrativeTurnDirector.Intent.DEESCALATE)
    check(!peace.combatMayStart)
    check(peace.requiresNpcReaction)
    val negotiate = NarrativeTurnDirector.analyze(c, "Предлагаю союз и сделку")
    check(negotiate.intent == NarrativeTurnDirector.Intent.NEGOTIATE)
    check(!negotiate.combatMayStart)
    val threat = NarrativeTurnDirector.analyze(c, "Готовьтесь к бою")
    check(threat.intent == NarrativeTurnDirector.Intent.THREATEN)
    check(!threat.combatMayStart)
    val attack = NarrativeTurnDirector.analyze(c, "Атакую стражника")
    check(attack.intent == NarrativeTurnDirector.Intent.ATTACK)
    check(attack.combatMayStart)
    val rules = NarrativeTurnDirector.responseRules()
    check("Не показывай технические блоки" in rules)
    check("не запускай случайную катастрофу" in rules.lowercase())
    println("PASS: 5 narrative turn contract smoke checks")
}
