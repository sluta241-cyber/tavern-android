import com.tavern.dnd.NpcKnowledgeExtractor

fun main() {
    val names = listOf("Борис")
    val told = NpcKnowledgeExtractor.extract("Я рассказал Борису, что дракон живёт в старой башне.", names)
    check(told.size == 1) { "Expected one told claim, got $told" }
    check(told[0].certainty == "told" && told[0].npcName == "Борис") { "Bad told claim: $told" }
    check(told[0].fact.contains("дракон живёт")) { "Fact lost: $told" }

    val observed = NpcKnowledgeExtractor.extract("Борис видел, как разбойник украл ключ.", names)
    check(observed.size == 1 && observed[0].certainty == "observed") { "Expected observed claim: $observed" }

    val rumor = NpcKnowledgeExtractor.extract("Борис слышал слух, что мост обрушился ночью.", names)
    check(rumor.size == 1 && rumor[0].certainty == "rumor") { "Expected rumor claim: $rumor" }

    val toldByOthers = NpcKnowledgeExtractor.extract("Борису сообщили, что караван прибудет завтра.", names)
    check(toldByOthers.size == 1 && toldByOthers[0].certainty == "told") { "Expected reported claim: $toldByOthers" }

    val negated = NpcKnowledgeExtractor.extract("Я не рассказал Борису, что ключ у меня.", names)
    check(negated.isEmpty()) { "Negated transfer should not extract: $negated" }

    val hypothetical = NpcKnowledgeExtractor.extract("Если бы я рассказал Борису, что ключ у меня, он бы пришёл.", names)
    check(hypothetical.isEmpty()) { "Hypothetical transfer should not extract: $hypothetical" }

    val mixedClauses = NpcKnowledgeExtractor.extract("Если бы я рассказал Борису, что ключ у меня. Но я рассказал Марте, что мост закрыт.", listOf("Борис", "Марта"))
    check(mixedClauses.size == 1 && mixedClauses[0].npcName == "Марта") { "Hypothetical clause must not suppress later explicit claim: $mixedClauses" }
    val commaClauses = NpcKnowledgeExtractor.extract("Если бы я рассказал Борису, что ключ у меня, но я рассказал Марте, что мост закрыт.", listOf("Борис", "Марта"))
    check(commaClauses.size == 1 && commaClauses[0].npcName == "Марта") { "Comma-separated real claim should survive a prior hypothetical: $commaClauses" }

    val quoteOnly = NpcKnowledgeExtractor.extract("Я сказал: «Я рассказал Борису, что ключ у меня».", names)
    check(quoteOnly.isEmpty()) { "Quoted phrase should not extract: $quoteOnly" }

    val ambiguous = NpcKnowledgeExtractor.extract("Я рассказал Борису, что ключ у меня.", listOf("Борис", "капитан Борис"))
    check(ambiguous.isEmpty()) { "Ambiguous NPC alias should not extract: $ambiguous" }

    val alexey = NpcKnowledgeExtractor.extract("Я рассказал Алексею, что вор сбежал.", listOf("Алексей"))
    check(alexey.size == 1 && alexey[0].certainty == "told") { "Names ending in й need dative inflection: $alexey" }

    check(NpcKnowledgeExtractor.replyExplicitlyVetoes("Борис не услышал, что ты ему сказал.", told[0])) { "Explicit failed transfer should veto a told claim" }
    check(NpcKnowledgeExtractor.replyExplicitlyVetoes("Ошибка: модель не ответила.", told[0])) { "Error reply must veto a claim" }
    check(!NpcKnowledgeExtractor.replyExplicitlyVetoes("Борис услышал, но не поверил.", told[0])) { "Disbelief does not erase the fact that NPC was told" }
    check(NpcKnowledgeExtractor.extract("Я рассказал Марте, что мост закрыт.", emptyList()).isEmpty())
    println("NpcKnowledgeExtractor smoke tests: 14 passed")
}
