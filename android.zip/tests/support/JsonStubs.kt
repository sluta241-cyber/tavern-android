package org.json

class JSONObject {
    constructor()
    constructor(raw: String)
    fun length(): Int = 0
    fun keys(): Iterator<String> = emptyList<String>().iterator()
    fun optJSONObject(name: String): JSONObject? = null
    fun optString(name: String): String = ""
    fun optString(name: String, fallback: String): String = fallback
    fun optJSONArray(name: String): JSONArray? = null
    fun optInt(name: String): Int = 0
    fun optInt(name: String, fallback: Int): Int = fallback
    fun has(name: String): Boolean = false
    fun isNull(name: String): Boolean = true
    fun put(name: String, value: Any?): JSONObject = this
    fun remove(name: String): Any? = null
    override fun toString(): String = "{}"
    companion object { val NULL: Any = Any() }
}

class JSONArray {
    constructor()
    fun length(): Int = 0
    fun optJSONObject(index: Int): JSONObject? = null
    fun optString(index: Int): String = ""
    fun put(value: Any?): JSONArray = this
    fun remove(index: Int): Any? = null
}
