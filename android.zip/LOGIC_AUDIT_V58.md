# Tavern v5.7.1 — исправления и аудит

## Исправлено
- `ndk { abiFilters += listOf("arm64-v8a") }` перенесён внутрь `android.defaultConfig`, где он ограничивает ABI приложения корректным образом.
- Подняты `versionCode` до 24 и `versionName` до 5.7.1.
- Исправлен `tools/verify_project.py`: прежняя проверка ожидала старую версию 5.3.0 / 21 и давала ложное падение; добавлены проверки положения ABI-фильтра, наличия upstream llama.cpp и явной маркировки JNI-заглушки.

## Проверки, выполненные локально
- Структурный аудит `tools/verify_project.py`: 0 ошибок, 72 проверки/заметки.
- NPC knowledge extractor: 14 smoke tests passed.
- Relationship logic: 4 smoke tests passed.
- Narrative turn director: 5 smoke checks passed.
- Проверка `modeBlock`: исходный блок с `child`, `uncensored` и `else` сохранён без изменений.

## Оставшиеся ограничения
- APK не собран: в архиве отсутствуют Gradle Wrapper script/JAR; полноценная Android-сборка не запускалась.
- `android/app/src/main/cpp/llama.cpp` отсутствует. CMake намеренно завершает конфигурацию с понятной ошибкой вместо успешной сборки фиктивного движка.
- `tavern_llama.cpp` пока диагностическая JNI-заглушка; реальная локальная генерация не реализована.
