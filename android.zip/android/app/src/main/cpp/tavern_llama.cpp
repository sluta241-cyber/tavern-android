#include <jni.h>
#include <android/log.h>
#include <string>

// Deliberately fails closed until the llama.cpp API version has been pinned and
// the model lifecycle/sampling loop is implemented against that exact revision.
// Never report successful inference from a placeholder implementation.
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "TavernLlama", __VA_ARGS__)

extern "C" JNIEXPORT jstring JNICALL
Java_com_tavern_dnd_LocalLlmEngine_nativeGenerate(
        JNIEnv *env, jobject /*thiz*/, jstring /*modelPath*/, jstring /*prompt*/,
        jint /*contextTokens*/, jint /*maxNewTokens*/, jint /*batchTokens*/, jint /*threads*/) {
    const char *message = "Нативный движок собран без реализации генерации: подключите проверенную версию llama.cpp.";
    LOGE("nativeGenerate called before inference backend is implemented");
    return env->NewStringUTF(message);
}
