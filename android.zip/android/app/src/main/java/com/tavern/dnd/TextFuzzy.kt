package com.tavern.dnd

/** Простое распознавание опечаток и близких формулировок. */
object TextFuzzy {

    fun normalize(s: String): String {
        return s.lowercase()
            .replace('ё', 'е')
            .replace(Regex("[^а-яa-z0-9\\s/_-]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /** Расстояние Левенштейна. */
    fun distance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val m = a.length
        val n = b.length
        var prev = IntArray(n + 1) { it }
        var cur = IntArray(n + 1)
        for (i in 1..m) {
            cur[0] = i
            for (j in 1..n) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[n]
    }

    fun similar(a: String, b: String, maxDist: Int = 2): Boolean {
        val na = normalize(a)
        val nb = normalize(b)
        if (na == nb) return true
        if (na.contains(nb) || nb.contains(na)) return true
        if (kotlin.math.abs(na.length - nb.length) > maxDist) return false
        return distance(na, nb) <= maxDist
    }

    /** Есть ли в тексте слово, похожее на любое из targets. */
    fun containsLike(text: String, targets: List<String>, maxDist: Int = 2): Boolean {
        val words = normalize(text).split(" ").filter { it.length > 1 }
        for (w in words) {
            for (t in targets) {
                if (similar(w, t, maxDist)) return true
                if (w.length >= 4 && t.length >= 4 && (w.startsWith(t.take(3)) || t.startsWith(w.take(3)))) {
                    if (distance(w, t) <= maxDist + 1) return true
                }
            }
        }
        // целиком фраза
        val n = normalize(text)
        for (t in targets) if (similar(n, t, maxDist + 1)) return true
        return false
    }

    fun isGreeting(text: String): Boolean =
        containsLike(text, listOf("привет", "здравствуй", "здравствуйте", "здарова", "добрый", "хай", "hello", "hi"))

    fun isSheetRequest(text: String): Boolean {
        val n = normalize(text)
        if (containsLike(n, listOf("лист", "sheet", "характеристик", "анкета"))) return true
        if (n.contains("покажи") && containsLike(n, listOf("персонаж", "себя", "героя"))) return true
        return false
    }

    fun isNpcSheetRequest(text: String): Boolean {
        val n = normalize(text)
        return n.contains("нпс") || n.contains("npc") ||
            (containsLike(n, listOf("лист")) && (
                containsLike(n, listOf("него", "нее", "её", "ее", "его", "страж", "торгов", "трактир", "жрец", "крестьян", "наемн", "наёмн", "вора", "охотн"))
                || n.split(" ").size >= 2
                ))
    }

    fun isHelp(text: String): Boolean =
        containsLike(text, listOf("помощь", "help", "команды", "что умеешь"))

    fun isStatus(text: String): Boolean =
        containsLike(text, listOf("статус", "состояние", "здоровье")) && !isSheetRequest(text)
}
