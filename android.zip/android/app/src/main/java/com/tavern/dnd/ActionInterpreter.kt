package com.tavern.dnd

/** Lightweight intent/context pass. It does not replace the LLM; it supplies grounded signals. */
object ActionInterpreter {
    data class Intent(
        val primary: String,
        val secondary: List<String>,
        val target: String,
        val isExplicitAttack: Boolean,
        val isDeescalation: Boolean,
        val isQuestion: Boolean,
        val summary: String
    )

    fun analyze(c: Campaign, raw: String): Intent {
        val t = raw.lowercase().replace('ё', 'е')
        val attack = hasAny(t, "атакую", "нападаю", "наношу удар", "бью его", "рублю", "стреляю", "колю мечом", "выхватываю оружие и атакую")
        val deescalation = hasAny(t, "не нападаю", "не хочу драться", "убираю меч", "опускаю оружие", "показываю пустые ладони", "предлагаю мир", "предлагаю сделку", "давай договоримся", "переговор")
        val defense = hasAny(t, "защищаюсь", "уклоняюсь", "уворачиваюсь", "закрываюсь щитом", "принимаю защитную стойку", "прикрываю")
        val stealth = hasAny(t, "крадусь", "скрываюсь", "прячусь", "тихо подхожу", "незаметно")
        val social = hasAny(t, "спрашиваю", "говорю", "убеждаю", "обманываю", "угрожаю", "торгуюсь", "предлагаю", "прошу")
        val movement = hasAny(t, "иду к", "подхожу", "отхожу", "отступаю", "бегу", "перепрыгиваю", "взбираюсь", "открываю дверь")
        val question = '?' in raw || hasAny(t, "кто ", "что ", "почему", "зачем", "где ", "как ", "спрашиваю")
        val parts = mutableListOf<String>()
        if (deescalation) parts += "деэскалация/переговоры"
        if (attack) parts += "явная атака"
        if (defense) parts += "защита/уклонение"
        if (stealth) parts += "скрытность"
        if (social) parts += "социальное взаимодействие"
        if (movement) parts += "перемещение/манипуляция окружением"
        if (question && parts.isEmpty()) parts += "получение информации"
        if (parts.isEmpty()) parts += "свободное действие или описание намерения"
        val target = listOf(c.lastNpc, c.combatEnemyName, c.lastLocation).firstOrNull { it.isNotBlank() }.orEmpty()
        val primary = when {
            deescalation -> "переговоры или снижение угрозы"
            attack -> "атака"
            defense -> "защита"
            stealth -> "скрытное действие"
            social -> "социальное действие"
            movement -> "перемещение или взаимодействие с окружением"
            question -> "получение информации"
            else -> "свободное намерение"
        }
        return Intent(primary, parts.distinct(), target, attack, deescalation, question,
            "Основное намерение: $primary. Связанные намерения: ${parts.distinct().joinToString(", ")}. " +
                "Контекстная цель: ${target.ifBlank { "не определена" }}. " +
                "Это гипотеза для понимания текста, не готовый результат проверки. Не трактуй упоминание оружия как атаку без явного намерения.")
    }

    private fun hasAny(text: String, vararg needles: String) = needles.any { it in text }
}
