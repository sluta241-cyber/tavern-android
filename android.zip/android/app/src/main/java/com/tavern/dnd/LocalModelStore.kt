package com.tavern.dnd

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Stores an optional local GGUF model outside the APK.
 * Model weights are downloaded only after an explicit user action.
 * This class deliberately does not pretend to run inference: the native llama.cpp
 * backend must be supplied and connected before the model can answer in-app.
 */
object LocalModelStore {
    const val MODEL_ID = "Qwen2.5-0.5B-Instruct-Q4_K_M"
    const val EXPECTED_MAX_BYTES = 600L * 1024L * 1024L
    const val EXPECTED_MIN_BYTES = 400L * 1024L * 1024L
    private const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private const val MODEL_FILE = "tavern-qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    data class Status(val downloaded: Boolean, val fileBytes: Long, val path: String?)

    fun status(context: Context): Status {
        val file = modelFile(context)
        val valid = file.isFile && file.length() in EXPECTED_MIN_BYTES..EXPECTED_MAX_BYTES && hasGgufMagic(file)
        return Status(valid, if (file.exists()) file.length() else 0L, if (valid) file.absolutePath else null)
    }

    fun download(context: Context, listener: (progressPercent: Int, result: Result<File>?) -> Unit) {
        val appContext = context.applicationContext
        executor.execute {
            val target = modelFile(appContext)
            val partial = File(target.parentFile, target.name + ".part")
            var connection: HttpURLConnection? = null
            try {
                target.parentFile?.mkdirs()
                val free = target.parentFile?.usableSpace ?: 0L
                if (free < EXPECTED_MAX_BYTES + 64L * 1024L * 1024L) {
                    throw IllegalStateException("Недостаточно свободного места: нужно около 660 МБ")
                }
                connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 20000
                    readTimeout = 60000
                    setRequestProperty("User-Agent", "Tavern-RPG/5.4")
                }
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("Ошибка загрузки модели: HTTP $code")
                val length = connection.contentLengthLong
                if (length > EXPECTED_MAX_BYTES) throw IllegalStateException("Модель превышает лимит 600 МБ")
                BufferedInputStream(connection.inputStream).use { input ->
                    FileOutputStream(partial).use { output ->
                        val buffer = ByteArray(128 * 1024)
                        var total = 0L
                        var lastReported = -1
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            total += read
                            if (total > EXPECTED_MAX_BYTES) throw IllegalStateException("Файл превысил лимит 600 МБ")
                            output.write(buffer, 0, read)
                            if (length > 0) {
                                val pct = ((total * 100L) / length).toInt().coerceIn(0, 100)
                                if (pct != lastReported) { lastReported = pct; listener(pct, null) }
                            }
                        }
                        output.fd.sync()
                    }
                }
                if (partial.length() !in EXPECTED_MIN_BYTES..EXPECTED_MAX_BYTES) {
                    throw IllegalStateException("Размер файла не соответствует ожидаемой модели (${partial.length()} байт)")
                }
                if (!hasGgufMagic(partial)) throw IllegalStateException("Загруженный файл не является GGUF-моделью")
                if (target.exists() && !target.delete()) throw IllegalStateException("Не удалось заменить старую модель")
                if (!partial.renameTo(target)) throw IllegalStateException("Не удалось сохранить модель")
                listener(100, Result.success(target))
            } catch (t: Throwable) {
                partial.delete()
                listener(-1, Result.failure(t))
            } finally {
                connection?.disconnect()
            }
        }
    }

    fun delete(context: Context): Boolean {
        val file = modelFile(context)
        return !file.exists() || file.delete()
    }

    private fun modelFile(context: Context) = File(File(context.filesDir, "models"), MODEL_FILE)

    private fun hasGgufMagic(file: File): Boolean = try {
        file.inputStream().use { input ->
            val magic = ByteArray(4)
            input.read(magic) == 4 && magic.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))
        }
    } catch (_: Exception) { false }
}
