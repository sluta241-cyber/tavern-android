package com.tavern.dnd

/**
 * Converts a deliberately small, documented subset of campaign house rules into
 * executable overrides. Unknown prose remains prompt context and never mutates state.
 */
object CustomRuleEngine {
    enum class RollMode { NORMAL, ADVANTAGE, DISADVANTAGE }
    data class RuleOverrides(
        val criticalThreshold: Int = 20,
        val checkRollMode: RollMode = RollMode.NORMAL,
        val sourceNotes: List<String> = emptyList()
    )
    data class RuleContext(
        val customRules: String,
        val raceTraits: String,
        val classTraits: String,
        val level: Int,
        val mode: String
    ) {
        fun promptBlock(): String = buildString {
            appendLine("ПРИОРИТЕТ ПРАВИЛ: (1) явные правила этой кампании и явно описанные механики персонажа; (2) встроенные правила D&D 5e 2014; (3) временное допущение ведущего, которое нужно обозначить.")
            appendLine("Пользовательские правила кампании — действующие правила, а не декоративный лор: ${customRules.ifBlank { "не заданы" }}")
            appendLine("Кастомные механики расы — применяй только когда описанная способность релевантна и условия выполнены: ${raceTraits.ifBlank { "не заданы" }}")
            appendLine("Кастомные механики класса — применяй только когда описанная способность релевантна и условия выполнены: ${classTraits.ifBlank { "не заданы" }}")
            appendLine("Уровень персонажа: $level. Режим контента: $mode (не изменять).")
            appendLine("Не игнорируй пользовательское правило только потому, что оно отличается от D&D 5e. При конфликте явное правило кампании имеет приоритет. Неясный текст не становится автоматической способностью: уточни условия и не выдумывай числовые бонусы.")
            appendLine("ИСПОЛНЯЕМЫЕ ПРАВИЛА: ${describeOverrides(parseOverrides(customRules))}")
        }
    }

    fun context(c: Campaign): RuleContext = RuleContext(c.customRules.trim(), c.raceTraits.trim(), c.classTraits.trim(), c.level, c.mode)

    /** Supported: explicit DC, advantage/disadvantage for named checks, and natural-19 criticals. */
    fun parseOverrides(raw: String): RuleOverrides {
        val text = raw.lowercase().replace('ё', 'е')
        val notes = mutableListOf<String>()
        val critRegexes = listOf(
            Regex("(?:крит(?:ическое попадание)?|критуют|критует|critical)[^\\n]{0,24}?(?:на|при|с|от)?\\s*(19|20)\\s*(?:[-–]\\s*20)?", RegexOption.IGNORE_CASE),
            Regex("(?:19|20)\\s*[-–]\\s*20[^\\n]{0,20}(?:крит|critical)", RegexOption.IGNORE_CASE)
        )
        var threshold = 20
        if (critRegexes.any { it.containsMatchIn(text) } && text.contains("19")) {
            threshold = 19; notes += "критическое попадание при натуральном 19–20"
        }
        val mode = when {
            Regex("(?:преимущество|с преимуществом)[^\\n]{0,32}(?:проверка|проверки|скрытност|убежден|обман|запугиван|атлетик|восприят)", RegexOption.IGNORE_CASE).containsMatchIn(text) -> RollMode.ADVANTAGE
            Regex("(?:проверка|проверки|скрытност|убежден|обман|запугиван|атлетик|восприят)[^\\n]{0,32}(?:с преимуществом|преимущество)", RegexOption.IGNORE_CASE).containsMatchIn(text) -> RollMode.ADVANTAGE
            Regex("(?:помеха|с помехой)[^\\n]{0,32}(?:проверка|проверки|скрытност|убежден|обман|запугиван|атлетик|восприят)", RegexOption.IGNORE_CASE).containsMatchIn(text) -> RollMode.DISADVANTAGE
            Regex("(?:проверка|проверки|скрытност|убежден|обман|запугиван|атлетик|восприят)[^\\n]{0,32}(?:с помехой|помеха)", RegexOption.IGNORE_CASE).containsMatchIn(text) -> RollMode.DISADVANTAGE
            else -> RollMode.NORMAL
        }
        if (mode != RollMode.NORMAL) notes += "режим броска проверок: ${if (mode == RollMode.ADVANTAGE) "преимущество" else "помеха"}"
        return RuleOverrides(threshold, mode, notes)
    }

    fun resolveDc(c: Campaign, ability: String, defaultDc: Int?): Int? {
        val rules = c.customRules.lowercase().replace('ё', 'е')
        val labels = when {
            ability.contains("ЛОВ") || ability.contains("Скрыт", ignoreCase = true) -> listOf("скрытность", "скрытности", "ловкость", "ловкости", "скрыт")
            ability.contains("Убеждение", ignoreCase = true) -> listOf("убеждение", "убеждения", "социальная проверка")
            ability.contains("Запугивание", ignoreCase = true) -> listOf("запугивание", "запугивания", "угроза", "угрозы")
            ability.contains("Обман", ignoreCase = true) -> listOf("обман", "обмана", "ложь", "лжи")
            ability.contains("Атлетика", ignoreCase = true) || ability.contains("СИЛ") -> listOf("атлетика", "атлетики", "сила", "силы")
            ability.contains("Восприятие", ignoreCase = true) -> listOf("восприятие", "восприятия", "наблюдательность")
            ability.contains("Расследование", ignoreCase = true) -> listOf("расследование", "расследования", "поиск", "поиска")
            else -> emptyList()
        }
        if (labels.isEmpty()) return defaultDc
        for (label in labels) {
            val escaped = Regex.escape(label)
            val patterns = listOf(
                Regex("(?:сл|сложность|dc)[^\\n]{0,24}${escaped}[^0-9]{0,8}(\\d{1,2})", RegexOption.IGNORE_CASE),
                Regex("${escaped}[^\\n]{0,12}(?:сл|сложность|dc)?[^0-9]{0,4}(\\d{1,2})", RegexOption.IGNORE_CASE)
            )
            val number = patterns.asSequence().mapNotNull { it.find(rules)?.groupValues?.getOrNull(1)?.toIntOrNull() }.firstOrNull()
            if (number != null && number in 1..30) return number
        }
        return defaultDc
    }

    private fun describeOverrides(r: RuleOverrides): String = buildList {
        add("порог крита ${r.criticalThreshold}")
        if (r.checkRollMode != RollMode.NORMAL) add("${if (r.checkRollMode == RollMode.ADVANTAGE) "преимущество" else "помеха"} на проверки")
        if (r.isEmpty()) add("другие правила остаются текстовым контекстом до явного описания")
    }.joinToString("; ")
    private fun RuleOverrides.isEmpty(): Boolean = criticalThreshold == 20 && checkRollMode == RollMode.NORMAL
}
