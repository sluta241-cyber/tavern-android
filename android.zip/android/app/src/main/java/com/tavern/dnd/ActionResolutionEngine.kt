package com.tavern.dnd

/**
 * Единый структурированный слой намерения. Он не подменяет D&D броски: если
 * действие относится к бою, фактические броски и изменения HP остаются CombatEngine.
 * Для внебоевых сцен слой задаёт тип проверки/необходимость уточнения и запрещает
 * считать художественный текст подтверждённым изменением состояния.
 */
object ActionResolutionEngine {
    enum class Kind { ATTACK, DEFEND, STEALTH, SOCIAL, MOVE, INTERACT, OBSERVE, REST, UNKNOWN }
    enum class Outcome { NEEDS_RULES_ENGINE, NEEDS_CHECK, NARRATIVE_ONLY, CLARIFY }

    data class ActionResult(
        val kind: Kind,
        val outcome: Outcome,
        val target: String,
        val ability: String,
        val suggestedDc: Int?,
        val rollMode: CustomRuleEngine.RollMode,
        val explicitIntent: Boolean,
        val stateChangesAllowed: Boolean,
        val rationale: String
    ) {
        fun promptLine(): String = buildString {
            append("Тип=${kind.name}; статус=${outcome.name}; цель=${target.ifBlank { "не определена" }}; ")
            append("характеристика=${ability.ifBlank { "не требуется" }}; СЛ=${suggestedDc?.toString() ?: "не задана"}; режим броска=${rollMode.name}; ")
            append("явное намерение=$explicitIntent; подтверждённые изменения состояния разрешены=$stateChangesAllowed. ")
            append(rationale)
        }
    }

    fun resolve(c: Campaign, raw: String): ActionResult {
        val text = raw.lowercase().replace('ё', 'е').trim()
        val negatedAttack = containsAny(text, "не атакую", "не нападаю", "не бью", "не ударяю", "не хочу драться", "не собираюсь атаковать")
        val hypothetical = containsAny(text, "если бы", "мог бы атаковать", "хочу спросить, можно ли", "что будет, если")
        val quoted = text.contains('«') || text.contains('"')
        val attack = !negatedAttack && !hypothetical && containsAny(text,
            "атакую", "нападаю", "наношу удар", "бью его", "бью ее", "рублю", "стреляю", "колю мечом", "ударяю", "режу его", "режу ее")
        val defend = containsAny(text, "защищаюсь", "уклоняюсь", "уворачиваюсь", "закрываюсь щитом", "уклонение")
        val stealth = containsAny(text, "крадусь", "скрываюсь", "прячусь", "незаметно", "тихо подхожу", "взламываю замок")
        val social = containsAny(text, "убеждаю", "обманываю", "угрожаю", "торгуюсь", "прошу", "предлагаю сделку", "пытаюсь убедить", "запугиваю", "уговариваю")
        val move = containsAny(text, "иду к", "подхожу", "отхожу", "отступаю", "бегу", "перепрыгиваю", "взбираюсь", "прыгаю через")
        val interact = containsAny(text, "открываю дверь", "поднимаю", "беру предмет", "осматриваю замок", "использую ключ", "нажимаю", "толкаю")
        val rest = containsAny(text, "короткий отдых", "долгий отдых", "отдыхаю", "ложусь спать")
        val observe = raw.contains('?') || containsAny(text, "осматриваю", "изучаю", "прислушиваюсь", "ищу следы", "замечаю")

        val kind = when {
            attack -> Kind.ATTACK
            defend -> Kind.DEFEND
            stealth -> Kind.STEALTH
            social -> Kind.SOCIAL
            move -> Kind.MOVE
            interact -> Kind.INTERACT
            rest -> Kind.REST
            observe -> Kind.OBSERVE
            else -> Kind.UNKNOWN
        }
        val target = listOf(c.combatEnemyName, c.lastNpc, c.lastLocation)
            .firstOrNull { it.isNotBlank() }.orEmpty()
        val ability = when (kind) {
            Kind.STEALTH -> "ЛОВ"
            Kind.SOCIAL -> if (containsAny(text, "обманываю", "лгу", "обмануть")) "ХАР (Обман)" else if (containsAny(text, "угрожаю", "запугиваю")) "ХАР (Запугивание)" else "ХАР (Убеждение)"
            Kind.MOVE -> if (containsAny(text, "перепрыгиваю", "взбираюсь", "прыгаю через")) "СИЛ (Атлетика)" else ""
            Kind.INTERACT, Kind.OBSERVE -> "МДР (Восприятие) или ИНТ (Расследование) по ситуации"
            else -> ""
        }
        val outcome = when {
            kind == Kind.ATTACK || c.combatActive && kind in setOf(Kind.DEFEND, Kind.MOVE) -> Outcome.NEEDS_RULES_ENGINE
            kind == Kind.SOCIAL || kind == Kind.STEALTH || (kind == Kind.MOVE && ability.isNotBlank()) -> Outcome.NEEDS_CHECK
            kind == Kind.UNKNOWN -> Outcome.CLARIFY
            else -> Outcome.NARRATIVE_ONLY
        }
        val defaultDc = when (kind) {
            Kind.STEALTH -> 12
            Kind.SOCIAL -> 13
            Kind.MOVE -> if (ability.isNotBlank()) 12 else null
            else -> null
        }
        // Explicit numeric campaign DC overrides take precedence over heuristic defaults.
        val dc = CustomRuleEngine.resolveDc(c, ability, defaultDc)
        val explicit = kind != Kind.UNKNOWN && !hypothetical && !(quoted && !attack)
        val rationale = when (outcome) {
            Outcome.NEEDS_RULES_ENGINE -> "Механику боя разрешает CombatEngine; не придумывай бросок, урон или изменение HP."
            Outcome.NEEDS_CHECK -> "СЛ по умолчанию ориентировочная; явная СЛ из правил кампании имеет приоритет. Это ещё не бросок: режим преимущества/помехи является правилом, но бросок должен реально выполнить игровой движок."
            Outcome.NARRATIVE_ONLY -> "Разрешай описанием без автоматических числовых изменений состояния."
            Outcome.CLARIFY -> "Намерение недостаточно определено: задай короткий уточняющий вопрос или опиши только наблюдаемое последствие без необратимых изменений."
        }
        val rollMode = if (outcome == Outcome.NEEDS_CHECK) CustomRuleEngine.parseOverrides(c.customRules).checkRollMode else CustomRuleEngine.RollMode.NORMAL
        return ActionResult(kind, outcome, target, ability, dc, rollMode, explicit,
            stateChangesAllowed = outcome == Outcome.NEEDS_RULES_ENGINE,
            rationale = rationale)
    }

    fun context(c: Campaign, raw: String): String = resolve(c, raw).promptLine() + "\n" + CustomRuleEngine.context(c).promptBlock()

    data class ExecutedCheck(
        val action: ActionResult,
        val roll: Dnd5eRules.CheckResult,
        val skill: String,
        val scoreName: String
    ) {
        fun displayLine(): String {
            val dice = if (roll.secondDie == null) "d20 ${roll.firstDie}" else "d20 ${roll.firstDie} и ${roll.secondDie}; выбрано ${roll.chosenDie}"
            val mode = when (roll.mode) {
                CustomRuleEngine.RollMode.ADVANTAGE -> "преимущество"
                CustomRuleEngine.RollMode.DISADVANTAGE -> "помеха"
                CustomRuleEngine.RollMode.NORMAL -> "обычный бросок"
            }
            return "🎲 Проверка $skill ($mode): $dice ${if (roll.modifier >= 0) "+${roll.modifier}" else roll.modifier.toString()} = ${roll.total} против СЛ ${roll.dc}. " + if (roll.success) "Успех." else "Провал."
        }
    }

    /** Executes only explicit checks that this classifier knows how to resolve. */
    fun executeCheck(c: Campaign, raw: String, rng: kotlin.random.Random = kotlin.random.Random.Default): ExecutedCheck? {
        val action = resolve(c, raw)
        if (!action.explicitIntent || action.outcome != Outcome.NEEDS_CHECK) return null
        val skill = when {
            action.ability.contains("Скрыт") || action.kind == Kind.STEALTH -> "Скрытность"
            action.ability.contains("Обман") -> "Обман"
            action.ability.contains("Запугивание") -> "Запугивание"
            action.ability.contains("Атлетика") -> "Атлетика"
            action.ability.contains("Восприятие") -> "Восприятие"
            action.ability.contains("Расследование") -> "Расследование"
            else -> "Убеждение"
        }
        val scoreName = when (skill) {
            "Скрытность", "Атлетика" -> if (skill == "Атлетика") "СИЛ" else "ЛОВ"
            "Восприятие" -> "МДР"
            "Расследование" -> "ИНТ"
            else -> "ХАР"
        }
        val score = c.stats[scoreName] ?: 10
        val skillText = c.skills.lowercase().replace('ё', 'е')
        val proficient = skill.lowercase() in skillText || when (skill) {
            "Скрытность" -> "скрытност" in skillText
            "Атлетика" -> "атлетик" in skillText
            "Убеждение" -> "убежден" in skillText
            "Запугивание" -> "запугиван" in skillText
            "Обман" -> "обман" in skillText
            "Восприятие" -> "восприят" in skillText
            else -> "расследован" in skillText
        }
        val dc = action.suggestedDc ?: 12
        val roll = Dnd5eRules.checkWithMode(score, proficient, c.level, dc, action.rollMode, rng)
        return ExecutedCheck(action, roll, skill, scoreName)
    }

    private fun containsAny(text: String, vararg values: String): Boolean = values.any { it in text }
}
