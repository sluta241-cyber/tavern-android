package com.tavern.dnd

import kotlin.random.Random
import kotlin.math.max

/** A compact, deterministic-state D&D-style combat resolver for the offline master.
 * It deliberately tracks rules separately from narration so reloads cannot reset a fight.
 */
object CombatEngine {
    private fun mod(score: Int) = Math.floorDiv(score - 10, 2)
    private fun roll(sides: Int, rng: Random) = rng.nextInt(1, sides + 1)
    private fun bonus(n: Int) = if (n >= 0) "+$n" else n.toString()

    fun handle(c: Campaign, rawInput: String, turn: Int): String? {
        val raw = rawInput.trim()
        val t = raw.lowercase()
        val negatedAttack = listOf("не атакую", "не нападаю", "не бью", "не хочу атаковать", "не собираюсь нападать").any { it in t }
        val attack = !negatedAttack && listOf("атак", "ударя", "бью", "наношу удар", "стреля", "рублю", "колю", "нападаю").any { it in t }
        val announce = listOf("готовьтесь к бою", "готов к бою", "приготовиться к бою", "начинаю бой", "вступаю в бой").any { it in t }
        val draw = listOf("достаю оружие", "обнажаю оружие", "выхватываю меч", "беру оружие").any { it in t }
        val defend = listOf("защищаюсь", "ухожу в оборону", "принимаю защитную стойку", "уклоняюсь", "заслоняюсь").any { it in t }
        val dodge = listOf("уклоняюсь", "уворачиваюсь", "избегаю удара", "уклонение").any { it in t }
        val flee = listOf("отступаю", "бегу прочь", "пытаюсь сбежать", "отступить", "бегство").any { it in t }
        val negotiate = listOf("сдавайся", "предлагаю переговоры", "предлагаю сделку", "давай договоримся", "не хочу драться", "мирно").any { it in t }
        val heal = listOf("лечу себя", "лечусь", "зелье лечения", "выпиваю зелье").any { it in t }
        val stabilize = listOf("стабилизирую", "оказываю первую помощь", "стабилизировать", "помогаю истекающему кровью").any { it in t }
        val explicit = attack || announce || draw || defend || flee || negotiate || heal || stabilize
        if (!c.combatActive && stabilize && c.hp <= 0 && !c.characterDead) {
            val medicineProficient = c.skills.contains("Медицина", ignoreCase = true)
            val check = Dnd5eRules.check(c.stats["МДР"] ?: 10, medicineProficient, c.level, 10)
            c.lastActionIntent = "попытка стабилизации союзника"
            return if (check.second) {
                c.deathSaveSuccesses = 3; c.deathSaveFailures = 0
                "Проверка Медицины: d20 ${bonus(check.first.modifier)} = ${check.first.total} против СЛ 10. Персонаж стабилизирован и остаётся без сознания с 0 HP."
            } else "Проверка Медицины: d20 ${bonus(check.first.modifier)} = ${check.first.total} против СЛ 10 — неудача. Можно попробовать снова или применить лечение."
        }
        if (!c.combatActive && !explicit && c.hp > 0 && !c.characterDead) return null
        val rng = Random.Default
        val out = StringBuilder()
        if (c.characterDead) return "Персонаж погиб. Продолжение требует предусмотренного кампанией воскрешения или загрузки сохранения до смерти."
        if (c.hp <= 0 && (!stabilize || c.combatActive)) {
            val save = Dnd5eRules.deathSave(c.deathSaveSuccesses, c.deathSaveFailures, rng)
            c.deathSaveSuccesses = save.successes
            c.deathSaveFailures = save.failures
            out.appendLine("🎲 Спасбросок от смерти: d20 = ${save.roll}.")
            when {
                save.roll == 20 -> { c.hp = 1; c.deathSaveSuccesses = 0; c.deathSaveFailures = 0; out.appendLine("Естественная 20! Персонаж приходит в сознание с 1 HP.") }
                save.dead -> { c.characterDead = true; out.appendLine("Три провала. Персонаж погиб.") }
                save.stable -> { c.hp = 0; out.appendLine("Три успеха. Персонаж стабилен, но без сознания.") }
                else -> out.appendLine("Успехи: ${c.deathSaveSuccesses}/3; провалы: ${c.deathSaveFailures}/3.")
            }
            if (c.combatActive && c.hp == 0 && !c.characterDead && c.deathSaveSuccesses < 3) enemyTurn(c, rng, out)
            return finish(c, turn, out)
        }

        if (!c.combatActive) {
            if (defend && !attack && !announce) {
                c.lastActionIntent = "защитная стойка"
                return "Ты не бросаешься вперёд: закрываешь корпус, следишь за руками противника и оставляешь путь для отхода. Преимущество позиции сохранено; сам по себе этот жест бой не начинает. Что делаешь дальше?"
            }
            if (draw && !attack && !announce) {
                c.lastActionIntent = "оружие обнажено"
                return "Сталь выходит из ножен с коротким звоном. Тот, кто рядом, замечает движение и напрягается, но ещё не обязан нападать. Ты можешь заговорить, отступить или начать бой."
            }
            if (!attack && !announce) return null
            val recent = (c.messages.takeLast(6).joinToString(" ") { it.content } + " " + raw).lowercase()
            val enemy = when {
                "гоблин" in recent -> "гоблин"
                "волк" in recent || "волки" in recent -> "волк"
                "разбойник" in recent -> "разбойник"
                "скелет" in recent || "нежить" in recent -> "скелет"
                "орк" in recent -> "орк"
                "дракон" in recent -> "дракон"
                else -> "противник у ${c.lastLocation.ifBlank { "тебя на пути" }}"
            }
            val level = c.level.coerceAtLeast(1)
            c.combatActive = true
            c.combatEnemyName = enemy
            c.combatEnemyKind = enemy
            c.combatEnemyMaxHp = when (enemy) { "гоблин" -> 7; "волк" -> 11; "разбойник" -> 16; "скелет" -> 13; "орк" -> 15; "дракон" -> 100; else -> 12 + level * 2 }
            c.combatEnemyHp = c.combatEnemyMaxHp
            c.combatEnemyAc = when (enemy) { "гоблин" -> 15; "волк" -> 13; "разбойник" -> 12; "скелет" -> 13; "орк" -> 13; "дракон" -> 19; else -> 12 }
            c.combatRound = 1
            val dex = mod(c.stats["ЛОВ"] ?: 10)
            val enemyInit = roll(20, rng) + if (enemy == "волк" || enemy == "гоблин") 2 else 0
            val playerInit = roll(20, rng) + dex
            c.combatInitiative = if (playerInit >= enemyInit) "${c.heroName} $playerInit · $enemy $enemyInit" else "$enemy $enemyInit · ${c.heroName} $playerInit"
            out.appendLine("⚔️ **Бой начинается — раунд 1.**")
            out.appendLine("Инициатива: ${c.combatInitiative}.")
            out.appendLine("${c.combatEnemyName}: КД ${c.combatEnemyAc}, HP ${c.combatEnemyHp}/${c.combatEnemyMaxHp}.")
            if (!attack) {
                out.appendLine("Ты занял позицию, оружие наготове. Доступно: атака, рывок, уклонение, помощь, отход или попытка переговоров.")
                return out.toString().trim()
            }
        }

        if (!c.combatActive) return out.toString().trim()
        if (negotiate) {
            val chance = roll(20, rng) + mod(c.stats["ХАР"] ?: 10)
            out.appendLine("Проверка убеждения: d20 + ${bonus(mod(c.stats["ХАР"] ?: 10))} = $chance.")
            if (chance >= 15 || c.combatEnemyHp <= c.combatEnemyMaxHp / 3) {
                out.appendLine("Противник колеблется и отступает на шаг. Он согласен прекратить бой, если ты не нападёшь первым.")
                c.combatActive = false; c.combatEnemyHp = 0; c.combatEnemyName = ""; c.combatPlayerDodging = false
                c.lastActionIntent = "переговоры завершили бой"
            } else {
                out.appendLine("Противник не верит тебе и не опускает оружие.")
                enemyTurn(c, rng, out)
            }
            return finish(c, turn, out)
        }
        if (flee) {
            val check = roll(20, rng) + mod(c.stats["ЛОВ"] ?: 10)
            out.appendLine("Отход: проверка Ловкости d20 ${bonus(mod(c.stats["ЛОВ"] ?: 10))} = $check против СЛ 12.")
            if (check >= 12) {
                out.appendLine("Ты разрываешь дистанцию и скрываешься за укрытием. Бой окончен, но противник может запомнить твоё лицо.")
                c.combatActive = false; c.combatEnemyName = ""; c.combatEnemyHp = 0; c.combatPlayerDodging = false
            } else {
                out.appendLine("Противник перекрывает путь отхода.")
                enemyTurn(c, rng, out)
            }
            return finish(c, turn, out)
        }
        if (heal) {
            val healed = minOf(c.maxHp - c.hp, roll(8, rng) + 2).coerceAtLeast(0)
            c.hp += healed
            if (c.hp > 0) { c.deathSaveSuccesses = 0; c.deathSaveFailures = 0 }
            out.appendLine("Ты тратишь действие на лечение: 1d8 + 2 = восстановлено $healed HP. Сейчас ${c.hp}/${c.maxHp}.")
            if (healed == 0) out.appendLine("Запас здоровья уже полон; потраченный ресурс не вернулся.")
            enemyTurn(c, rng, out)
            return finish(c, turn, out)
        }
        if (defend || dodge) {
            c.combatPlayerDodging = true
            out.appendLine("Ты используешь действие на уклонение: до начала следующего хода атаки, которые ты видишь, совершаются с помехой.")
            enemyTurn(c, rng, out)
            return finish(c, turn, out)
        }
        if (!attack) {
            out.appendLine("Раунд ${c.combatRound}. Выбери конкретное действие: атаковать, уклониться, отойти, лечиться или попытаться договориться.")
            return out.toString().trim()
        }

        val str = c.stats["СИЛ"] ?: 10
        val dex = c.stats["ЛОВ"] ?: 10
        val finesse = listOf("лук", "арбалет", "стреля", "кинжал", "ловкост").any { it in t }
        val ability = if (finesse) dex else str
        val attackBonus = mod(ability) + (2 + (c.level - 1) / 4).coerceAtLeast(2)
        val damageSides = when {
            listOf("двуруч", "великий меч", "секира", "глефа", "алебард").any { it in t || it in c.inventory.lowercase() } -> 10
            listOf("короткий меч", "рапира", "длинный меч", "боевой топор", "лук", "арбалет").any { it in t || it in c.inventory.lowercase() } -> 8
            listOf("кинжал", "дубинка", "праща").any { it in t || it in c.inventory.lowercase() } -> 4
            else -> 6
        }
        val className = (c.heroClass + " " + c.multiclass).lowercase()
        val hasExtraAttack = c.level >= 5 && (
            listOf("воин", "fighter", "паладин", "paladin", "следопыт", "ranger", "варвар", "barbarian", "монах", "monk").any { it in className } ||
                c.classTraits.contains("дополнительная атака", ignoreCase = true) || c.classTraits.contains("extra attack", ignoreCase = true)
        )
        val attacks = if (hasExtraAttack) 2 else 1
        out.appendLine("**Твоя атака — раунд ${c.combatRound}.**${if (attacks > 1) " Доступно атак по действию: $attacks." else ""}")
        for (attackNo in 1..attacks) {
            if (c.combatEnemyHp <= 0) break
            val result = Dnd5eRules.attack(attackBonus, c.combatEnemyAc, 1, damageSides, mod(ability), rng, CustomRuleEngine.parseOverrides(c.customRules).criticalThreshold)
            val natural = result.roll.natural
            val total = result.roll.total
            out.appendLine(if (attacks > 1) "**Атака $attackNo.** 🎲 d20 ${bonus(attackBonus)} = $natural ${bonus(attackBonus)} = $total против КД ${c.combatEnemyAc}." else "🎲 d20 ${bonus(attackBonus)} = $natural ${bonus(attackBonus)} = $total против КД ${c.combatEnemyAc}.")
            if (result.hit) {
                c.combatEnemyHp = (c.combatEnemyHp - result.totalDamage).coerceAtLeast(0)
                val diceLabel = if (result.critical) "критическое попадание: ${result.damageRolls.size}d$damageSides" else "урон: 1d$damageSides"
                out.appendLine("${if (result.critical) "Критическое попадание!" else "Попадание."} $diceLabel (${result.damageRolls.joinToString(" + ")}) ${bonus(result.flatDamage)} = ${result.totalDamage}.")
                out.appendLine("${c.combatEnemyName}: HP ${c.combatEnemyHp}/${c.combatEnemyMaxHp}.")
            } else out.appendLine(if (natural == 1) "Критический промах: удар уходит в сторону." else "Промах. Противник успевает сместиться, и оружие рассекает воздух.")
        }
        if (c.combatEnemyHp <= 0) {
            out.appendLine("${c.combatEnemyName} падает и больше не представляет угрозы. Бой окончен.")
            c.combatActive = false; c.combatEnemyName = ""; c.combatEnemyHp = 0; c.combatPlayerDodging = false
            c.worldTension = (c.worldTension + 2).coerceAtMost(100)
            c.worldLog = (c.worldLog.split("\n").filter { it.isNotBlank() } + "Х$turn/бой: побеждён противник ${c.combatEnemyKind}.").takeLast(40).joinToString("\n")
        } else enemyTurn(c, rng, out)
        return finish(c, turn, out)
    }

    private fun enemyTurn(c: Campaign, rng: Random, out: StringBuilder) {
        if (!c.combatActive || c.combatEnemyHp <= 0) return
        val enemy = c.combatEnemyName
        val attackBonus = when (c.combatEnemyKind) { "гоблин" -> 4; "волк" -> 4; "разбойник" -> 3; "скелет" -> 4; "орк" -> 5; "дракон" -> 8; else -> 3 }
        val ac = 10 + mod(c.stats["ЛОВ"] ?: 10) + if (c.combatPlayerDodging) 2 else 0
        val first = roll(20, rng)
        val second = if (c.combatPlayerDodging) roll(20, rng) else first
        val natural = if (c.combatPlayerDodging) minOf(first, second) else first
        val total = natural + attackBonus
        out.appendLine("**Ход противника — $enemy.**")
        out.appendLine(if (c.combatPlayerDodging) "🎲 Атака с помехой: $first и $second, берём $natural; итог $total против КД $ac." else "🎲 d20 + $attackBonus = $natural + $attackBonus = $total против КД $ac.")
        if (natural == 20 || (total >= ac && natural != 1)) {
            val sides = when (c.combatEnemyKind) { "гоблин", "скелет", "разбойник" -> 6; "волк" -> 8; "орк" -> 12; "дракон" -> 10; else -> 6 }
            val flat = when (c.combatEnemyKind) { "гоблин", "скелет" -> 2; "волк" -> 2; "разбойник" -> 1; "орк" -> 3; "дракон" -> 5; else -> 1 }
            val critical = natural == 20
            val diceCount = if (critical) 2 else 1
            val dice = (0 until diceCount).map { roll(sides, rng) }
            val damage = (dice.sum() + flat).coerceAtLeast(1)
            c.hp = (c.hp - damage).coerceAtLeast(0)
            if (c.hp == 0) { c.deathSaveSuccesses = 0; c.deathSaveFailures = 0 }
            out.appendLine("${if (critical) "Критическое попадание! " else "Попадание."} Урон: ${diceCount}d$sides (${dice.joinToString(" + ")}) + $flat = $damage. HP героя: ${c.hp}/${c.maxHp}.")
            if (c.hp == 0) out.appendLine("Ты падаешь без сознания. В свой ход потребуется спасбросок от смерти; союзник может потратить действие на стабилизацию.")
        } else out.appendLine("Противник промахивается; удар скользит по броне или проходит рядом.")
        c.combatPlayerDodging = false
        c.combatRound += 1
    }

    private fun finish(c: Campaign, turn: Int, out: StringBuilder): String {
        if (c.combatActive) out.appendLine("Состояние: раунд ${c.combatRound}, враг ${c.combatEnemyName} ${c.combatEnemyHp}/${c.combatEnemyMaxHp} HP; ты ${c.hp}/${c.maxHp} HP. Действие на ход: атака, уклонение, отход, лечение или переговоры.")
        c.lastActionIntent = when { !c.combatActive -> "бой завершён"; else -> "боевое действие" }
        c.campaignMemory = (c.campaignMemory.lines().filter { it.isNotBlank() } + "Ход $turn: ${c.heroName}: ${c.lastActionIntent}; HP ${c.hp}/${c.maxHp}; бой=${c.combatActive}; враг=${c.combatEnemyName.ifBlank { "нет" }}.").takeLast(12).joinToString("\n")
        c.saveSchemaVersion = 5
        return out.toString().trim()
    }
}
