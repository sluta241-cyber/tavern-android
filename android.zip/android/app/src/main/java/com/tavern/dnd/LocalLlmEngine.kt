package com.tavern.dnd

import android.content.Context
import java.io.File

/**
 * Stable Kotlin boundary for an optional llama.cpp/JNI implementation.
 * The JNI library is deliberately optional: the app remains launchable when it is absent.
 * Native symbols are not bundled in this archive yet, so this class reports that honestly
 * and uses the deterministic offline engine as a fallback rather than pretending inference ran.
 */
object LocalLlmEngine {
    private const val LIBRARY = "tavern_llama"
    @Volatile private var libraryChecked = false
    @Volatile private var libraryAvailable = false

    data class Readiness(val modelPresent: Boolean, val nativeBackendPresent: Boolean, val reason: String) {
        val ready: Boolean get() = modelPresent && nativeBackendPresent
    }

    fun readiness(context: Context): Readiness {
        val model = LocalModelStore.status(context)
        val native = ensureLibraryLoaded()
        val reason = when {
            !model.downloaded -> "Сначала скачайте GGUF-модель в разделе локальной модели."
            !native -> "Нативный движок llama.cpp ещё не включён в сборку приложения."
            else -> "Локальная модель готова."
        }
        return Readiness(model.downloaded, native, reason)
    }

    /** Called from the existing IO dispatcher. The game rules/state engine remains authoritative. */
    fun chat(campaign: Campaign, userMessage: String): String {
        val app = AppContextHolder.context
        if (app == null) return OfflineEngine.respond(campaign, userMessage)
        val ready = readiness(app)
        if (!ready.ready) {
            return "Локальная модель пока недоступна: ${ready.reason}\n\nОфлайн-ответ:\n${OfflineEngine.respond(campaign, userMessage)}"
        }
        return try {
            val profile = LocalModelRuntimeProfile.forDevice(app)
            val modelPath = LocalModelStore.status(app).path ?: error("Файл модели не найден")
            val prompt = buildString {
                appendLine("<|im_start|>system")
                appendLine(OnlineLlm.systemPrompt(campaign))
                appendLine("<|im_end|>")
                appendLine("<|im_start|>user")
                appendLine(userMessage.take(6000))
                appendLine("<|im_end|>")
                append("<|im_start|>assistant\n")
            }
            nativeGenerate(modelPath, prompt, profile.contextTokens, profile.maxNewTokens, profile.batchTokens, profile.threads)
                .trim().ifBlank { OfflineEngine.respond(campaign, userMessage) }
        } catch (e: UnsatisfiedLinkError) {
            "Нативный движок не поддерживает текущую сборку.\n\nОфлайн-ответ:\n${OfflineEngine.respond(campaign, userMessage)}"
        } catch (e: Exception) {
            "Ошибка локальной модели (${e.message?.take(100)}).\n\nОфлайн-ответ:\n${OfflineEngine.respond(campaign, userMessage)}"
        }
    }

    private fun ensureLibraryLoaded(): Boolean {
        if (!libraryChecked) synchronized(this) {
            if (!libraryChecked) {
                libraryAvailable = try { System.loadLibrary(LIBRARY); true } catch (_: UnsatisfiedLinkError) { false }
                libraryChecked = true
            }
        }
        return libraryAvailable
    }

    // Contract for the future JNI implementation. It must free native context after generation
    // unless a bounded, device-aware model cache is explicitly enabled.
    private external fun nativeGenerate(
        modelPath: String,
        prompt: String,
        contextTokens: Int,
        maxNewTokens: Int,
        batchTokens: Int,
        threads: Int
    ): String

    /** Application context injected by MainActivity without retaining an Activity. */
    object AppContextHolder {
        @Volatile var context: Context? = null
    }
}
