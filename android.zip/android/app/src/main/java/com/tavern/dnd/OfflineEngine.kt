package com.tavern.dnd

import kotlin.random.Random
import org.json.JSONObject

/**
 * Офлайн-мастер v3.2+: статусы, иерархия, фетиши (18+),
 * последствия, катастрофы, лор/правила, внешность, личность.
 */
object OfflineEngine {

    data class Biome(
        val sites: List<String>, val sounds: List<String>, val smells: List<String>,
        val fauna: List<String>, val hazards: List<String>
    )

    data class NpcLive(
        val id: String,
        val name: String,
        val role: String,
        val rank: String,          // иерархия
        val status: String,        // социальный статус
        val profession: String,
        val sex: String,
        val age: Int,
        val appearance: String,
        val beauty: Int,
        val personality: String,
        val traits: List<String>,
        val speechStyle: String,
        val goal: String,
        val fear: String,
        val kinkTags: List<String>, // открытые/скрытые предпочтения (для adult+)
        val lines: List<String>,
        var affection: Int = 0,
        var trust: Int = 0,
        var fearOfPc: Int = 0,
        var plan: String = ""      // текущее намерение NPC
    )

    private val biomes = mapOf(
        "лес" to Biome(listOf("часовня", "лесопилка", "каменный круг", "домик углежога", "охотничья тропа"), listOf("скрип стволов", "крик совы"), listOf("хвоя", "прель"), listOf("олени", "волки"), listOf("топкие корни")),
        "горы" to Biome(listOf("перевал", "рудник", "монастырь", "пещера"), listOf("вой ветра"), listOf("камень", "сера"), listOf("орлы", "козероги"), listOf("осыпи")),
        "болото" to Biome(listOf("затопленная деревня", "ведьмин мосток", "курган"), listOf("бульканье"), listOf("гниль"), listOf("цапли", "змеи"), listOf("зыбун")),
        "степь" to Biome(listOf("стан кочевников", "почтовая станция", "курган", "колодец"), listOf("свист ветра"), listOf("пыль", "полынь"), listOf("сайгаки", "орлы"), listOf("зной")),
        "побережье" to Biome(listOf("маяк", "посёлок", "бухта", "таверна у причала"), listOf("прибой"), listOf("соль", "рыба"), listOf("чайки"), listOf("прилив")),
        "пустыня" to Biome(listOf("караван-сарай", "колодец", "руины"), listOf("шелест песка"), listOf("пыль"), listOf("ящерицы"), listOf("жажда")),
        "тундра" to Biome(listOf("зимовье", "тотем", "форт"), listOf("вой ветра"), listOf("холод"), listOf("олени", "песцы"), listOf("метель")),
        "джунгли" to Biome(listOf("пирамида", "висячий мост", "деревня на сваях"), listOf("крики обезьян"), listOf("прелость"), listOf("ягуары"), listOf("пиявки")),
        "город" to Biome(
            listOf("таверна «Три кружки»", "рынок", "храм", "трущобы", "порт", "гильдия", "казармы", "дворецкая площадь", "улица фонарей"),
            listOf("крики торговцев", "звон кузницы"), listOf("дым", "специи", "хлеб"), listOf("крысы", "голуби"), listOf("воры", "давка")
        )
    )

    private val seasons = mapOf(
        "весна" to "половодье и ранняя грязь", "лето" to "жаркий долгий день",
        "осень" to "туман и сырой урожай", "зима" to "короткий свет и голодный холод"
    )

    // --- иерархия / профессии / статус ---
    private data class RoleDef(
        val role: String, val ranks: List<String>, val statuses: List<String>,
        val profession: String, val goals: List<String>, val fears: List<String>,
        val namesM: List<String>, val namesF: List<String>
    )

    private val roles = listOf(
        RoleDef("стражник", listOf("новобранец", "рядовой", "десятник", "сержант", "капитан стражи"),
            listOf("служилый", "при должности", "на грани увольнения"), "городская стража",
            listOf("выполнить приказ", "не попасть под суд", "получить взятку тихо"), listOf("гнев капитана", "восстание", "магия"),
            listOf("Рен", "Кайл", "Тит", "Серж"), listOf("Ольга", "Мира", "Дана")),
        RoleDef("трактирщик", listOf("помощник", "хозяин зала", "владелец"),
            listOf("мелкий хозяин", "уважаемый в квартале"), "трактирное дело",
            listOf("прибыль", "тишина в зале", "хорошая репутация"), listOf("долги", "пожар", "гнев знати"),
            listOf("Борис", "Осип", "Гедеон"), listOf("Марта", "Инга", "Фекла")),
        RoleDef("торговец", listOf("лоточник", "лавочник", "купец гильдии", "фактор каравана"),
            listOf("мещанин", "член гильдии", "богатый гость"), "торговля",
            listOf("выгодная сделка", "новый рынок"), listOf("разбой", "конфискация", "конкуренты"),
            listOf("Лис", "Том", "Карл"), listOf("Сара", "Яна", "Рита")),
        RoleDef("дворянин", listOf("безземельный", "мелкий барон", "придворный", "наместник"),
            listOf("знать", "при дворе", "в опале"), "управление землёй",
            listOf("влияние", "брачный союз", "унизить соперника"), listOf("скандал", "яд", "потеря титула"),
            listOf("Эдрик", "Вальтер", "Роман"), listOf("Эльза", "Ирина", "Кларис")),
        RoleDef("жрец", listOf("послушник", "диакон", "священник", "настоятель"),
            listOf("клирик", "уважаемый", "под подозрением инквизиции"), "церковь",
            listOf("распространить веру", "очистить ересь"), listOf("богохульство", "тёмные чудеса"),
            listOf("отец Ильин", "брат Дан"), listOf("сестра Вера", "мать Анна")),
        RoleDef("наёмник", listOf("зелёный", "ветеран", "сержант роты", "капитан отряда"),
            listOf("вольный меч", "на службе дома"), "наёмничество",
            listOf("деньги", "слава", "выжить"), listOf("предательство", "проклятие"),
            listOf("Ворг", "Дрейк", "Гор"), listOf("Кира", "Нелл", "Бриг")),
        RoleDef("вор", listOf("карманник", "взломщик", "смотрящий улицы", "правая рука гильдии"),
            listOf("изгой", "в гильдии", "в розыске"), "вор",
            listOf("добыча", "не попасться"), listOf("пытки", "изгнание"),
            listOf("Шустрый", "Нож", "Пыль"), listOf("Лиска", "Тень", "Искра")),
        RoleDef("крестьянин", listOf("батрак", "дворник", "старшина деревни"),
            listOf("простолюдин", "свободный держатель"), "земледелие",
            listOf("урожай", "семья"), listOf("голод", "набеги"),
            listOf("Пётр", "Мирон"), listOf("Аня", "Фёкла")),
        RoleDef("охотник", listOf("следопыт", "егерь", "старший охотник"),
            listOf("вольный", "на службе лесничества"), "охота",
            listOf("пушнина", "тропа"), listOf("зверь", "голод"),
            listOf("Волк", "Егерь", "Стрела"), listOf("Роса", "Ива")),
        RoleDef("солдат", listOf("рядовой", "капрал", "сержант", "лейтенант"),
            listOf("военный", "дезертир", "ветеран"), "армия",
            listOf("дожить до своих", "выполнить приказ"), listOf("плен", "суд"),
            listOf("Иван", "Марк", "Гор"), listOf("Лена", "Соня"))
    )

    private val personalities = listOf(
        "осторожный реалист" to listOf("сдержанный", "наблюдательный"),
        "вспыльчивый гордец" to listOf("резкий", "самолюбивый"),
        "тихий слуга привычки" to listOf("послушный", "усталый"),
        "циничный шутник" to listOf("язвительный", "живой"),
        "набожный строгий" to listOf("моралист", "твёрдый"),
        "алчный прагматик" to listOf("расчётливый", "гибкий"),
        "добрый, но слабый" to listOf("мягкий", "нерешительный"),
        "холодный профессионал" to listOf("деловой", "закрытый"),
        "любопытствующий бродяга" to listOf("разговорчивый", "лёгкий"),
        "раненая душа" to listOf("подозрительный", "тихий"),
        "властный доминирующий" to listOf("жёсткий", "требовательный"),
        "покорный ищущий опору" to listOf("мягкий", "зависимый")
    )

    // Фетиш-теги (для adult/uncensored) — влияют на реакции, не на детский режим
    private val kinkPool = listOf(
        "власть", "подчинение", "роль_господин_слуга", "сословная_разница",
        "похвала", "грубость", "нежность", "риск_быть_увиденным",
        "форма_власти", "плен", "унижение_словесное", "забота_после",
        "сила_партнёра", "голос", "взгляд_власти"
    )

    private val disasters = listOf(
        Triple("пожар_в_квартале", 0.04, "В дальнем квартале поднимается чёрный дым — пожар. Люди кричат, стража бежит с вёдрами."),
        Triple("эпидемия_слухов", 0.03, "По городу/стану ползёт слух о чуме. Рынок редеет, лица закрывают платками."),
        Triple("набег", 0.035, "С окраины доносится рог: набег. Кто-то прячет детей, кто-то хватает оружие."),
        Triple("голод", 0.025, "Цены на хлеб скачут. В глазах торговцев злость, в глазах бедняков — отчаяние."),
        Triple("буря", 0.05, "Небо схлопывается. Буря ломает ветки/паруса/палатки. Дороги на часы становятся ловушкой."),
        Triple("аресты", 0.03, "Стража устраивает облаву. Кто-то указывает пальцем, кто-то исчезает в подворотне."),
        Triple("порча_колодца", 0.02, "Колодец/источник испорчен. Народ шепчется о мести или о порче."),
        Triple("знамение", 0.02, "На небе странный знак — комета или кровавый закат. Жрецы уже толкуют, торговцы уже повышают цены.")
    )

    private val weather = listOf("пасмурно", "моросит", "ясно", "ветер", "туман", "холодно", "сыро")
    private val hairColors = listOf("чёрные", "русые", "рыжие", "пепельные", "каштановые", "с проседью")
    private val eyeColors = listOf("карие", "серые", "зелёные", "голубые", "янтарные")
    private val builds = listOf("коренастый", "жилистый", "полный", "худощавый", "широкоплечий", "изящный")
    private val faces = listOf("острое лицо", "круглое лицо", "шрам на брови", "жёсткий рот", "мягкие черты", "сбитый нос")
    private val clothes = listOf("потёртый плащ", "чистый кафтан", "латанная куртка", "дорожный доспех", "форменная накидка")

    private val campaignNpcs = mutableMapOf<String, MutableList<NpcLive>>()

    fun openingScene(c: Campaign): String {
        val b = biomeOf(c.landscape)
        val site = b.sites.random()
        c.lastLocation = site
        val npc = ensureNpc(c)
        c.lastNpc = "${npc.role} ${npc.name}"
        persistNpc(c, npc)
        val classLine = if (c.multiclass.isNotBlank()) "${c.heroClass}/${c.multiclass}" else c.heroClass
        applyLoreFlags(c)
        return buildString {
            appendLine("══ ${c.worldName} ══")
            appendLine("${cap(c.season)}, ${c.landscape}. ${seasons[c.season] ?: ""}")
            if (c.worldLore.isNotBlank()) appendLine("Лор: ${c.worldLore}")
            appendLine("ЕДИНАЯ СИСТЕМА КАСТОМНЫХ ПРАВИЛ:\n${CustomRuleEngine.context(c).promptBlock()}")
            if (c.customRules.isNotBlank()) appendLine("Правила партии (действуютствуют): ${c.customRules}")
            appendLine("Состояние края: напряжённость ${c.worldTension}/100, достаток ${c.worldProsperity}/100, страх ${c.worldFear}/100.")
            appendLine()
            appendLine("Ты — ${c.heroName}, ${c.race}, $classLine ${c.level}/${c.maxLevel} ур., ${c.alignment}.")
            appendLine("Статус: ${c.socialRank} · богатство ${c.wealth}/10 · ${c.divineTier} (вес ~${SocialSpeech.playerWeight(c)})")
            appendLine("Красота ${c.beauty}/10. ${c.appearance.ifBlank { generateHeroAppearance(c) }}")
            if (c.traits.isNotBlank()) appendLine("Черты: ${c.traits}")
            if (c.mythicalTraits.isNotBlank()) appendLine("Мифическое: ${c.mythicalTraits}")
            if (c.mythicalAscension.isNotBlank()) appendLine("Путь вознесения: ${c.mythicalAscension}")
            if (c.raceTraits.isNotBlank()) appendLine("Раса: ${c.raceTraits}")
            if (c.classTraits.isNotBlank()) appendLine("Класс: ${c.classTraits}")
            if (c.backstory.isNotBlank()) appendLine("Предыстория: ${c.backstory}")
            if (c.skills.isNotBlank()) appendLine("Навыки: ${c.skills}")
            appendLine("Характеристики: ${c.stats.entries.joinToString { "${it.key}${it.value}" }} · HP ${c.hp}/${c.maxHp}")
            appendLine()
            appendLine("Место: $site. ${cap(b.sounds.random())}; пахнет ${b.smells.random()}.")
            appendLine()
            appendLine("Здесь ${npc.name} — ${npc.profession}, ранг «${npc.rank}», статус «${npc.status}».")
            appendLine("Личность: ${npc.personality}. ${npc.appearance}")
            if (c.mode != "child" && npc.kinkTags.isNotEmpty()) {
                appendLine("(Скрытые склонности этого NPC проявятся только если сцена к ним ведёт.)")
            }
            appendLine()
            appendLine(npc.lines.random())
            appendLine()
            appendLine("Команды: лист · лист нпс · статус · помощь · мир")
            appendLine("Что делаешь?")
        }.trim()
    }

    fun respond(c: Campaign, userMessage: String): String {
        val raw = userMessage.trim()
        if (raw.isEmpty()) return "Напиши действие или речь."

        when {
            TextFuzzy.isHelp(raw) -> return helpText()
            TextFuzzy.isStatus(raw) -> return statusBlock(c)
            TextFuzzy.containsLike(raw, listOf("мир", "обстановка", "что в мире")) &&
                !TextFuzzy.isSheetRequest(raw) -> return worldReport(c)
            TextFuzzy.isNpcSheetRequest(raw) -> return npcSheet(c, raw)
            TextFuzzy.isSheetRequest(raw) -> return characterSheet(c)
            TextFuzzy.containsLike(raw, listOf("брак", "женись", "выйти замуж", "предложение руки", "заключить союз", "контракт брака", "обруч")) -> {
                val npc = ensureNpc(c)
                return MarriageLogic.tryPlayerProposal(c, npc.name, npc.rank, npc.role, c.messages.count { it.role == "user" } + 1)
            }
            TextFuzzy.containsLike(raw, listOf("вознес", "стать богом", "стать полубогом", "апофеоз", "божественн")) -> {
                return divineAscensionScene(c, raw)
            }
        }

        val turn = c.messages.count { it.role == "user" } + 1
        // Combat is resolved by a rules engine before narrative flavour is generated.
        CombatEngine.handle(c, raw, turn)?.let { return it }
        // Non-combat checks now use the same executable custom-rule overrides as the online prompt.
        val executedCheck = ActionResolutionEngine.executeCheck(c, raw, Random((c.id + turn + raw + "check").hashCode()))
        val rng = Random((c.id + turn + raw).hashCode())
        val b = biomeOf(c.landscape)
        applyLoreFlags(c)

        val violent = TextFuzzy.containsLike(raw, listOf("убить", "удар", "нож", "меч", "кровь", "напасть", "бить", "резать", "пытка", "сломать"))
        val sexual = TextFuzzy.containsLike(raw, listOf("секс", "целовать", "поцелуй", "ласкать", "обнять", "раздеть", "трах", "господин", "раб"))
        val talk = TextFuzzy.isGreeting(raw) || TextFuzzy.containsLike(raw, listOf("говорить", "сказать", "спросить", "просить", "торговать", "предложить"))
        val generous = TextFuzzy.containsLike(raw, listOf("дать", "подарить", "заплатить", "помочь", "вылечить"))
        val insult = TextFuzzy.containsLike(raw, listOf("дурак", "убей себя", "отвали", "тварь", "урод"))

        val npc = ensureNpc(c)
        c.lastNpc = "${npc.role} ${npc.name}"
        val site = c.lastLocation.ifBlank { b.sites.random() }
        c.lastLocation = site

        // --- логика отношений и последствий ---
        when {
            generous -> { npc.trust += 2; npc.affection += 1; c.worldProsperity = (c.worldProsperity + 1).coerceAtMost(100) }
            insult -> { npc.trust -= 2; npc.affection -= 2; npc.fearOfPc += 1 }
            violent -> {
                npc.trust -= 3; npc.affection -= 2; npc.fearOfPc += 2
                c.worldTension = (c.worldTension + 8).coerceAtMost(100)
                c.worldFear = (c.worldFear + 5).coerceAtMost(100)
                logWorld(c, turn, "Насилие у $site не прошло незамеченным.", "consequence")
                if (c.mode != "child" && rng.nextDouble() < 0.45) c.hp = (c.hp - rng.nextInt(1, 6)).coerceAtLeast(0)
                // иерархия: удар по страже/дворянину опаснее
                if (npc.role in listOf("стражник", "дворянин", "жрец")) {
                    c.worldTension = (c.worldTension + 10).coerceAtMost(100)
                    logWorld(c, turn, "Пострадал человек при должности (${npc.rank}). Власти могут ответить.", "consequence")
                    npc.plan = "доложить начальству или отомстить"
                } else npc.plan = "избежать тебя или ударить в спину"
            }
            talk && TextFuzzy.isGreeting(raw) -> { if (executedCheck == null || executedCheck.roll.success) { npc.trust += 1; npc.affection += 1 }; npc.plan = "продолжить разговор" }
            talk -> { if (executedCheck == null || executedCheck.roll.success) npc.trust += 1; npc.plan = if (executedCheck != null && !executedCheck.roll.success) "сохранять осторожность после неудачной попытки" else "выжать выгоду из разговора" }
            else -> if (npc.plan.isBlank()) npc.plan = "наблюдать"
        }
        npc.trust = npc.trust.coerceIn(-5, 5)
        npc.affection = npc.affection.coerceIn(-5, 5)
        npc.fearOfPc = npc.fearOfPc.coerceIn(0, 5)

        // красота
        val beautyLine = beautyReaction(c.beauty, npc, sexual, talk, rng)

        // фетиши / власть (только adult+)
        val kinkLine = if (c.mode != "child" && (sexual || TextFuzzy.containsLike(raw, listOf("приказ", "на колени", "господин", "госпожа", "раб")))) {
            kinkReaction(c, npc, raw, rng)
        } else ""

        // правила партии реально влияют
        val rulesLine = applyRulesToScene(c, violent, sexual, talk)

        // катастрофы
        val disasterLine = maybeDisaster(c, turn, rng)

        val actionBlock = narrateAction(c, raw, npc, violent, sexual, talk)

        val hostile = false // Случайная драка не запускается вместо ответа на действие игрока.

        val body = if (hostile) {
            c.worldTension = (c.worldTension + 3).coerceAtMost(100)
            "Тревога: ${listOf("разбойники", "волки", "гоблины", "дезертиры", "пьяная драка").random(rng)} у $site.\n" +
                (if (violent) "Схватка на грани — добей, беги, торгуйся или блефуй."
                else "Они смотрят на тебя. Оружие, бегство или переговоры.")
        } else {
            buildString {
                // Внутренние параметры NPC остаются в памяти движка, а игрок видит только реакцию.
                when {
                    violent -> appendLine("${npc.name} резко отступает, прикрываясь рукой. Взгляд становится настороженным.")
                    generous -> appendLine("${npc.name} замечает твой жест и на мгновение смягчается, хотя всё ещё оценивает, чего ты ждёшь взамен.")
                    talk -> appendLine("${npc.name} поворачивается к тебе и внимательно слушает.")
                    else -> appendLine("${npc.name} следит за твоими движениями, пытаясь понять, чего ты добиваешься.")
                }
                if (talk || violent || sexual) appendLine(npcReply(c, npc, raw, rng, talk, violent, sexual))
                else appendLine(pickLine(npc, raw, rng))
                if (beautyLine.isNotBlank() && (c.beauty >= 9 || c.beauty <= 2) && talk) appendLine(beautyLine)
                if (kinkLine.isNotBlank()) appendLine(kinkLine)
            }
        }

        // цепочка последствий NPC
        val chain = npcChain(c, npc, turn, rng)
        val offer = MarriageLogic.maybeNpcOffer(c, npc.name, npc.rank, npc.personality, npc.affection, turn, rng)

        return buildString {
            if (turn == 1 || c.lastActionIntent.isBlank()) {
                appendLine("${cap(c.season)}. ${cap(weather.random(rng))}. ${cap(b.sounds.random())}; пахнет ${b.smells.random()}.")
                appendLine("Место: $site.")
            }
            if (rulesLine.isNotBlank()) appendLine(rulesLine)
            if (executedCheck != null) appendLine(executedCheck.displayLine())
            if (disasterLine.isNotBlank()) { appendLine(); appendLine(disasterLine) }
            appendLine()
            appendLine(actionBlock)
            appendLine()
            append(body.trim())
            if (chain.isNotBlank()) { appendLine(); appendLine(chain) }
            if (offer.isNotBlank()) { appendLine(); appendLine(offer) }
            appendLine()
            if (c.hp < c.maxHp) appendLine("HP: ${c.hp}/${c.maxHp}")
            appendLine("Мир: напряжение ${c.worldTension}, достаток ${c.worldProsperity}, страх ${c.worldFear}.")
            appendLine("— Ход $turn")
        }.trim().also {
            c.lastActionIntent = when {
                talk -> "разговор: ${raw.take(100)}"
                generous -> "помощь/ресурсы: ${raw.take(100)}"
                violent -> "насилие: ${raw.take(100)}"
                else -> raw.take(120)
            }
            val memoryLine = "Ход $turn у ${c.lastLocation}: ${c.heroName} — ${c.lastActionIntent}. NPC ${npc.name}: доверие ${npc.trust}, симпатия ${npc.affection}, страх ${npc.fearOfPc}/5. Мир T${c.worldTension}/P${c.worldProsperity}/F${c.worldFear}."
            c.campaignMemory = (c.campaignMemory.lines().filter { it.isNotBlank() } + memoryLine).takeLast(12).joinToString("\n")
            persistNpc(c, npc)
            logWorld(c, turn, "${c.heroName}: ${c.lastActionIntent}", "память")
        }
    }

    private fun beautyReaction(beauty: Int, npc: NpcLive, sexual: Boolean, talk: Boolean, rng: Random): String {
        return when {
            beauty >= 9 -> listOf(
                "${npc.name} смотрит дольше приличия. В голосе проскальзывает осторожное уважение к красивому лицу — не к твоим словам.",
                "Такая внешность здесь редкость: кто-то завидует, кто-то хочет приблизиться, кто-то уже считает тебя опасным соблазном."
            ).random(rng)
            beauty >= 7 -> listOf(
                "${npc.name} отмечает твою внешность мягче обычного тона.",
                "Приятное лицо чуть открывает дверь — но характер и статус всё ещё важнее."
            ).random(rng)
            beauty <= 2 -> listOf(
                "На лицо почти не смотрят. Оценивают руки, одежду, угрозу.",
                "${npc.name} отвечает сухо: внешность не даёт тебе кредита доверия."
            ).random(rng)
            beauty <= 4 -> "${npc.name} смотрит мимо черт лица — на поступки."
            else -> "Внешность обычная: ни плюса, ни минуса. Решают слова и дела."
        } + if (sexual && beauty >= 7) " В интимной сцене это усиливает притяжение, но не отменяет страха и расчёта." else ""
    }

    private fun kinkReaction(c: Campaign, npc: NpcLive, raw: String, rng: Random): String {
        if (npc.kinkTags.isEmpty()) return if (c.mode == "uncensored")
            "${npc.name} реагирует на власть/близость осторожно: склонности не совпали или ещё скрыты."
        else ""
        val tag = npc.kinkTags.random(rng)
        return when (tag) {
            "власть", "форма_власти", "роль_господин_слуга" ->
                "В ${npc.name} просыпается интерес к иерархии: «${npc.rank}» и твой тон задевают старую струну ($tag)."
            "подчинение" ->
                if (TextFuzzy.containsLike(raw, listOf("приказ", "на колени", "служи")))
                    "${npc.name} чуть склоняет голову — не из страха, а из тёмного согласия ($tag)."
                else "${npc.name} ловит себя на желании уступить сильному ($tag)."
            "сословная_разница" ->
                "Разница статусов («${npc.status}» vs путник) возбуждает или злит ${npc.name} — $tag."
            "плен" ->
                if (c.mode == "uncensored") "${npc.name} сглатывает при намёке на захват/силу ($tag)." else ""
            "нежность", "забота_после" ->
                "${npc.name} неожиданно отвечает мягче, чем позволял статус ($tag)."
            "грубость", "унижение_словесное" ->
                if (c.mode == "uncensored") "${npc.name} вспыхивает на грубость — злостью или странным жаром ($tag)." else ""
            else -> "Скрытая склонность ($tag) едва заметно меняет дыхание ${npc.name}."
        }
    }

    private fun applyRulesToScene(c: Campaign, violent: Boolean, sexual: Boolean, talk: Boolean): String {
        val r = c.customRules.lowercase()
        if (r.isBlank()) return ""
        val bits = mutableListOf<String>()
        if ("последств" in r && violent) bits += "Правило партии: насилие имеет последствия — мир уже сдвинулся."
        if ("отдых" in r && TextFuzzy.containsLike(c.messages.lastOrNull { it.role == "user" }?.content ?: "", listOf("спать", "отдых", "лагерь")))
            bits += "По вашим правилам отдых восстанавливает силы лишь постепенно."
        if (("без магии" in r || "магии нет" in r) && TextFuzzy.containsLike(c.messages.lastOrNull()?.content ?: "", listOf("заклин", "магия", "колдов")))
            bits += "По лору/правилам магия здесь слаба или запретна — эффект срывается в искру и дым."
        if ("честь" in r && talk) bits += "В этом мире честь на виду: ложь может стоить репутации."
        if (c.worldLore.isNotBlank() && Random.nextDouble() < 0.2)
            bits += "Лор напоминает о себе: ${c.worldLore.take(90)}"
        return bits.joinToString(" ")
    }

    private fun maybeDisaster(c: Campaign, turn: Int, rng: Random): String {
        if (turn - c.lastDisasterTurn < 8) return ""
        val stress = c.worldTension / 100.0 + c.worldFear / 150.0
        for ((id, base, text) in disasters) {
            val chance = base + stress * 0.03
            if (rng.nextDouble() < chance) {
                c.lastDisasterTurn = turn
                c.worldTension = (c.worldTension + 12).coerceAtMost(100)
                c.worldFear = (c.worldFear + 10).coerceAtMost(100)
                c.worldProsperity = (c.worldProsperity - 8).coerceAtLeast(0)
                logWorld(c, turn, text, "disaster")
                c.worldFlags = (c.worldFlags.split("|").filter { it.isNotBlank() } + id).distinct().joinToString("|")
                return "⚠ Катастрофа: $text"
            }
        }
        return ""
    }

    private fun npcChain(c: Campaign, npc: NpcLive, turn: Int, rng: Random): String {
        // логические цепочки: что NPC сделает дальше в мире
        return when {
            npc.fearOfPc >= 4 && npc.role in listOf("стражник", "дворянин", "жрец") -> {
                logWorld(c, turn, "${npc.name} (${npc.rank}) готовит жалобу или донос.", "social")
                "Цепочка: ${npc.name} унесёт слух выше по иерархии. Жди патруль или вызов."
            }
            npc.trust <= -3 && npc.role == "вор" -> {
                logWorld(c, turn, "Воры метят путника после конфликта.", "social")
                "Цепочка: ночью возможен карманный вор или месть гильдии."
            }
            npc.affection >= 4 && rng.nextDouble() < 0.3 -> {
                "Цепочка: ${npc.name} может стать союзником — предложит кров, имя или сделку."
            }
            c.worldTension > 70 && rng.nextDouble() < 0.25 -> {
                "Цепочка: край на нервах. Даже нейтральные NPC сегодня резче обычного."
            }
            else -> ""
        }
    }

    private fun narrateAction(c: Campaign, raw: String, npc: NpcLive, violent: Boolean, sexual: Boolean, talk: Boolean): String {
        val q = raw.take(240)
        return when (c.mode) {
            "child" -> when {
                violent || sexual -> "Жёсткое/взрослое действие смягчается правилами детского режима."
                talk -> "Ты говоришь ${npc.name}: «$q»."
                else -> "Ты делаешь: $q."
            }
            "uncensored" -> when {
                sexual -> "Ты идёшь в плоть и власть: $q. Прямо, без купюр (18+)."
                violent -> "Ты обрушиваешь силу: $q. Боль, звук, последствия."
                talk -> "Ты говоришь ${npc.name}: «$q»."
                else -> "Ты действуешь: $q."
            }
            else -> when {
                sexual -> "Ты сближаешься: $q. Тело и эмоции есть; детали — по твоим словам."
                violent -> "Ты применяешь силу: $q."
                talk -> "Ты говоришь ${npc.name}: «$q»."
                else -> "Ты делаешь: $q."
            }
        }
    }

    private fun pickLine(npc: NpcLive, raw: String, rng: Random): String {
        if (TextFuzzy.isGreeting(raw)) return listOf("— Ну здравствуй.", "— Привет. Говори.", "— Добро.").random(rng)
        return npc.lines.random(rng)
    }

    private fun npcReply(c: Campaign, npc: NpcLive, raw: String, rng: Random, talk: Boolean, violent: Boolean, sexual: Boolean): String {
        if (violent) {
            val intent = "Ещё шаг — и отвечу железом. Я ${npc.rank}, меня не так просто сломать."
            return SocialSpeech.speak(npc.rank, npc.status, npc.personality, true, c, intent, rng) +
                "\n(${npc.speechStyle})"
        }
        if (!talk && !sexual) return "Ждёт твоего хода. Можно говорить, уйти, предложить сделку, союз — или рискнуть."
        val intent = when {
            TextFuzzy.containsLike(raw, listOf("помощь", "помоги")) ->
                "Помощь стоит. Я ${npc.status}: просто так доброту не раздаю."
            TextFuzzy.containsLike(raw, listOf("кто", "имя")) ->
                "${npc.name}. ${npc.profession}, ${npc.rank}."
            TextFuzzy.containsLike(raw, listOf("купить", "продать", "цена")) ->
                "Торг возможен. Ранг «${npc.rank}» обязывает считать монеты."
            sexual && c.mode != "child" ->
                if (npc.affection + (if (c.beauty >= 7) 1 else 0) >= 2)
                    "Ты прямолинеен… Это опасно. И цепляет."
                else
                    "Не так быстро. Статус и голова ещё при мне."
            TextFuzzy.isGreeting(raw) ->
                when {
                    SocialSpeech.playerWeight(c) - SocialSpeech.rankWeight(npc.rank) >= 30 -> "Здравствуйте… не ожидал(а) такой крови здесь."
                    SocialSpeech.rankWeight(npc.rank) - SocialSpeech.playerWeight(c) >= 30 -> "Ну здравствуй, путник."
                    else -> "Здравствуй. Говори."
                }
            else -> listOf("Слушаю.", "И что с того?", "Продолжай.", "Хм.", "Говори яснее.").random(rng)
        }
        val spoken = SocialSpeech.speak(npc.rank, npc.status, npc.personality, true, c, intent, rng)
        return spoken
    }

    private fun divineAscensionScene(c: Campaign, raw: String): String {
        val path = c.mythicalAscension.ifBlank {
            "По умолчанию: подвиг, культ, кровь предка или ритуал — если прописано в лоре."
        }
        return buildString {
            appendLine("══ Путь вознесения ══")
            appendLine("Сейчас ты: ${c.divineTier}.")
            appendLine("Твои мифические черты: ${c.mythicalTraits.ifBlank { "—" }}")
            appendLine("Правила вознесения (твои): $path")
            appendLine()
            appendLine("Действие: «${raw.take(200)}»")
            appendLine(
                when (c.divineTier.lowercase()) {
                    "смертный" -> "Мир ещё не признаёт в тебе божество. Нужны знамения, вера, кровь или условие из твоих правил."
                    "полубог" -> "Полубожественность уже давит на смертных: стража нервничает, жрецы шепчутся. До полного бога — шаг по твоим правилам."
                    else -> "Божественный статус ощутим: простолюдины склоняются, знать считает политику."
                }
            )
            if (c.raceTraits.isNotBlank()) appendLine("Раса (${c.race}): ${c.raceTraits}")
            if (c.classTraits.isNotBlank()) appendLine("Класс (${c.heroClass}): ${c.classTraits}")
            appendLine("Можешь сменить tier в новой партии или описать ритуал — мастер учтёт текст вознесения.")
            appendLine("════════════════")
        }.trim()
    }

    fun characterSheet(c: Campaign): String {
        val classLine = if (c.multiclass.isNotBlank()) "${c.heroClass}/${c.multiclass}" else c.heroClass
        return buildString {
            appendLine("══ Лист героя ══")
            appendLine("${c.heroName} · ${c.race} · $classLine ${c.level}/${c.maxLevel}")
            appendLine("Статус: ${c.socialRank} · богатство ${c.wealth}/10 · ${c.divineTier}")
            appendLine("${c.alignment} · красота ${c.beauty}/10 · вес в мире ~${SocialSpeech.playerWeight(c)}")
            appendLine("Внешность: ${c.appearance.ifBlank { generateHeroAppearance(c) }}")
            appendLine("Черты: ${c.traits.ifBlank { "—" }}")
            appendLine("Мифические черты: ${c.mythicalTraits.ifBlank { "—" }}")
            appendLine("Вознесение: ${c.mythicalAscension.ifBlank { "—" }}")
            appendLine("Механики расы: ${c.raceTraits.ifBlank { "—" }}")
            appendLine("Механики класса: ${c.classTraits.ifBlank { "—" }}")
            appendLine("Навыки: ${c.skills.ifBlank { "—" }}")
            appendLine("Предыстория: ${c.backstory.ifBlank { "—" }}")
            c.stats.forEach { (k, v) -> appendLine("  $k $v (${modStr(v)})") }
            appendLine("HP ${c.hp}/${c.maxHp}")
            appendLine("Правила: ${c.customRules.ifBlank { "—" }}")
            appendLine("Контракты: ${c.customContracts.ifBlank { "—" }}")
            appendLine("Лор: ${c.worldLore.ifBlank { "—" }}")
            appendLine("════════════════")
        }.trim()
    }

    fun npcSheet(c: Campaign, request: String): String {
        val list = campaignNpcs[c.id].orEmpty()
        if (list.isEmpty()) return "NPC ещё не встречены."
        val n = TextFuzzy.normalize(request)
        val found = list.lastOrNull {
            n.contains(TextFuzzy.normalize(it.name)) || n.contains(TextFuzzy.normalize(it.role)) ||
                TextFuzzy.containsLike(n, listOf(it.name, it.role, it.profession))
        } ?: list.last()
        return buildString {
            appendLine("══ Лист NPC ══")
            appendLine("${found.name} · ${found.sex} · ~${found.age} лет")
            appendLine("Профессия: ${found.profession}")
            appendLine("Ранг/должность: ${found.rank}")
            appendLine("Статус: ${found.status}")
            appendLine("Личность: ${found.personality} (${found.traits.joinToString()})")
            appendLine("Красота: ${found.beauty}/10")
            appendLine("Внешность: ${found.appearance}")
            appendLine("Речь: ${found.speechStyle}")
            appendLine("Цель: ${found.goal} · Страх: ${found.fear}")
            appendLine("План сейчас: ${found.plan.ifBlank { "—" }}")
            appendLine("К тебе: доверие ${found.trust}, симпатия ${found.affection}, страх ${found.fearOfPc}")
            if (c.mode != "child" && found.kinkTags.isNotEmpty())
                appendLine("Скрытые склонности: ${found.kinkTags.joinToString()}")
            appendLine("════════════════")
        }.trim()
    }

    private fun worldReport(c: Campaign): String = buildString {
        appendLine("══ Состояние мира ══")
        appendLine("Напряжение ${c.worldTension}/100 · Достаток ${c.worldProsperity}/100 · Страх ${c.worldFear}/100")
        if (c.worldLore.isNotBlank()) appendLine("Лор: ${c.worldLore}")
        if (c.customRules.isNotBlank()) appendLine("Правила: ${c.customRules}")
        if (c.worldFlags.isNotBlank()) appendLine("Метки: ${c.worldFlags}")
        val log = c.worldLog.split("\n").filter { it.isNotBlank() }.takeLast(8)
        if (log.isNotEmpty()) {
            appendLine("Недавние события:")
            log.forEach { appendLine("· $it") }
        } else appendLine("Крупных событий пока не зафиксировано.")
        appendLine("════════════════")
    }

    private fun statusBlock(c: Campaign) =
        "${c.heroName} HP ${c.hp}/${c.maxHp}. ${c.lastLocation}. Рядом: ${c.lastNpc}. Мир T${c.worldTension}/P${c.worldProsperity}/F${c.worldFear}."

    private fun helpText() = """
Команды: лист · лист нпс · статус · мир · помощь\nБрак/союз — напиши «предлагаю брак» или «заключить союз».\nВознесение — «стать полубогом» / «вознесение».

Пиши действия обычным текстом, можно длинно.
Красота, ранг NPC, лор и правила партии влияют на ответы.
Насилие качает напряжение мира; катастрофы приходят сами.
""".trim()

    private fun ensureNpc(c: Campaign): NpcLive {
        val bag = campaignNpcs.getOrPut(c.id) { mutableListOf() }
        if (bag.isNotEmpty()) return bag.last()
        if (c.npcMemory.isNotBlank()) {
            try {
                val o = JSONObject(c.npcMemory)
                val restored = NpcLive(
                    id = o.optString("id", "N1"), name = o.optString("name", "Незнакомец"),
                    role = o.optString("role", "путник"), rank = o.optString("rank", "обычный"),
                    status = o.optString("status", "путник"), profession = o.optString("profession", "путник"),
                    sex = o.optString("sex", "м"), age = o.optInt("age", 30), appearance = o.optString("appearance", ""),
                    beauty = o.optInt("beauty", 5), personality = o.optString("personality", "осторожный реалист"),
                    traits = o.optString("traits").split("|").filter { it.isNotBlank() },
                    speechStyle = o.optString("speechStyle", "по делу"), goal = o.optString("goal", "выжить"),
                    fear = o.optString("fear", "неизвестность"), kinkTags = o.optString("kinkTags").split("|").filter { it.isNotBlank() },
                    lines = listOf("— Говори. Я помню наш разговор."), affection = o.optInt("affection"),
                    trust = o.optInt("trust"), fearOfPc = o.optInt("fearOfPc"), plan = o.optString("plan")
                )
                bag.add(restored)
                return restored
            } catch (_: Exception) { /* corrupted NPC snapshot: generate a fresh NPC safely */ }
        }
        val def = roles.random()
        val rng = Random((c.id + def.role + bag.size).hashCode())
        val sex = if (rng.nextBoolean()) "ж" else "м"
        val name = if (sex == "ж") def.namesF.random(rng) else def.namesM.random(rng)
        val rank = def.ranks.random(rng)
        val status = def.statuses.random(rng)
        val (pers, traits) = personalities.random(rng)
        val beauty = rng.nextInt(2, 10)
        val age = rng.nextInt(18, 65)
        val kinks = if (c.mode == "child") emptyList()
        else kinkPool.shuffled(rng).take(rng.nextInt(1, 4))
        val speech = when {
            "строг" in pers || def.role == "жрец" -> "коротко, с давлением статуса"
            "цинич" in pers || def.role == "вор" -> "с усмешкой"
            "властн" in pers -> "приказами и паузами"
            "покорн" in pers -> "тише, с оглядкой"
            else -> "по делу"
        }
        val npc = NpcLive(
            id = "N${bag.size + 1}", name = name, role = def.role, rank = rank, status = status,
            profession = def.profession, sex = sex, age = age,
            appearance = genAppearance(sex, age, beauty, rng), beauty = beauty,
            personality = pers, traits = traits, speechStyle = speech,
            goal = def.goals.random(rng), fear = def.fears.random(rng),
            kinkTags = kinks,
            lines = listOf("— Чего надо?", "— Говори.", "— Не стой на проходе.", "— Смотрю и не пойму — друг ты или беда.")
        )
        bag.add(npc)
        if (bag.size > 16) bag.removeAt(0)
        return npc
    }

    private fun persistNpc(c: Campaign, n: NpcLive) {
        c.npcMemory = JSONObject()
            .put("id", n.id).put("name", n.name).put("role", n.role).put("rank", n.rank)
            .put("status", n.status).put("profession", n.profession).put("sex", n.sex).put("age", n.age)
            .put("appearance", n.appearance).put("beauty", n.beauty).put("personality", n.personality)
            .put("traits", n.traits.joinToString("|")).put("speechStyle", n.speechStyle)
            .put("goal", n.goal).put("fear", n.fear).put("kinkTags", n.kinkTags.joinToString("|"))
            .put("affection", n.affection).put("trust", n.trust).put("fearOfPc", n.fearOfPc).put("plan", n.plan).toString()
        c.lastNpc = "${n.role} ${n.name}"
    }

    fun generateHeroAppearance(c: Campaign) = genAppearance("?", 25, c.beauty, Random(c.heroName.hashCode()))

    private fun genAppearance(sex: String, age: Int, beauty: Int, rng: Random): String {
        val sexW = when (sex) { "ж" -> "женщина"; "м" -> "мужчина"; else -> "человек" }
        val bW = when { beauty >= 8 -> "заметная красота"; beauty <= 3 -> "резкая/непримечательная внешность"; else -> "обычные черты" }
        return "$sexW ~$age, ${builds.random(rng)}, ${hairColors.random(rng)} волосы, ${eyeColors.random(rng)} глаза, ${faces.random(rng)}, ${clothes.random(rng)}. $bW."
    }

    private fun applyLoreFlags(c: Campaign) {
        val lore = (c.worldLore + " " + c.customRules).lowercase()
        if ("война" in lore) c.worldTension = maxOf(c.worldTension, 40)
        if ("голод" in lore) c.worldProsperity = minOf(c.worldProsperity, 35)
        if ("чума" in lore || "эпидем" in lore) c.worldFear = maxOf(c.worldFear, 40)
    }

    private fun logWorld(c: Campaign, turn: Int, text: String, kind: String) {
        val line = "Х$turn/$kind: $text"
        val lines = (c.worldLog.split("\n").filter { it.isNotBlank() } + line).takeLast(30)
        c.worldLog = lines.joinToString("\n")
    }

    private fun biomeOf(l: String) = biomes.entries.firstOrNull { it.key in l.lowercase() }?.value ?: biomes.getValue("лес")
    private fun modStr(s: Int): String { val m = (s - 10) / 2; return if (m >= 0) "+$m" else "$m" }
    private fun cap(s: String) = if (s.isEmpty()) s else s[0].titlecaseChar() + s.substring(1)
    private fun <T> List<T>.random(rng: Random) = this[rng.nextInt(size)]
}
