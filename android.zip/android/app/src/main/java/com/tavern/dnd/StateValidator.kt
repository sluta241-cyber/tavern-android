package com.tavern.dnd

/** Validates durable numeric invariants without rewriting the player's selected content mode. */
object StateValidator {
    data class Report(val valid: Boolean, val issues: List<String>)

    fun validate(c: Campaign): Report {
        val issues = mutableListOf<String>()
        if (c.maxHp < 1) issues += "maxHp must be positive"
        if (c.hp !in 0..c.maxHp) issues += "hp outside 0..maxHp"
        if (c.level !in 1..c.maxLevel.coerceAtLeast(1)) issues += "level outside configured range"
        if (c.combatActive && c.combatEnemyMaxHp < 1) issues += "active combat has no valid enemy max HP"
        if (c.combatActive && c.combatEnemyHp !in 0..c.combatEnemyMaxHp) issues += "enemy HP outside valid range"
        if (c.deathSaveSuccesses !in 0..3 || c.deathSaveFailures !in 0..3) issues += "death-save counters outside 0..3"
        if (c.characterDead && c.hp > 0) issues += "dead character has positive HP"
        if (c.worldTension !in 0..100 || c.worldFear !in 0..100 || c.worldProsperity !in 0..100) issues += "world meter outside 0..100"
        return Report(issues.isEmpty(), issues)
    }

    /** Only clamps impossible numeric values; textual settings, including c.mode, are untouched. */
    fun repairNumericInvariants(c: Campaign) {
        c.maxHp = c.maxHp.coerceAtLeast(1)
        c.hp = c.hp.coerceIn(0, c.maxHp)
        c.maxLevel = c.maxLevel.coerceIn(1, 20)
        c.level = c.level.coerceIn(1, c.maxLevel)
        c.combatEnemyMaxHp = c.combatEnemyMaxHp.coerceAtLeast(0)
        c.combatEnemyHp = c.combatEnemyHp.coerceIn(0, c.combatEnemyMaxHp.coerceAtLeast(0))
        // An active encounter without a valid enemy cannot progress; close the broken encounter
        // instead of leaving the player trapped in a combat state with no target.
        if (c.combatActive && (c.combatEnemyMaxHp < 1 || c.combatEnemyName.isBlank())) {
            c.combatActive = false
            c.combatEnemyName = ""
            c.combatEnemyHp = 0
            c.combatEnemyMaxHp = 0
            c.combatPlayerDodging = false
            c.combatInitiative = ""
        }
        c.deathSaveSuccesses = c.deathSaveSuccesses.coerceIn(0, 3)
        c.deathSaveFailures = c.deathSaveFailures.coerceIn(0, 3)
        if (c.characterDead) c.hp = 0
        c.worldTension = c.worldTension.coerceIn(0, 100)
        c.worldFear = c.worldFear.coerceIn(0, 100)
        c.worldProsperity = c.worldProsperity.coerceIn(0, 100)
    }
}
