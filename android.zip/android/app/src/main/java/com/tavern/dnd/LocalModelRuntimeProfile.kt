package com.tavern.dnd

import android.app.ActivityManager
import android.content.Context
import kotlin.math.max
import kotlin.math.min

/**
 * Conservative, RAM-aware defaults for the future llama.cpp Android backend.
 * These values do not start inference by themselves; the JNI adapter must consume them.
 * Keep defaults intentionally modest so mid-range phones remain responsive.
 */
object LocalModelRuntimeProfile {
    data class Profile(
        val modelId: String,
        val contextTokens: Int,
        val maxNewTokens: Int,
        val batchTokens: Int,
        val threads: Int,
        val useGpu: Boolean,
        val keepModelLoaded: Boolean,
        val recommendedMinRamMb: Long,
        val explanation: String
    )

    fun forDevice(context: Context): Profile {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryClassMb = (am?.memoryClass ?: 128).toLong()
        // Use memoryClass, not physical RAM: it is a conservative Android app-heap signal.
        val ramMb = memoryClassMb
        val processors = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)

        // Do not use all cores: leave headroom for Android, audio, UI and game-state logic.
        val threads = min(4, max(2, processors - 2))
        return when {
            ramMb < 192L -> Profile(
                modelId = LocalModelStore.MODEL_ID,
                contextTokens = 1024,
                maxNewTokens = 192,
                batchTokens = 32,
                threads = 2,
                useGpu = false,
                keepModelLoaded = false,
                recommendedMinRamMb = 192,
                explanation = "Экономный режим: короткий контекст и ответы, модель не держится в памяти между ходами."
            )
            ramMb < 320L -> Profile(
                modelId = LocalModelStore.MODEL_ID,
                contextTokens = 1536,
                maxNewTokens = 256,
                batchTokens = 64,
                threads = min(3, threads),
                useGpu = false,
                keepModelLoaded = false,
                recommendedMinRamMb = 192,
                explanation = "Сбалансированный режим для телефона со скромным запасом памяти."
            )
            else -> Profile(
                modelId = LocalModelStore.MODEL_ID,
                contextTokens = 2048,
                maxNewTokens = 320,
                batchTokens = 96,
                threads = threads,
                useGpu = false,
                keepModelLoaded = true,
                recommendedMinRamMb = 192,
                explanation = "Обычный режим: умеренный контекст, ограниченная параллельность и запас для интерфейса."
            )
        }
    }
}
