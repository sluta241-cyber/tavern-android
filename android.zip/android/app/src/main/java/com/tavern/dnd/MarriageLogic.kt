package com.tavern.dnd

import kotlin.random.Random

object MarriageLogic {

    fun tryPlayerProposal(c: Campaign, npcName: String, npcRank: String, npcRole: String, turn: Int): String {
        val pw = SocialSpeech.playerWeight(c)
        val nw = SocialSpeech.rankWeight(npcRank)
        val (ok, reason) = SocialSpeech.marriagePlausible(pw, nw, c.customRules + " " + c.customContracts)
        val line = if (ok) {
            val contract = if (c.customContracts.isNotBlank())
                "Условия из ваших контрактов: ${c.customContracts.take(120)}"
            else
                "Обычный союз: взаимные обязательства, статус, возможный выкуп или клятва."
            log(c, turn, "Ты предложил(а) союз $npcName ($npcRole, $npcRank). $reason")
            buildString {
                appendLine("Ты делаешь брачное / союзное предложение $npcName.")
                appendLine(reason)
                appendLine(contract)
                appendLine(
                    when {
                        nw >= 60 -> "$npcName бледнеет от серьёзности момента: такие слова у знати не бросают в шутку."
                        SocialSpeech.rankWeight(c.socialRank) >= 60 -> "Нижестоящий слышит предложение сверху — это честь и ловушка одновременно."
                        else -> "$npcName молчит, взвешивая выгоду, страх и характер."
                    }
                )
                appendLine("Ответ зависит от доверия, симпатии и политики. Можно уточнить условия.")
            }
        } else {
            log(c, turn, "Отказ по статусу: $npcName. $reason")
            buildString {
                appendLine("Предложение звучит… неуместно.")
                appendLine(reason)
                appendLine(
                    if (nw > pw) "$npcName (ранг «$npcRank») смотрит с холодной вежливостью или насмешкой: королевская кровь / высокий дом не отдаёт руку без веса."
                    else "Разница статусов мешает. Нужен другой рычаг — подвиг, титул, богатство, божественность."
                )
            }
        }
        return line.trim()
    }

    fun maybeNpcOffer(c: Campaign, npcName: String, npcRank: String, personality: String, affection: Int, turn: Int, rng: Random): String {
        if (affection < 3) return ""
        if (rng.nextDouble() > 0.12) return ""
        val pw = SocialSpeech.playerWeight(c)
        val nw = SocialSpeech.rankWeight(npcRank)
        val (ok, reason) = SocialSpeech.marriagePlausible(nw, pw, c.customRules + " " + c.customContracts)
        // Король/высокий дом не предлагает дочь крестьянину
        if (!ok && nw >= 50 && pw < 40) {
            return "" // молчит — не делает глупого предложения
        }
        if (!ok) return ""
        log(c, turn, "$npcName намекает на союз. $reason")
        val tone = when {
            nw >= 60 -> "сдержанно, почти как о политике"
            "гордец" in personality || "властн" in personality -> "как о выгодном захвате"
            "добрый" in personality -> "мягко, с надеждой"
            else -> "осторожно"
        }
        return buildString {
            appendLine("✦ $npcName $tone заговаривает о постоянном союзе — браке, контракте или клятве.")
            appendLine(reason)
            if (c.customContracts.isNotBlank()) appendLine("В мире действуют ваши формы контрактов: ${c.customContracts.take(100)}")
            if (c.divineTier != "смертный") appendLine("Твоя природа (${c.divineTier}) делает предложение политически весомым.")
            appendLine("Можно согласиться, торговаться об условиях или отвергнуть.")
        }.trim()
    }

    private fun log(c: Campaign, turn: Int, text: String) {
        val line = "Х$turn: $text"
        c.marriageLog = (c.marriageLog.split("\n").filter { it.isNotBlank() } + line).takeLast(20).joinToString("\n")
    }
}
