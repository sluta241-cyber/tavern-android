package com.tavern.dnd

import java.util.Locale

/**
 * Conservative, offline extraction of NPC knowledge claims from PLAYER-AUTHORED text only.
 * This deliberately handles a few explicit Russian constructions instead of guessing from
 * arbitrary narration or from the model's reply.
 */
object NpcKnowledgeExtractor {
    data class Claim(
        val npcName: String,
        val fact: String,
        val certainty: String,
        val source: String
    )

    private val transferVerbs = "(?:рассказал(?:а)?|сообщил(?:а)?|сказал(?:а)?|объяснил(?:а)?|предупредил(?:а)?|признал(?:а)?)"
    private val observeVerbs = "(?:видел(?:а)?|наблюдал(?:а)?|заметил(?:а)?|присутствовал(?:а)?\\s+при)"
    private val rumorVerbs = "(?:слышал(?:а)?|услышал(?:а)?)"

    fun extract(playerText: String, knownNpcNames: List<String>, maxClaims: Int = 5): List<Claim> {
        val text = playerText.trim()
        if (text.isBlank() || knownNpcNames.isEmpty()) return emptyList()
        val claims = mutableListOf<Claim>()
        val rawCandidates = knownNpcNames.map { it.trim() }
            .filter { it.length >= 2 }
            .distinctBy { normalize(it) }
        // A role-prefixed active label is removed by knownNames() when its profile already exists.
        // If multiple durable candidates still share a final name, skip the alias as ambiguous.
        val candidates = rawCandidates.groupBy { normalize(it.split(Regex("\\s+")).lastOrNull().orEmpty()) }
            .values.mapNotNull { group -> if (group.size == 1) group.first() else null }

        for (npcName in candidates) {
            val alias = npcName.split(Regex("\\s+")).lastOrNull().orEmpty()
            if (alias.length < 2) continue
            val variants = nameVariants(alias).sortedByDescending { it.length }
            val namePattern = variants.joinToString("|") { Regex.escape(it) }

            val transfer = Regex(
                "(?iu)(?<![\\p{L}])(?:я\\s+)?$transferVerbs\\s+(?:нпс\\s+)?(?:этому\\s+|этой\\s+)?(?:$namePattern)\\s*,?\\s*(?:что|о\\s+том,?\\s+что)\\s+([^.!?\\n]{3,260})"
            )
            transfer.findAll(text).forEach { match ->
                if (isNegatedOrHypothetical(text, match.range.first) || insideQuotes(text, match.range.first)) return@forEach
                val fact = cleanFact(match.groupValues[1]) ?: return@forEach
                claims += Claim(npcName, fact, "told", "герой сообщил NPC (явно описано игроком)")
            }

            val observed = Regex(
                "(?iu)(?<![\\p{L}])(?:$namePattern)\\s+$observeVerbs\\s*,?\\s*(?:как\\s+)?([^.!?\\n]{3,260})"
            )
            observed.findAll(text).forEach { match ->
                if (isNegatedOrHypothetical(text, match.range.first) || insideQuotes(text, match.range.first)) return@forEach
                val fact = cleanFact(match.groupValues[1]) ?: return@forEach
                claims += Claim(npcName, fact, "observed", "личное наблюдение NPC (явно описано игроком)")
            }

            val rumor = Regex(
                "(?iu)(?<![\\p{L}])(?:$namePattern)\\s+$rumorVerbs\\s+слух(?:и)?\\s*,?\\s*(?:о\\s+том,?\\s+)?что\\s+([^.!?\\n]{3,260})"
            )
            rumor.findAll(text).forEach { match ->
                if (isNegatedOrHypothetical(text, match.range.first) || insideQuotes(text, match.range.first)) return@forEach
                val fact = cleanFact(match.groupValues[1]) ?: return@forEach
                claims += Claim(npcName, fact, "rumor", "слух, явно описанный игроком")
            }

            val toldByOthers = Regex(
                "(?iu)(?<![\\p{L}])(?:$namePattern)\\s+(?:сообщили|сказали|рассказали)\\s*,?\\s*(?:что|о\\s+том,?\\s+что)\\s+([^.!?\\n]{3,260})"
            )
            toldByOthers.findAll(text).forEach { match ->
                if (isNegatedOrHypothetical(text, match.range.first) || insideQuotes(text, match.range.first)) return@forEach
                val fact = cleanFact(match.groupValues[1]) ?: return@forEach
                claims += Claim(npcName, fact, "told", "неуказанный источник, явно описанный игроком")
            }
        }

        return claims.distinctBy { normalize(it.npcName) + "|" + normalize(it.fact) + "|" + it.certainty }
            .take(maxClaims.coerceIn(1, 10))
    }

    /**
     * A reply is never a source of knowledge; it may only veto an extraction when it explicitly
     * says the described transfer/observation did not happen. This is intentionally narrow.
     */
    fun replyExplicitlyVetoes(reply: String, claim: Claim): Boolean {
        val normalized = normalize(reply)
        if (normalized.startsWith("ошибка ") || normalized.startsWith("error ")) return true
        val name = normalize(claim.npcName).split(" ").lastOrNull().orEmpty()
        val nameMentioned = nameVariants(name).any { variant ->
            Regex("(?:^|[^\\p{L}\\p{N}])${Regex.escape(normalize(variant))}(?=$|[^\\p{L}\\p{N}])").containsMatchIn(normalized)
        }
        if (!nameMentioned) return false
        val vetoes = when (claim.certainty) {
            "told" -> listOf("не удалось рассказать", "не получилось рассказать", "не смог рассказать", "не смогла рассказать", "не успел рассказать", "не успела рассказать", "не смог сообщить", "не смогла сообщить", "не услышал", "не услышала", "слова не дошли", "не дошли слова")
            "observed" -> listOf("не видел", "не видела", "не наблюдал", "не наблюдала", "не заметил", "не заметила", "не присутствовал", "не присутствовала", "не был свидетелем", "не была свидетелем", "не мог видеть", "не могла видеть")
            "rumor" -> listOf("не слышал слух", "не слышала слух", "слух до него не дошел", "слух до нее не дошел", "слух до него не дошёл", "слух до неё не дошёл")
            else -> emptyList()
        }
        return vetoes.any { normalized.contains(it) }
    }

    private fun nameVariants(name: String): Set<String> {
        val base = name.trim()
        val out = linkedSetOf(base)
        if (base.length < 3) return out
        when (base.last().lowercaseChar()) {
            'а' -> {
                val stem = base.dropLast(1)
                out += listOf(stem + "ы", stem + "е", stem + "у", stem + "ой", stem + "ою")
            }
            'я' -> {
                val stem = base.dropLast(1)
                out += listOf(stem + "и", stem + "е", stem + "ю", stem + "ей", stem + "ею")
            }
            'ь' -> {
                val stem = base.dropLast(1)
                out += listOf(stem + "я", stem + "ю", stem + "ем", stem + "е", stem + "и")
            }
            'й' -> {
                val stem = base.dropLast(1)
                out += listOf(stem + "я", stem + "ю", stem + "ем", stem + "е")
            }
            else -> out += listOf(base + "а", base + "у", base + "ом", base + "е", base + "ы")
        }
        return out
    }

    private fun cleanFact(raw: String): String? {
        val fact = raw.replace(Regex("\\s+"), " ").trim().trim(',', ';', ':', '—', '-', '«', '»', '"', '\'')
        if (fact.length < 4) return null
        if (Regex("(?iu)^(?:что|как|это|там|тут)\\b\\s*$").containsMatchIn(fact)) return null
        return fact.take(260)
    }

    private fun isNegatedOrHypothetical(text: String, start: Int): Boolean {
        val shortPrefix = text.substring(maxOf(0, start - 55), start).lowercase(Locale.ROOT)
        if (Regex("(?:^|[^\\p{L}])(?:не|никогда не|не собираюсь|не стану|не буду|не хочу)\\s*$").containsMatchIn(shortPrefix)) return true
        val boundary = text.lastIndexOfAny(charArrayOf('.', '!', '?', ';', ',', '\n'), (start - 1).coerceAtLeast(0))
        val clausePrefix = text.substring(maxOf(boundary + 1, start - 140), start).lowercase(Locale.ROOT)
        return listOf("если бы", "представим", "допустим", "что если", "планирую", "собираюсь", "хотел бы", "хотела бы", "мог бы", "могла бы")
            .any { marker -> clausePrefix.contains(marker) }
    }

    private fun insideQuotes(text: String, index: Int): Boolean {
        val pairs = listOf('«' to '»', '“' to '”', '"' to '"')
        for ((open, close) in pairs) {
            val before = text.substring(0, index).count { it == open }
            if (open == close) {
                if (before % 2 == 1) return true
            } else if (text.lastIndexOf(open, index) > text.lastIndexOf(close, index)) return true
        }
        return false
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace('ё', 'е').replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
}
