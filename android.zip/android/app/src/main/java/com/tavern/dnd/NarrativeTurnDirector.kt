package com.tavern.dnd

/** Deterministic scene contract: anchors the LLM to the player's actual intent and existing state. */
object NarrativeTurnDirector {
    enum class Intent { DEESCALATE, NEGOTIATE, THREATEN, ATTACK, DECLARE_COMBAT, ASK, OBSERVE, OTHER }

    data class TurnContract(
        val intent: Intent,
        val target: String,
        val mustAddressPlayerWords: Boolean,
        val combatMayStart: Boolean,
        val requiresNpcReaction: Boolean,
        val instruction: String
    ) {
        fun promptLine(): String = "Намерение=${intent.name}; цель=${target.ifBlank { "не определена" }}; " +
            "ответить на смысл слов=${mustAddressPlayerWords}; начинать бой=${combatMayStart}; " +
            "нужна реакция NPC=${requiresNpcReaction}. $instruction"
    }

    fun analyze(c: Campaign, raw: String): TurnContract {
        val t = raw.lowercase().replace('ё', 'е').trim()
        val negation = has(t, "не атакую", "не нападаю", "не хочу драться", "вы мне не противники", "мы не враги", "не враги", "не собираюсь драться")
        val deescalate = negation || has(t, "опускаю оружие", "убираю меч", "показываю пустые ладони", "предлагаю мир", "давайте без драки", "не хочу конфликта")
        val negotiate = has(t, "предлагаю сделку", "давай договоримся", "давайте договоримся", "предлагаю союз", "союз", "перемирие", "обсудим условия")
        val threat = !negation && has(t, "угрожаю", "иначе убью", "сейчас пожалеете", "готовьтесь к бою", "готовьтесь к битве")
        val attack = !negation && has(t, "атакую", "нападаю", "наношу удар", "бью его", "стреляю в", "рублю его", "колю мечом")
        val ask = '?' in raw || has(t, "спрашиваю", "говорю", "говорю им", "говорю ему", "говорю ей", "объясняю", "сообщаю")
        val observe = has(t, "осматриваюсь", "осматриваю", "прислушиваюсь", "ищу следы", "наблюдаю")
        val intent = when {
            deescalate -> Intent.DEESCALATE
            negotiate -> Intent.NEGOTIATE
            attack -> Intent.ATTACK
            threat -> Intent.THREATEN
            ask -> Intent.ASK
            observe -> Intent.OBSERVE
            else -> Intent.OTHER
        }
        val target = when {
            c.combatEnemyName.isNotBlank() && (c.combatActive || attack || threat) -> c.combatEnemyName
            c.lastNpc.isNotBlank() -> c.lastNpc
            else -> ""
        }
        val instruction = when (intent) {
            Intent.DEESCALATE -> "Это попытка снизить угрозу, а не атака. NPC должны отреагировать на точные слова игрока с учётом их страха, целей и прошлого; не начинай бой автоматически. Они могут не поверить сразу, потребовать доказательств или продолжить держать оружие наготове. Покажи конкретную реплику и наблюдаемое действие NPC."
            Intent.NEGOTIATE -> "Разреши именно предложение переговоров/сделки: назови позицию собеседника, встречное условие или причину отказа. Не объявляй союз заключённым без согласия другой стороны."
            Intent.THREATEN -> "Это угроза или заявление о готовности к бою, но не автоматическая атака. Опиши реакцию тех, кто реально слышал угрозу; бой начинается только если противники явно переходят к нападению или уже активен боевой режим."
            Intent.ATTACK -> "Разрешай заявленную атаку через боевой движок. Не подменяй результат атмосферным текстом и не выдумывай броски или урон."
            Intent.ASK -> "Ответь непосредственно на вопрос/содержание реплики. Не вставляй случайную катастрофу и не меняй тему. NPC отвечает только в пределах своих знаний."
            Intent.OBSERVE -> "Опиши конкретные доступные наблюдению признаки. Не раскрывай скрытые сведения без успешной проверки или явной причины."
            else -> "Сначала определи конкретное действие по словам игрока. Если намерение неясно, задай один короткий уточняющий вопрос; не создавай событие только ради драматизма."
        }
        return TurnContract(intent, target, true,
            combatMayStart = intent == Intent.ATTACK || (c.combatActive && intent == Intent.THREATEN),
            requiresNpcReaction = intent in setOf(Intent.DEESCALATE, Intent.NEGOTIATE, Intent.THREATEN, Intent.ASK),
            instruction = instruction)
    }

    fun responseRules(): String = """
        ОБЯЗАТЕЛЬНЫЙ ПРОТОКОЛ ХОДА:
        1) Первая часть ответа должна явно продвинуть именно действие/реплику игрока, а не пересказывать её.
        2) Если игрок обращается к NPC, дай конкретную реакцию именно этого NPC: слова ИЛИ наблюдаемое действие, объяснимое его целями, страхом и известными фактами.
        3) Не показывай технические блоки вида 'Состояние мира', числовые показатели или метки событий в обычном художественном ответе, если игрок прямо не запросил статус/лист/мир. Не выдумывай и не меняй эти числа в тексте.
        4) Не запускай случайную катастрофу, бой, запахи или новую угрозу в качестве заполнителя. Новое событие допустимо только если оно следует из текущей сцены, активной угрозы или предыдущих фактов.
        5) В конце дай одно понятное продолжение ситуации или оставь естественную паузу для хода игрока; не перечисляй универсальное меню вариантов после каждой реплики.
        6) Держи ответ в 1–3 абзацах (обычно 60–150 слов). Не описывай мысли/действия героя, которых игрок не заявлял.
    """.trimIndent()

    private fun has(t: String, vararg terms: String) = terms.any { it in t }
}
