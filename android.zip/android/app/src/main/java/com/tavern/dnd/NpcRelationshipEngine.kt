package com.tavern.dnd

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Conservative relationship bookkeeping.
 *
 * This remains a heuristic, not semantic understanding. It only records clear actions that are
 * explicitly described as done. It never infers attraction, consent, trauma or intimacy readiness.
 */
object NpcRelationshipEngine {
    data class Delta(
        val trust: Int = 0,
        val affection: Int = 0,
        val fear: Int = 0,
        val reason: String = "",
        val confidence: Int = 0
    ) {
        val isEmpty: Boolean get() = trust == 0 && affection == 0 && fear == 0
    }

    private data class Signal(val patterns: List<Regex>, val delta: Delta, val allowNegated: Boolean = false)

    private val signals = listOf(
        Signal(listOf(
            Regex("""(?:^|[^\p{L}])(?:я\s+)?(?:предал|предала|обманул|обманула|украл|украла|нарушил обещание|нарушила обещание)(?=$|[^\p{L}])""", RegexOption.IGNORE_CASE)
        ), Delta(trust = -12, affection = -7, reason = "явное предательство или обман", confidence = 3)),
        Signal(listOf(
            Regex("""(?:^|[^\p{L}])(?:я\s+)?(?:угрожаю|угрожал|угрожала|запугиваю|запугал|запугала|шантажирую|шантажировал|шантажировала|избиваю|избил|избила|пытаю|пытал|пытала)(?=$|[^\p{L}])""", RegexOption.IGNORE_CASE)
        ), Delta(trust = -8, affection = -5, fear = 12, reason = "явная угроза или принуждение", confidence = 3)),
        Signal(listOf(
            Regex("""(?:^|[^\p{L}])(?:я\s+)?(?:оскорбляю|оскорбил|оскорбила|унижаю|унижал|унижала|издеваюсь)(?=$|[^\p{L}])""", RegexOption.IGNORE_CASE)
        ), Delta(trust = -4, affection = -8, reason = "оскорбление или унижение", confidence = 2)),
        // Positive shifts require a completed action, not a promise or an attempt in progress.
        Signal(listOf(
            Regex("""(?:^|[^\p{L}])(?:я\s+)?(?:спас|спасла|помог|помогла|вылечил|вылечила|поделился едой|поделилась едой|вернул долг|вернула долг|сдержал обещание|сдержала обещание)(?=$|[^\p{L}])""", RegexOption.IGNORE_CASE)
        ), Delta(trust = 5, affection = 2, reason = "завершённая помощь или выполненное обещание", confidence = 2)),
        Signal(listOf(
            Regex("""(?:^|[^\p{L}])(?:я\s+)?(?:извинился|извинилась|попросил прощения|попросила прощения|признал свою ошибку|признала свою ошибку)(?=$|[^\p{L}])""", RegexOption.IGNORE_CASE)
        ), Delta(trust = 2, affection = 1, reason = "явное извинение; оно не гарантирует прощения", confidence = 2)),
        // These patterns describe de-escalating behaviour, so their "не буду давить" phrase is
        // an affirmative boundary-respecting statement, not a negated harmful act.
        Signal(listOf(
            Regex("""(?:уважаю (?:твой|её|его) отказ|останавливаюсь|отступаю|не буду давить|прекращаю и отхожу)""", RegexOption.IGNORE_CASE)
        ), Delta(trust = 3, reason = "уважение обозначенной границы", confidence = 3), allowNegated = true)
    )

    fun classify(playerText: String, npcReply: String = ""): Delta {
        val raw = playerText.trim()
        if (raw.isBlank()) return Delta()
        val candidates = mutableListOf<Delta>()
        for (signal in signals) {
            for (pattern in signal.patterns) {
                for (match in pattern.findAll(raw)) {
                    val actionOffset = match.value.indexOfFirst { it.isLetter() }.coerceAtLeast(0)
                    if (insideQuotes(raw, match.range.first + actionOffset)) continue
                    if (!signal.allowNegated && isNegated(raw, match.range.first)) continue
                    if (isHypotheticalBefore(raw, match.range.first)) continue
                    candidates += signal.delta
                }
            }
        }
        if (candidates.isEmpty()) return Delta()

        val hasPositive = candidates.any { it.trust > 0 || it.affection > 0 }
        val hasNegative = candidates.any { it.trust < 0 || it.affection < 0 || it.fear > 0 }
        // Mixed turns need semantic resolution; do not guess which action dominates.
        if (hasPositive && hasNegative) return Delta()
        val selected = candidates.maxByOrNull { it.confidence } ?: return Delta()

        val reply = npcReply.lowercase(Locale.ROOT)
        if ((selected.trust > 0 || selected.affection > 0) &&
            listOf("не получилось", "не удалось", "помощь не удалась", "отвергает помощь",
                "отказывается от помощи", "не принимает извин", "не верит", "не доверяет",
                "не подпускает", "попытка провалилась", "не успел помочь", "не успела помочь")
                .any(reply::contains)) return Delta()
        return selected
    }

    /**
     * Do not attach an interaction to a stale lastNpc value. The NPC must be mentioned in the
     * current player turn or reply. For multiword labels, the final token is treated as the name.
     */
    fun resolveMentionedNpc(c: Campaign, playerText: String, npcReply: String): String? {
        val profileNames = mutableListOf<String>()
        try {
            val root = JSONObject(c.npcProfiles.ifBlank { "{}" })
            val keys = root.keys()
            while (keys.hasNext()) {
                val p = root.optJSONObject(keys.next()) ?: continue
                p.optString("name").trim().takeIf { it.isNotBlank() }?.let(profileNames::add)
            }
        } catch (_: Exception) { /* Corrupt profile data is handled by the profile store. */ }

        val active = c.lastNpc.trim()
        val activeFinal = normalize(active).split(" ").lastOrNull().orEmpty()
        // The active label often includes a role ("трактирщик Борис") while the durable profile
        // is just "Борис". Do not count both labels as two different NPCs.
        val candidates = profileNames.distinctBy { normalize(it) }.toMutableList()
        if (active.isNotBlank() && candidates.none {
                normalize(it) == normalize(active) || normalize(it).split(" ").lastOrNull() == activeFinal
            }) candidates += active

        // Prefer an NPC named by the player. A name appearing only in generated narration must
        // not receive relationship changes unless it is the active scene NPC.
        val playerTextNormalized = normalize(playerText)
        val playerMatches = candidates.filter { hasNpcMention(playerTextNormalized, it) }
            .distinctBy { normalize(it) }
        if (playerMatches.isNotEmpty()) return playerMatches.singleOrNull()

        if (active.isBlank()) return null
        val activeCandidates = candidates.filter { label ->
            val normalized = normalize(label)
            normalized == normalize(active) || normalized.split(" ").lastOrNull() == activeFinal
        }.distinctBy { normalize(it) }
        val activeCandidate = activeCandidates.singleOrNull() ?: return null
        return activeCandidate.takeIf { hasNpcMention(normalize(npcReply), it) }
    }

    fun apply(c: Campaign, npcName: String, playerText: String, npcReply: String = "") {
        if (npcName.isBlank()) return
        val delta = classify(playerText, npcReply)
        if (delta.isEmpty) return
        val root = try { JSONObject(c.npcProfiles.ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
        val key = resolveProfileKey(root, npcName)
        val p = root.optJSONObject(key) ?: JSONObject().put("name", npcName.trim().take(100))
        p.put("name", npcName.trim().take(100))
        applyScore(p, "trust", delta.trust)
        applyScore(p, "affection", delta.affection)
        applyScore(p, "fear", delta.fear)
        val events = p.optJSONArray("events") ?: JSONArray()
        events.put("Изменение отношений (${delta.reason}): доверие ${signed(delta.trust)}, расположение ${signed(delta.affection)}, страх ${signed(delta.fear)}. Основание: ${clean(playerText, 160)}")
        while (events.length() > 12) events.remove(0)
        p.put("events", events)
        root.put(key, p)
        c.npcProfiles = root.toString()
    }


    private fun hasNpcMention(normalizedText: String, label: String): Boolean {
        val full = normalize(label)
        val finalName = full.split(" ").lastOrNull().orEmpty()
        if (full.isBlank()) return false
        if (hasPhrase(normalizedText, full)) return true
        return nameVariants(finalName).any { hasPhrase(normalizedText, it) }
    }

    private fun nameVariants(name: String): Set<String> {
        if (name.length < 3) return setOf(name)
        val variants = linkedSetOf(name)
        when (name.last()) {
            'а' -> { val stem = name.dropLast(1); variants += listOf(stem + "ы", stem + "е", stem + "у", stem + "ой") }
            'я' -> { val stem = name.dropLast(1); variants += listOf(stem + "и", stem + "е", stem + "ю", stem + "ей") }
            'й' -> { val stem = name.dropLast(1); variants += listOf(stem + "я", stem + "ю", stem + "ем", stem + "е") }
            'ь' -> { val stem = name.dropLast(1); variants += listOf(stem + "я", stem + "ю", stem + "ем", stem + "е", stem + "и") }
            else -> variants += listOf(name + "а", name + "у", name + "ом", name + "е", name + "ы")
        }
        return variants
    }

    private fun resolveProfileKey(root: JSONObject, requested: String): String {
        val normalized = normalize(requested)
        if (root.has(normalized)) return normalized
        val finalName = normalized.split(" ").lastOrNull().orEmpty()
        val matches = root.keys().asSequence().filter { key ->
            val profileName = normalize(root.optJSONObject(key)?.optString("name", key) ?: key)
            profileName == normalized || profileName.split(" ").lastOrNull() == finalName
        }.toList()
        return if (matches.size == 1) matches.first() else normalized
    }

    private fun isNegated(text: String, start: Int): Boolean {
        val prefix = text.substring(maxOf(0, start - 45), start).lowercase(Locale.ROOT)
        return Regex("""(?:^|[^\p{L}])(?:не|никогда не|не собираюсь|не стану|не буду|не хочу|не пытался|не пыталась)(?:\s+[\p{L}\p{M}-]+){0,2}\s*$""")
            .containsMatchIn(prefix)
    }

    private fun isHypotheticalBefore(text: String, start: Int): Boolean {
        val boundary = text.lastIndexOfAny(charArrayOf('.', '!', '?', ';', ',', '\n'), (start - 1).coerceAtLeast(0))
        val prefix = text.substring(maxOf(boundary + 1, start - 100), start).lowercase(Locale.ROOT)
        return listOf("если бы", "представим", "допустим", "что если", "мог бы", "могла бы", "хотел бы", "хотела бы", "планирую", "собираюсь")
            .any { marker -> prefix.contains(marker) }
    }

    private fun insideQuotes(text: String, index: Int): Boolean {
        val quotePairs = listOf('«' to '»', '“' to '”', '"' to '"', '„' to '“')
        for ((open, close) in quotePairs) {
            val before = text.substring(0, index).count { it == open }
            if (open == close) {
                if (before % 2 == 1) return true
            } else {
                val lastOpen = text.lastIndexOf(open, index)
                val lastClose = text.lastIndexOf(close, index)
                if (lastOpen >= 0 && lastOpen > lastClose) return true
            }
        }
        return false
    }

    private fun hasPhrase(text: String, phrase: String): Boolean {
        val pattern = Regex("""(?:^|[^\p{L}\p{N}])${Regex.escape(phrase)}(?=$|[^\p{L}\p{N}])""")
        return pattern.containsMatchIn(text)
    }

    private fun normalize(value: String) = value.lowercase(Locale.ROOT)
        .replace('ё', 'е').replace(Regex("""[^\p{L}\p{N}]+"""), " ").trim()

    private fun applyScore(p: JSONObject, key: String, delta: Int) {
        val old = if (!p.has(key) || p.isNull(key)) 0 else p.optInt(key).coerceIn(-100, 100)
        p.put(key, (old + delta).coerceIn(-100, 100))
    }

    private fun signed(v: Int) = if (v > 0) "+$v" else v.toString()
    private fun clean(value: String, limit: Int) = value.replace(Regex("\\s+"), " ").trim().take(limit)
}
