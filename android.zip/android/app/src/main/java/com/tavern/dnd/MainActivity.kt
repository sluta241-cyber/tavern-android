package com.tavern.dnd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Палитра переключается между белой и чёрной темами; выбор хранится отдельно от кампаний.
private val DarkThemeState = mutableStateOf(false)
private val Bg: Color get() = if (DarkThemeState.value) Color(0xFF08090C) else Color(0xFFF7F8FA)
private val Panel: Color get() = if (DarkThemeState.value) Color(0xFF14161B) else Color(0xFFFFFFFF)
private val Panel2: Color get() = if (DarkThemeState.value) Color(0xFF242831) else Color(0xFFEEF1F5)
private val Accent = Color(0xFF4D6BFE)
private val TextMain: Color get() = if (DarkThemeState.value) Color(0xFFF1F3F8) else Color(0xFF182230)
private val Muted: Color get() = if (DarkThemeState.value) Color(0xFFA0A8B7) else Color(0xFF697586)
private val UserBubble: Color get() = if (DarkThemeState.value) Color(0xFF202B49) else Color(0xFFE8EEFF)
private val AiBubble: Color get() = if (DarkThemeState.value) Color(0xFF14161B) else Color(0xFFFFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalLlmEngine.AppContextHolder.context = applicationContext
        val uiPrefs = getSharedPreferences("tavern_ui", MODE_PRIVATE)
        DarkThemeState.value = uiPrefs.getBoolean("dark_theme", false)
        setContent {
            SideEffect {
                val bar = if (DarkThemeState.value) android.graphics.Color.rgb(8, 9, 12) else android.graphics.Color.rgb(247, 248, 250)
                window.statusBarColor = bar
                window.navigationBarColor = bar
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    var flags = window.decorView.systemUiVisibility
                    flags = if (DarkThemeState.value) flags and android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                    else flags or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    window.decorView.systemUiVisibility = flags
                }
            }
            MaterialTheme(
                colorScheme = if (DarkThemeState.value) darkColorScheme(
                    primary = Accent, onPrimary = Color.White,
                    background = Bg, onBackground = TextMain,
                    surface = Panel, onSurface = TextMain,
                    surfaceVariant = Panel2, onSurfaceVariant = Muted
                ) else lightColorScheme(
                    primary = Accent, onPrimary = Color.White,
                    background = Bg, onBackground = TextMain,
                    surface = Panel, onSurface = TextMain,
                    surfaceVariant = Panel2, onSurfaceVariant = Muted
                )
            ) { TavernApp() }
        }
    }
}

@Composable
private fun TavernApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf("home") }
    var campaigns by remember { mutableStateOf(CampaignStore.list(ctx)) }
    var current by remember { mutableStateOf<Campaign?>(null) }
    var busy by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var settings by remember { mutableStateOf(CampaignStore.loadSettings(ctx)) }

    fun refreshList() { campaigns = CampaignStore.list(ctx) }

    fun openCampaign(c: Campaign) {
        current = c
        CampaignStore.setCurrent(ctx, c.id)
        screen = "chat"
    }

    fun sendMessage() {
        val c = current ?: return
        val text = input.trim()
        if (text.isEmpty() || busy) return
        input = ""
        busy = true
        scope.launch {
            try {
                val turn = c.messages.count { it.role == "user" } + 1
                c.messages.add(ChatMessage("user", text, turn))
                // force recomposition snapshot
                current = c.copy(messages = c.messages.toMutableList())
                val reply = withContext(Dispatchers.IO) {
                    try {
                        OnlineLlm.chat(c, text)
                    } catch (e: Exception) {
                        "Ошибка: ${e.message ?: e.javaClass.simpleName}"
                    }
                }
                c.messages.add(ChatMessage("assistant", reply, turn))
                val interpreted = ActionInterpreter.analyze(c, text)
                if (c.lastActionIntent.isBlank() || c.lastActionIntent == "боевое действие") {
                    c.lastActionIntent = interpreted.primary
                }
                CampaignMemory.recordTurn(c, turn, text, reply)
                // Repair only numeric invariants; never rewrite the selected content mode or campaign choices.
                StateValidator.repairNumericInvariants(c)
                val validation = StateValidator.validate(c)
                if (!validation.valid) {
                    error = "Состояние кампании требует проверки: ${validation.issues.joinToString("; ")}"
                }
                CampaignStore.save(ctx, c)
                current = c.copy(messages = c.messages.toMutableList())
            } catch (e: Exception) {
                error = e.message ?: "Неизвестная ошибка"
            } finally {
                busy = false
                refreshList()
            }
        }
    }

    fun showSheet() {
        val c = current ?: return
        val sheet = OfflineEngine.characterSheet(c)
        c.messages.add(ChatMessage("assistant", sheet, c.messages.lastOrNull()?.turn ?: 0))
        CampaignStore.save(ctx, c)
        current = c.copy(messages = c.messages.toMutableList())
    }

    fun showNpcSheet() {
        val c = current ?: return
        val sheet = OfflineEngine.respond(c, "лист нпс")
        c.messages.add(ChatMessage("assistant", sheet, c.messages.lastOrNull()?.turn ?: 0))
        CampaignStore.save(ctx, c)
        current = c.copy(messages = c.messages.toMutableList())
    }

    fun showWorld() {
        val c = current ?: return
        val sheet = OfflineEngine.respond(c, "мир")
        c.messages.add(ChatMessage("assistant", sheet, c.messages.lastOrNull()?.turn ?: 0))
        CampaignStore.save(ctx, c)
        current = c.copy(messages = c.messages.toMutableList())
    }

    BackHandler(enabled = screen != "home") {
        when (screen) {
            "chat" -> {
                current?.let { CampaignStore.save(ctx, it) }
                screen = "home"
                refreshList()
            }
            else -> screen = if (current != null) "chat" else "home"
        }
    }

    Surface(Modifier.fillMaxSize().imePadding(), color = Bg) {
        when (screen) {
            "home" -> HomeScreen(
                campaigns, onNew = { screen = "new" },
                onOpen = { openCampaign(it) },
                onDelete = { CampaignStore.delete(ctx, it.id); refreshList() },
                onSettings = { screen = "settings" },
                onHelp = { screen = "help" }
            )
            "new" -> NewCampaignScreen(
                settings,
                onCancel = { screen = "home" },
                onCreate = { c ->
                    val tel = c.stats["ТЕЛ"] ?: 12
                    c.maxHp = (8 + c.level * ((tel - 10) / 2 + 5).coerceAtLeast(4)).coerceAtLeast(8)
                    c.hp = c.maxHp
                    c.messages.add(ChatMessage("assistant", OfflineEngine.openingScene(c), 0))
                    CampaignStore.save(ctx, c)
                    refreshList()
                    openCampaign(c)
                }
            )
            "settings" -> SettingsScreen(
                settings, darkMode = DarkThemeState.value,
                onDarkModeChange = { enabled ->
                    DarkThemeState.value = enabled
                    ctx.getSharedPreferences("tavern_ui", android.content.Context.MODE_PRIVATE).edit().putBoolean("dark_theme", enabled).apply()
                },
                onBack = { screen = "home" }
            ) {
                settings = it
                CampaignStore.saveSettings(ctx, it)
                screen = "home"
            }
            "help" -> GuideScreen(onBack = { screen = "home" })
            "chat" -> {
                val c = current
                if (c == null) screen = "home"
                else ChatScreen(
                    c, input, busy,
                    onInput = { input = it },
                    onSend = { sendMessage() },
                    onSheet = { showSheet() },
                    onNpcSheet = { showNpcSheet() },
                    onWorld = { showWorld() },
                    onBack = {
                        CampaignStore.save(ctx, c)
                        screen = "home"
                        refreshList()
                    }
                )
            }
        }
        if (error.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { error = "" },
                title = { Text("Ошибка") },
                text = { Text(error) },
                confirmButton = { TextButton(onClick = { error = "" }) { Text("ОК") } },
                containerColor = Panel
            )
        }
    }
}

@Composable
private fun HomeScreen(
    campaigns: List<Campaign>,
    onNew: () -> Unit, onOpen: (Campaign) -> Unit,
    onDelete: (Campaign) -> Unit, onSettings: () -> Unit, onHelp: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Таверна", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Твой мир. Твои правила.", color = Muted, fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onHelp) { Text("Справка", color = Accent) }
                TextButton(onClick = onSettings) { Text("Настройки", color = Accent) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onNew,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Новая партия") }
        Spacer(Modifier.height(16.dp))
        Text("Партии", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        if (campaigns.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Нет сохранений.\nСоздай партию — можно полностью офлайн.", color = Muted, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(campaigns, key = { it.id }) { c ->
                    Card(
                        onClick = { onOpen(c) },
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 15.dp)) {
                            Text(c.title.ifBlank { c.worldName }, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text(
                                "${c.heroName} · ${modeLabel(c.mode)} · ${masterLabel(c.masterSource)} · ${c.messages.count { it.role == "user" }} ходов",
                                color = Muted, fontSize = 12.sp
                            )
                            TextButton(onClick = { onDelete(c) }, contentPadding = PaddingValues(0.dp)) {
                                Text("Удалить", color = Color(0xFFCC6666), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NewCampaignScreen(settings: AppSettings, onCancel: () -> Unit, onCreate: (Campaign) -> Unit) {
    var world by remember { mutableStateOf("Три короны") }
    var worldLore by remember { mutableStateOf("") }
    var hero by remember { mutableStateOf("Странник") }
    var race by remember { mutableStateOf("человек") }
    var cls by remember { mutableStateOf("воин") }
    var multi by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("1") }
    var maxLevel by remember { mutableStateOf("20") }
    var appearance by remember { mutableStateOf("") }
    var beauty by remember { mutableStateOf("5") }
    var alignment by remember { mutableStateOf("нейтральный") }
    var backstory by remember { mutableStateOf("") }
    var skills by remember { mutableStateOf("") }
    var traits by remember { mutableStateOf("") }
    var mythicalTraits by remember { mutableStateOf("") }
    var mythicalAscension by remember { mutableStateOf("") }
    var divineTier by remember { mutableStateOf("смертный") }
    var raceTraits by remember { mutableStateOf("") }
    var classTraits by remember { mutableStateOf("") }
    var wealth by remember { mutableStateOf("3") }
    var socialRank by remember { mutableStateOf("простолюдин") }
    var customContracts by remember { mutableStateOf("") }
    var str by remember { mutableStateOf("12") }
    var dex by remember { mutableStateOf("12") }
    var con by remember { mutableStateOf("12") }
    var int_ by remember { mutableStateOf("12") }
    var wis by remember { mutableStateOf("12") }
    var cha by remember { mutableStateOf("12") }
    var mode by remember { mutableStateOf("adult") }
    var landscape by remember { mutableStateOf("лес") }
    var season by remember { mutableStateOf("осень") }
    var culture by remember { mutableStateOf("смешанная") }
    var rules by remember { mutableStateOf("Решения имеют последствия.") }
    var master by remember { mutableStateOf(settings.defaultMaster.ifBlank { "offline" }) }
    var model by remember { mutableStateOf(settings.defaultModel) }
    var apiKey by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("") }
    val scroll = rememberScrollState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Новая партия", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Можно заполнить кратко — остальное необязательно.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Head("Мир")
            F(world, { world = it }, "Название мира")
            F(worldLore, { worldLore = it }, "Предыстория / лор мира", single = false)
            Label("Сезон"); Chips(listOf("весна", "лето", "осень", "зима"), season) { season = it }
            Label("Ландшафт"); Chips(listOf("лес", "горы", "болото", "степь", "побережье", "пустыня", "тундра", "джунгли", "город"), landscape) { landscape = it }
            F(culture, { culture = it }, "Культура")
            F(rules, { rules = it }, "Правила партии (свои)", single = false)

            Head("Герой")
            F(hero, { hero = it }, "Имя")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                F(race, { race = it }, "Раса (любая)", Modifier.weight(1f))
                F(cls, { cls = it }, "Класс", Modifier.weight(1f))
            }
            F(multi, { multi = it }, "Второй класс (мультикласс, необязательно)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                F(level, { level = it.filter(Char::isDigit).take(2) }, "Уровень", Modifier.weight(1f))
                F(maxLevel, { maxLevel = it.filter(Char::isDigit).take(2) }, "Макс. уровень", Modifier.weight(1f))
            }
            F(alignment, { alignment = it }, "Мировоззрение (напр. хаотично-добрый)")
            F(beauty, { beauty = it.filter(Char::isDigit).take(2) }, "Красота 1–10")
            F(appearance, { appearance = it }, "Внешность", single = false)
            F(backstory, { backstory = it }, "Предыстория героя", single = false)
            F(skills, { skills = it }, "Навыки (своими словами)", single = false)
            F(traits, { traits = it }, "Черты характера (храбрый, мстительный…)", single = false)
            F(mythicalTraits, { mythicalTraits = it }, "Мифические черты (кровь дракона, глаз бури…)", single = false)
            F(mythicalAscension, { mythicalAscension = it }, "Как стать полубогом/богом (свои правила)", single = false)
            Label("Божественный статус")
            Chips(listOf("смертный", "полубог", "бог"), divineTier) { divineTier = it }
            F(raceTraits, { raceTraits = it }, "Механики расы (кастом)", single = false)
            F(classTraits, { classTraits = it }, "Механики класса (кастом)", single = false)
            F(socialRank, { socialRank = it }, "Социальный статус (крестьянин, барон, король…)")
            F(wealth, { wealth = it.filter(Char::isDigit).take(2) }, "Богатство 1–10")
            F(customContracts, { customContracts = it }, "Свои браки/контракты (правила союзов)", single = false)

            Head("Характеристики")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                F(str, { str = it.filter(Char::isDigit).take(2) }, "СИЛ", Modifier.weight(1f))
                F(dex, { dex = it.filter(Char::isDigit).take(2) }, "ЛОВ", Modifier.weight(1f))
                F(con, { con = it.filter(Char::isDigit).take(2) }, "ТЕЛ", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                F(int_, { int_ = it.filter(Char::isDigit).take(2) }, "ИНТ", Modifier.weight(1f))
                F(wis, { wis = it.filter(Char::isDigit).take(2) }, "МДР", Modifier.weight(1f))
                F(cha, { cha = it.filter(Char::isDigit).take(2) }, "ХАР", Modifier.weight(1f))
            }

            Head("Содержание")
            Chips(listOf("child" to "Детская", "adult" to "Взрослая", "uncensored" to "Полное отсутствие цензуры"), mode) { mode = it }

            Head("Мастер")
            Chips(listOf("offline" to "Офлайн", "local" to "Локальная модель", "openrouter" to "OpenRouter", "openai" to "OpenAI", "ollama" to "Ollama"), master) { master = it }
            if (master == "local") {
                Text("Модель хранится на телефоне. Для генерации требуется установленный нативный движок; без него Tavern честно переключится на офлайн-ответ.", color = Muted, fontSize = 11.sp)
            }
            if (master != "offline" && master != "local") {
                F(model, { model = it }, "Модель")
                if (master != "ollama") F(apiKey, { apiKey = it }, "API-ключ", password = true)
                if (master == "ollama") F(baseUrl, { baseUrl = it }, "Адрес Ollama")
            } else Text("Офлайн работает без интернета. Пиши действия обычным текстом. Команда «лист» — лист персонажа.", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Отмена") }
            Button(
                onClick = {
                    fun st(s: String) = s.toIntOrNull()?.coerceIn(1, 30) ?: 12
                    val c = Campaign(
                        id = CampaignStore.newId(),
                        title = world.ifBlank { "Партия" },
                        worldName = world.ifBlank { "Мир" },
                        worldLore = worldLore,
                        heroName = hero.ifBlank { "Странник" },
                        race = race.ifBlank { "человек" },
                        raceTraits = raceTraits,
                        heroClass = cls.ifBlank { "воин" },
                        classTraits = classTraits,
                        multiclass = multi,
                        level = level.toIntOrNull()?.coerceIn(1, 30) ?: 1,
                        maxLevel = maxLevel.toIntOrNull()?.coerceIn(1, 30) ?: 20,
                        appearance = appearance,
                        beauty = beauty.toIntOrNull()?.coerceIn(1, 10) ?: 5,
                        wealth = wealth.toIntOrNull()?.coerceIn(1, 10) ?: 3,
                        socialRank = socialRank.ifBlank { "простолюдин" },
                        alignment = alignment.ifBlank { "нейтральный" },
                        backstory = backstory,
                        traits = traits,
                        mythicalTraits = mythicalTraits,
                        mythicalAscension = mythicalAscension,
                        divineTier = divineTier,
                        stats = mapOf(
                            "СИЛ" to st(str), "ЛОВ" to st(dex), "ТЕЛ" to st(con),
                            "ИНТ" to st(int_), "МДР" to st(wis), "ХАР" to st(cha)
                        ),
                        skills = skills,
                        mode = mode,
                        landscape = landscape,
                        season = season,
                        culture = culture,
                        customRules = rules,
                        customContracts = customContracts,
                        masterSource = master,
                        model = model,
                        apiKey = apiKey,
                        baseUrl = baseUrl
                    )
                    onCreate(c)
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Text("Начать") }
        }
    }
}

@Composable
private fun ChatScreen(
    campaign: Campaign,
    input: String,
    busy: Boolean,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onSheet: () -> Unit,
    onNpcSheet: () -> Unit,
    onWorld: () -> Unit,
    onBack: () -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(campaign.messages.size, busy) {
        if (campaign.messages.isNotEmpty()) listState.animateScrollToItem(campaign.messages.lastIndex)
    }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←", color = TextMain, fontSize = 18.sp) }
            Column(Modifier.weight(1f)) {
                Text(campaign.title, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 16.sp)
                Text(
                    "${campaign.heroName} · HP ${campaign.hp}/${campaign.maxHp} · ${modeLabel(campaign.mode)}",
                    color = Muted, fontSize = 11.sp, maxLines = 1
                )
            }
            TextButton(onClick = onSheet) { Text("Лист", color = Accent, fontSize = 12.sp) }
            TextButton(onClick = onNpcSheet) { Text("NPC", color = Accent, fontSize = 12.sp) }
            TextButton(onClick = onWorld) { Text("Мир", color = Accent, fontSize = 12.sp) }
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(campaign.messages) { m ->
                val mine = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (mine) UserBubble else AiBubble,
                        shape = RoundedCornerShape(if (mine) 18.dp else 10.dp),
                        shadowElevation = if (mine) 0.dp else 1.dp,
                        modifier = Modifier.widthIn(max = 360.dp)
                    ) {
                        Text(
                            m.content,
                            Modifier.padding(horizontal = 15.dp, vertical = 12.dp),
                            color = TextMain, fontSize = 15.sp, lineHeight = 23.sp
                        )
                    }
                }
            }
            if (busy) {
                item {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Мастер думает…", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = onInput,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(20.dp),
                placeholder = { Text("Напиши сообщение…", color = Muted) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                maxLines = 6,
                colors = fieldColors()
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onSend,
                enabled = !busy && input.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                contentPadding = PaddingValues(15.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("➤") }
        }
    }
}

@Composable
private fun GuideScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Назад", color = Accent) }
            Text("Как пользоваться Tavern", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("Краткая инструкция по основным возможностям. Карточки ниже — наглядные мини-схемы экранов.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            GuideCard("1", "Создай кампанию", "Нажми «Новая партия». Укажи мир, героя, расу, класс, характеристики и собственные правила. Необязательные поля можно заполнить позже.", "🏰", "НОВАЯ ПАРТИЯ", "Мир · Герой · Правила")
            GuideCard("2", "Играй обычным текстом", "В чате описывай действие так, как сказал бы ведущему за столом: «Осматриваю дверь», «Пытаюсь убедить стражника», «Атакую гоблина». Уточняй цель и способ, если это важно.", "💬", "ТЫ: Осматриваю дверь", "МАСТЕР: Опиши, что замечаешь…")
            GuideCard("3", "Используй лист, NPC и мир", "Кнопка «Лист» показывает сведения о герое, «NPC» — информацию о персонажах, а «Мир» помогает запросить сведения о текущем мире. Доступность деталей зависит от выбранного мастера.", "📜", "Лист     NPC     Мир", "Персонаж · Отношения · Локации")
            GuideCard("4", "Настрой мастера и правила", "В настройках выбери офлайн-режим или подключаемого провайдера, укажи модель и необходимые данные. В настройках кампании можно задать свои правила; явно указанные условия важнее стандартных подсказок, если движок умеет их распознавать.", "⚙️", "МАСТЕР: Офлайн / API", "Модель · Ключ · Свои правила")
            GuideCard("5", "Выбери режим содержания", "При создании кампании выбери подходящий режим. Он влияет на инструкции ведущему. Смена темы приложения не меняет этот выбор и не меняет правила кампании.", "🎭", "Содержание", "Детская · Взрослая · Полное отсутствие цензуры")
            GuideCard("6", "Сохраняй историю", "Кампания сохраняется на устройстве по мере игры. Воспоминания и журнал помогают удерживать важные события, но автоматическое извлечение памяти может что-то пропустить — важные факты лучше явно повторить или записать в правилах кампании.", "🧠", "ПАМЯТЬ КАМПАНИИ", "События · NPC · Сюжетные линии")
            GuideCard("7", "Переключай белую и чёрную тему", "Открой «Настройки» и включи переключатель «Тема приложения». Выбор сохраняется на устройстве и применяется к следующим запускам.", "🌗", "ТЕМА ПРИЛОЖЕНИЯ", "Белая  ◉────────  Чёрная")
            Surface(color = Panel2, shape = RoundedCornerShape(14.dp)) {
                Text("Совет: если ответ мастера не совпадает с задумкой, уточни действие или правило прямо в сообщении. Для важных механик формулируй условия конкретно: например, «СЛ скрытности 17».", Modifier.padding(14.dp), color = TextMain, fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Понятно") }
    }
}

@Composable
private fun GuideCard(number: String, title: String, description: String, emoji: String, mockTitle: String, mockSubtitle: String) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = Accent.copy(alpha = 0.13f), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(emoji, fontSize = 22.sp) }
                }
                Column(Modifier.weight(1f)) {
                    Text("$number. $title", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(mockTitle, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            // Миниатюрная схематичная иллюстрация интерфейса — не зависит от внешних картинок или интернета.
            Surface(color = Panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.fillMaxWidth(0.72f).height(7.dp).background(Muted.copy(alpha = 0.25f), RoundedCornerShape(8.dp)))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.weight(0.58f).height(25.dp).background(Accent.copy(alpha = 0.18f), RoundedCornerShape(8.dp)))
                        Box(Modifier.weight(0.42f).height(25.dp).background(Panel, RoundedCornerShape(8.dp)))
                    }
                    Text(mockSubtitle, color = Muted, fontSize = 10.sp)
                }
            }
            Text(description, color = TextMain, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun SettingsScreen(settings: AppSettings, darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit, onBack: () -> Unit, onSave: (AppSettings) -> Unit) {
    var defaultMaster by remember { mutableStateOf(settings.defaultMaster) }
    var orKey by remember { mutableStateOf(settings.openRouterKey) }
    var oaKey by remember { mutableStateOf(settings.openAiKey) }
    var model by remember { mutableStateOf(settings.defaultModel) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Настройки", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text("Ключи только на этом телефоне. Для офлайна не нужны.", color = Muted, fontSize = 12.sp)
        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Тема приложения", color = TextMain, fontWeight = FontWeight.Medium)
                    Text(if (darkMode) "Чёрная тема" else "Белая тема", color = Muted, fontSize = 12.sp)
                }
                Switch(checked = darkMode, onCheckedChange = onDarkModeChange)
            }
        }
        Label("Мастер по умолчанию")
        Chips(listOf("offline" to "Офлайн", "local" to "Локальная модель", "openrouter" to "OpenRouter", "openai" to "OpenAI", "ollama" to "Ollama"), defaultMaster) { defaultMaster = it }
        F(model, { model = it }, "Модель по умолчанию")
        F(orKey, { orKey = it }, "Ключ OpenRouter", password = true)
        F(oaKey, { oaKey = it }, "Ключ OpenAI", password = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Назад") }
            Button(onClick = { onSave(AppSettings(defaultMaster, orKey, oaKey, model)) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Сохранить") }
        }
    }
}

@Composable private fun Head(t: String) = Text(t, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
@Composable private fun Label(t: String) = Text(t, color = Muted, fontSize = 12.sp)

@Composable
private fun F(
    value: String, onChange: (String) -> Unit, label: String,
    modifier: Modifier = Modifier.fillMaxWidth(), single: Boolean = true, password: Boolean = false
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, modifier = modifier, label = { Text(label) },
        singleLine = single, minLines = if (single) 1 else 2, maxLines = if (single) 1 else 5,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        colors = fieldColors()
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Accent, unfocusedBorderColor = Panel2,
    focusedTextColor = TextMain, unfocusedTextColor = TextMain,
    focusedLabelColor = Accent, unfocusedLabelColor = Muted,
    cursorColor = Accent
)

@Composable
private fun Chips(options: List<Any>, selected: String, onSelect: (String) -> Unit) {
    val pairs = options.map {
        when (it) {
            is Pair<*, *> -> it.first.toString() to it.second.toString()
            else -> it.toString() to it.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        pairs.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { (id, label) ->
                    FilterChip(
                        selected = selected == id,
                        onClick = { onSelect(id) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent.copy(alpha = 0.25f),
                            selectedLabelColor = Accent
                        )
                    )
                }
            }
        }
    }
}

private fun modeLabel(m: String) = when (m) {
    "child" -> "детская"; "uncensored" -> "полное отсутствие цензуры"; else -> "взрослая"
}
private fun masterLabel(m: String) = when (m) {
    "offline" -> "офлайн"; "local" -> "локальная модель"; "openrouter" -> "OpenRouter"; "openai" -> "OpenAI"; "ollama" -> "Ollama"; else -> m
}
