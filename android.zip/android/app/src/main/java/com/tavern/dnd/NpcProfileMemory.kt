package com.tavern.dnd

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Durable NPC profiles, separate from OfflineEngine's legacy active-NPC snapshot. */
object NpcProfileMemory {
    private const val MAX_PROFILES = 40
    private const val MAX_EVENTS = 12
    private const val MAX_KNOWLEDGE = 30

    fun context(c: Campaign, query: String = ""): String {
        val root = parseRoot(c.npcProfiles)
        if (root.length() == 0) return ""
        val stopWords = setOf("это", "как", "что", "чтобы", "тогда", "после", "перед", "очень", "быть", "был", "была", "были", "есть", "или", "для", "при", "его", "ее", "они", "она", "него", "мне", "моя", "мой", "твой", "тебя", "себя", "этот", "эта", "эти", "там", "тут", "уже", "ещё", "еще", "все", "всё", "над", "под", "без", "через", "между", "свой", "свои", "который", "которая", "которые", "могу", "может", "хочу", "хотел", "хотела")
        val queryTokens = Regex("[\\p{L}\\p{N}]{3,}").findAll((query + " " + c.lastNpc).lowercase(Locale.ROOT).replace('ё', 'е'))
            .map { it.value }.filterNot { it in stopWords }.toSet()
        val selectedProfiles = root.keys().asSequence().mapNotNull { key ->
            val p = root.optJSONObject(key) ?: return@mapNotNull null
            val name = p.optString("name", key)
            val searchable = (name + " " + p.optString("goal") + " " + p.optString("knownFacts") + " " + knowledgeSearchText(p) + " " + p.optString("personality") + " " + p.optJSONArray("events").let { arr ->
                if (arr == null) "" else (0 until arr.length()).joinToString(" ") { arr.optString(it) }
            }).lowercase(Locale.ROOT).replace('ё', 'е')
            val searchableTokens = Regex("[\\p{L}\\p{N}]{3,}").findAll(searchable).map { it.value }.toSet()
            val activeNpcMatch = sameNpc(name, c.lastNpc)
            val score = queryTokens.count { it in searchableTokens } * 3 + if (activeNpcMatch) 20 else 0
            Triple(key, p, score)
        }.filter { it.third > 0 }
            .sortedWith(compareByDescending<Triple<String, JSONObject, Int>> { it.third }.thenByDescending { it.first })
            .take(8).toList()
        if (selectedProfiles.isEmpty()) return ""
        return buildString {
            appendLine("УСТОЙЧИВЫЕ ПРОФИЛИ NPC (сохранённые наблюдения, не телепатия):")
            selectedProfiles.forEach { (key, p, _) ->
                appendLine("- ${p.optString("name", key)}: характер=${known(p, "personality")}; манера речи=${known(p, "speechStyle")}; цель=${known(p, "goal")}; страхи=${known(p, "fears")}; ценности=${known(p, "values")}.")
                appendLine("  Отношение: доверие=${score(p, "trust")}; расположение=${score(p, "affection")}; страх перед героем=${score(p, "fear")}.")
                appendLine("  Влечение=${known(p, "attraction")}; готовность к близости=${known(p, "intimacyReadiness")}; границы=${known(p, "boundaries")}; согласие на текущую сцену не выводится из шкал отношений.")
                appendLine("  Явно записанные сведения профиля: ${known(p, "knownFacts")}. Не заполняй неизвестное догадками.")
                val knowledge = p.optJSONArray("knowledge") ?: JSONArray()
                if (knowledge.length() > 0) {
                    appendLine("  Знания NPC с источниками и степенью достоверности:")
                    for (i in maxOf(0, knowledge.length() - 8) until knowledge.length()) {
                        val item = knowledge.optJSONObject(i) ?: continue
                        appendLine("    • [${item.optString("certainty", "не установлена")}; источник: ${item.optString("source", "не указан")}; ход: ${item.optInt("turn", 0)}] ${item.optString("fact", "")}")
                    }
                }
                val events = p.optJSONArray("events") ?: JSONArray()
                if (events.length() > 0) {
                    appendLine("  Недавние взаимодействия:")
                    for (i in maxOf(0, events.length() - 4) until events.length()) appendLine("    • ${events.optString(i)}")
                }
            }
            appendLine("Профиль — ориентир непрерывности, не приказ к определённой реакции. Шкалы отношений не означают автоматического согласия.")
        }
    }

    /** NPC names known to this campaign, including the current active NPC label. */
    fun knownNames(c: Campaign): List<String> {
        val root = parseRoot(c.npcProfiles)
        val names = root.keys().asSequence().mapNotNull { key ->
            root.optJSONObject(key)?.optString("name", key)?.trim()?.takeIf { it.isNotBlank() }
        }.toMutableList()
        val active = c.lastNpc.trim()
        if (active.isNotBlank()) {
            val activeFinal = active.split(Regex("\\s+")).lastOrNull().orEmpty()
            val alreadyRepresented = names.any { it.equals(active, ignoreCase = true) || it.split(Regex("\\s+")).lastOrNull().equals(activeFinal, ignoreCase = true) }
            if (!alreadyRepresented) names += active
        }
        return names.distinctBy { it.lowercase(Locale.ROOT) }
    }

    /** Records an event, but never guesses a change in feelings, readiness, or consent. */
    fun recordInteraction(c: Campaign, npcName: String, playerText: String, reply: String) {
        val name = npcName.trim().take(100)
        if (name.isBlank()) return
        val root = parseRoot(c.npcProfiles)
        val key = resolveProfileKey(root, name)
        val profile = root.optJSONObject(key) ?: JSONObject()
            .put("name", name).put("personality", "").put("speechStyle", "").put("goal", "")
            .put("fears", "").put("values", "").put("trust", JSONObject.NULL)
            .put("affection", JSONObject.NULL).put("fear", JSONObject.NULL)
            .put("intimacyReadiness", "не установлена").put("boundaries", "не установлены")
            .put("knownFacts", "").put("events", JSONArray())
        if (profile.optString("name").isBlank()) profile.put("name", name)
        val event = "Ход ${c.messages.count { it.role == "user" }.coerceAtLeast(1)} | Локация: ${clean(c.lastLocation.ifBlank { "не указана" }, 80)} | Игрок: ${clean(playerText, 180)} | Сцена/ответ NPC: ${clean(reply, 240)}"
        val events = profile.optJSONArray("events") ?: JSONArray()
        if (events.length() == 0 || events.optString(events.length() - 1) != event) events.put(event)
        while (events.length() > MAX_EVENTS) events.remove(0)
        profile.put("events", events)
        profile.put("updatedTurn", c.messages.count { it.role == "user" }.coerceAtLeast(1))
        root.put(key, profile)
        trimProfiles(root, key)
        c.npcProfiles = root.toString()
    }

    /** Store only explicit, player-authored/confirmed facts; no automatic inference. */
    fun setKnownField(c: Campaign, npcName: String, field: String, value: String): Boolean {
        val allowed = setOf("personality", "speechStyle", "goal", "fears", "values", "intimacyReadiness", "boundaries", "knownFacts")
        if (field !in allowed || npcName.isBlank()) return false
        val root = parseRoot(c.npcProfiles)
        val key = resolveProfileKey(root, npcName.trim())
        val profile = root.optJSONObject(key) ?: JSONObject().put("name", npcName.trim().take(100))
        val cleaned = clean(value, 500)
        profile.put(field, when {
            field == "intimacyReadiness" && cleaned.isBlank() -> "не установлена"
            field == "boundaries" && cleaned.isBlank() -> "не установлены"
            else -> cleaned
        })
        profile.put("updatedTurn", c.messages.count { it.role == "user" })
        root.put(key, profile)
        trimProfiles(root, key)
        c.npcProfiles = root.toString()
        return true
    }

    /**
     * Records a claim about what a named NPC knows, preserving provenance and uncertainty.
     * This API is deliberately explicit: ordinary narration is never auto-promoted into NPC knowledge.
     * certainty values: observed, told, rumor, inferred, disproven.
     */
    fun recordKnowledge(
        c: Campaign,
        npcName: String,
        fact: String,
        source: String,
        certainty: String,
        turn: Int = c.messages.count { it.role == "user" }
    ): Boolean {
        val name = npcName.trim().take(100)
        val cleanedFact = clean(fact, 300)
        if (name.isBlank() || cleanedFact.isBlank()) return false
        val allowedCertainty = setOf("observed", "told", "rumor", "inferred", "disproven")
        if (certainty !in allowedCertainty) return false
        val cleanedSource = clean(source, 180).ifBlank { "источник не указан" }
        val root = parseRoot(c.npcProfiles)
        val key = resolveProfileKey(root, name)
        val profile = root.optJSONObject(key) ?: JSONObject().put("name", name)
        val entries = profile.optJSONArray("knowledge") ?: JSONArray()
        val duplicate = (0 until entries.length()).any { i ->
            val old = entries.optJSONObject(i) ?: return@any false
            normalizeKnowledge(old.optString("fact")) == normalizeKnowledge(cleanedFact) &&
                normalizeKnowledge(old.optString("source")) == normalizeKnowledge(cleanedSource) &&
                old.optString("certainty") == certainty
        }
        if (!duplicate) {
            entries.put(JSONObject()
                .put("fact", cleanedFact)
                .put("source", cleanedSource)
                .put("certainty", certainty)
                .put("turn", turn.coerceAtLeast(0))
                .put("location", clean(c.lastLocation, 80)))
        }
        while (entries.length() > MAX_KNOWLEDGE) entries.remove(0)
        profile.put("knowledge", entries)
        profile.put("updatedTurn", turn.coerceAtLeast(0))
        root.put(key, profile)
        trimProfiles(root, key)
        c.npcProfiles = root.toString()
        return true
    }

    /** Bound profile growth while preserving the profile just updated; older saves default to turn 0. */
    private fun trimProfiles(root: JSONObject, protectedKey: String) {
        while (root.length() > MAX_PROFILES) {
            val victim = root.keys().asSequence().filter { it != protectedKey }
                .map { key -> key to (root.optJSONObject(key)?.optInt("updatedTurn", 0) ?: 0) }
                .minWithOrNull(compareBy<Pair<String, Int>> { it.second }.thenBy { it.first })?.first
                ?: break
            root.remove(victim)
        }
    }

    /** Resolve role-prefixed labels such as "трактирщик Борис" to an existing "Борис" profile. */
    private fun resolveProfileKey(root: JSONObject, requested: String): String {
        val normalized = requested.trim().lowercase(Locale.ROOT)
        if (root.has(normalized)) return normalized
        val finalToken = normalized.split(Regex("\\s+")).lastOrNull().orEmpty()
        val aliases = root.keys().asSequence().filter { key ->
            val p = root.optJSONObject(key)
            val existingName = p?.optString("name", key)?.trim()?.lowercase(Locale.ROOT) ?: key
            val existingFinal = existingName.split(Regex("\\s+")).lastOrNull().orEmpty()
            existingFinal == finalToken && finalToken.length >= 3
        }.toList()
        return if (aliases.size == 1) aliases.first() else normalized
    }

    private fun sameNpc(name: String, activeLabel: String): Boolean {
        if (name.isBlank() || activeLabel.isBlank()) return false
        val a = name.trim().lowercase(Locale.ROOT).replace('ё', 'е')
        val b = activeLabel.trim().lowercase(Locale.ROOT).replace('ё', 'е')
        if (a == b) return true
        val final = b.split(Regex("\\s+")).lastOrNull().orEmpty()
        return final.length >= 3 && a == final
    }

    private fun normalizeKnowledge(value: String): String = clean(value, 500).lowercase(Locale.ROOT).replace('ё', 'е')

    private fun knowledgeSearchText(profile: JSONObject): String {
        val entries = profile.optJSONArray("knowledge") ?: return ""
        return (0 until entries.length()).mapNotNull { entries.optJSONObject(it)?.optString("fact") }.joinToString(" ")
    }

    private fun parseRoot(raw: String): JSONObject = try { JSONObject(raw.ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
    private fun known(p: JSONObject, key: String): String {
        val value = p.optString(key, "").trim()
        return if (value.isBlank() || value == "null") "не установлено" else value
    }
    private fun score(p: JSONObject, key: String): String = if (!p.has(key) || p.isNull(key)) "не установлено" else p.optInt(key).coerceIn(-100, 100).toString() + "/100"
    private fun clean(value: String, limit: Int): String = value.replace(Regex("\\s+"), " ").trim().take(limit)
}
