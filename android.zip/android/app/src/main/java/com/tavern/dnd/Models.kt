package com.tavern.dnd

data class ChatMessage(
    val role: String,
    val content: String,
    val turn: Int = 0
)

data class Campaign(
    val id: String,
    var title: String,
    var worldName: String,
    var worldLore: String = "",
    var heroName: String,
    var race: String = "человек",
    var raceTraits: String = "",          // кастом механики расы
    var heroClass: String = "воин",
    var classTraits: String = "",         // кастом механики класса
    var multiclass: String = "",
    var level: Int = 1,
    var maxLevel: Int = 20,
    var appearance: String = "",
    var beauty: Int = 5,
    var wealth: Int = 3,                  // 1–10 богатство/ресурсы
    var socialRank: String = "простолюдин", // статус игрока
    var alignment: String = "нейтральный",
    var backstory: String = "",
    var traits: String = "",              // черты характера
    var mythicalTraits: String = "",      // мифические черты
    var mythicalAscension: String = "",   // как становишься полубогом/богом
    var divineTier: String = "смертный",  // смертный | полубог | бог
    var stats: Map<String, Int> = mapOf(
        "СИЛ" to 12, "ЛОВ" to 12, "ТЕЛ" to 12,
        "ИНТ" to 12, "МДР" to 12, "ХАР" to 12
    ),
    var skills: String = "",
    var mode: String = "adult",
    var landscape: String = "лес",
    var season: String = "осень",
    var culture: String = "смешанная",
    var customRules: String = "",
    var customContracts: String = "",     // свои типы браков/контрактов
    var masterSource: String = "offline",
    var model: String = "",
    var apiKey: String = "",
    var baseUrl: String = "",
    var messages: MutableList<ChatMessage> = mutableListOf(),
    var updatedAt: Long = System.currentTimeMillis(),
    var lastNpc: String = "",
    var lastLocation: String = "",
    var hp: Int = 10,
    var maxHp: Int = 10,
    var worldTension: Int = 15,
    var worldProsperity: Int = 50,
    var worldFear: Int = 10,
    var lastDisasterTurn: Int = -30,
    var worldFlags: String = "",
    var worldLog: String = "",
    var marriageLog: String = "",         // предложения и контракты
    // Структурированное состояние боя — переживает перезапуск приложения.
    var combatActive: Boolean = false,
    var combatEnemyName: String = "",
    var combatEnemyHp: Int = 0,
    var combatEnemyMaxHp: Int = 0,
    var combatEnemyAc: Int = 13,
    var combatRound: Int = 0,
    var combatInitiative: String = "",
    var combatEnemyKind: String = "",
    var combatPlayerDodging: Boolean = false,
    // Краткая память мастера и факты, которые нельзя терять между ходами.
    var campaignMemory: String = "",
    var inventory: String = "",
    var conditions: String = "",
    var lastActionIntent: String = "",
    var npcMemory: String = "",
    // v39: separate durable NPC relationship profiles from legacy/offline active-NPC snapshot.
    var npcProfiles: String = "{}",
    // v36: durable event log and compact world facts; defaults preserve old saves.
    var eventLog: String = "",
    var worldFacts: String = "",
    var openThreads: String = "",
    var saveSchemaVersion: Int = 6,
    // D&D 5e 2014 death-save track; defaults keep older campaign files compatible.
    var deathSaveSuccesses: Int = 0,
    var deathSaveFailures: Int = 0,
    var characterDead: Boolean = false
)

data class AppSettings(
    var defaultMaster: String = "offline",
    var openRouterKey: String = "",
    var openAiKey: String = "",
    var defaultModel: String = "openai/gpt-4o-mini"
)
