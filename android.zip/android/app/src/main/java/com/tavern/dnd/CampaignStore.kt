package com.tavern.dnd

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object CampaignStore {
    private const val PREFS = "tavern_standalone"
    private const val KEY_CAMPAIGNS = "campaigns"
    private const val KEY_SETTINGS = "settings"
    private const val KEY_CURRENT = "current_id"
    private const val KEY_BACKUP = "campaigns_backup"

    fun list(ctx: Context): List<Campaign> {
        val p = prefs(ctx)
        val primary = p.getString(KEY_CAMPAIGNS, "{}") ?: "{}"
        val obj = try { JSONObject(primary) } catch (_: Exception) {
            // Recover from the last known-good snapshot if the main JSON was interrupted/corrupted.
            val backup = p.getString(KEY_BACKUP, "{}") ?: "{}"
            try { JSONObject(backup) } catch (_: Exception) { JSONObject() }
        }
        val out = mutableListOf<Campaign>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val id = keys.next()
            val item = obj.optJSONObject(id) ?: continue
            try {
                out += fromJson(item)
            } catch (_: Exception) {
                // One damaged save must not make every other campaign inaccessible.
            }
        }
        return out.sortedByDescending { it.updatedAt }
    }

    fun save(ctx: Context, c: Campaign) {
        // Keep chat storage bounded; older turns are condensed into durable campaign memory.
        if (c.messages.size > 240) {
            val archived = c.messages.take(c.messages.size - 240).mapNotNull { m ->
                val line = m.content.replace(Regex("\\s+"), " ").take(220)
                when (m.role) {
                    "user" -> "Игрок: $line"
                    "assistant" -> "Мастер: $line"
                    else -> null
                }
            }
            c.campaignMemory = (c.campaignMemory.lines().filter { it.isNotBlank() } + archived).takeLast(40).joinToString("\n")
            c.messages = c.messages.takeLast(240).toMutableList()
        }
        c.updatedAt = System.currentTimeMillis()
        val p = prefs(ctx)
        val oldRaw = p.getString(KEY_CAMPAIGNS, "{}") ?: "{}"
        val backupRaw = p.getString(KEY_BACKUP, "{}") ?: "{}"
        val parsed = try { JSONObject(oldRaw) to oldRaw } catch (_: Exception) {
            try { JSONObject(backupRaw) to backupRaw } catch (_: Exception) { JSONObject() to "{}" }
        }
        val root = parsed.first
        root.put(c.id, toJson(c))
        // Keep the last known-good state as a recovery point and commit before returning.
        p.edit().putString(KEY_BACKUP, parsed.second).putString(KEY_CAMPAIGNS, root.toString()).commit()
    }

    fun delete(ctx: Context, id: String) {
        val p = prefs(ctx)
        val raw = p.getString(KEY_CAMPAIGNS, "{}") ?: "{}"
        val backupRaw = p.getString(KEY_BACKUP, "{}") ?: "{}"
        val parsed = try { JSONObject(raw) to raw } catch (_: Exception) {
            try { JSONObject(backupRaw) to backupRaw } catch (_: Exception) { JSONObject() to "{}" }
        }
        parsed.first.remove(id)
        p.edit().putString(KEY_BACKUP, parsed.second).putString(KEY_CAMPAIGNS, parsed.first.toString()).commit()
        if (currentId(ctx) == id) setCurrent(ctx, null)
    }

    fun currentId(ctx: Context): String? = prefs(ctx).getString(KEY_CURRENT, null)
    fun setCurrent(ctx: Context, id: String?) {
        prefs(ctx).edit().putString(KEY_CURRENT, id).apply()
    }

    fun newId(): String = UUID.randomUUID().toString().take(8)

    fun loadSettings(ctx: Context): AppSettings {
        val o = JSONObject(prefs(ctx).getString(KEY_SETTINGS, "{}") ?: "{}")
        return AppSettings(
            defaultMaster = o.optString("defaultMaster", "offline"),
            openRouterKey = o.optString("openRouterKey", ""),
            openAiKey = o.optString("openAiKey", ""),
            defaultModel = o.optString("defaultModel", "openai/gpt-4o-mini")
        )
    }

    fun saveSettings(ctx: Context, s: AppSettings) {
        val o = JSONObject()
            .put("defaultMaster", s.defaultMaster)
            .put("openRouterKey", s.openRouterKey)
            .put("openAiKey", s.openAiKey)
            .put("defaultModel", s.defaultModel)
        prefs(ctx).edit().putString(KEY_SETTINGS, o.toString()).apply()
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun toJson(c: Campaign): JSONObject {
        val msgs = JSONArray()
        c.messages.forEach { m ->
            msgs.put(JSONObject().put("role", m.role).put("content", m.content).put("turn", m.turn))
        }
        val stats = JSONObject()
        c.stats.forEach { (k, v) -> stats.put(k, v) }
        return JSONObject()
            .put("id", c.id).put("title", c.title).put("worldName", c.worldName)
            .put("worldLore", c.worldLore)
            .put("heroName", c.heroName).put("race", c.race).put("raceTraits", c.raceTraits)
            .put("heroClass", c.heroClass).put("classTraits", c.classTraits)
            .put("multiclass", c.multiclass)
            .put("level", c.level).put("maxLevel", c.maxLevel)
            .put("appearance", c.appearance).put("beauty", c.beauty)
            .put("wealth", c.wealth).put("socialRank", c.socialRank)
            .put("alignment", c.alignment).put("backstory", c.backstory)
            .put("traits", c.traits).put("mythicalTraits", c.mythicalTraits)
            .put("mythicalAscension", c.mythicalAscension).put("divineTier", c.divineTier)
            .put("stats", stats).put("skills", c.skills)
            .put("mode", c.mode).put("landscape", c.landscape).put("season", c.season)
            .put("culture", c.culture).put("customRules", c.customRules)
            .put("customContracts", c.customContracts)
            .put("masterSource", c.masterSource).put("model", c.model)
            .put("apiKey", c.apiKey).put("baseUrl", c.baseUrl)
            .put("lastNpc", c.lastNpc).put("lastLocation", c.lastLocation)
            .put("hp", c.hp).put("maxHp", c.maxHp)
            .put("worldTension", c.worldTension).put("worldProsperity", c.worldProsperity)
            .put("worldFear", c.worldFear).put("lastDisasterTurn", c.lastDisasterTurn)
            .put("worldFlags", c.worldFlags).put("worldLog", c.worldLog)
            .put("marriageLog", c.marriageLog)
            .put("combatActive", c.combatActive).put("combatEnemyName", c.combatEnemyName)
            .put("combatEnemyHp", c.combatEnemyHp).put("combatEnemyMaxHp", c.combatEnemyMaxHp)
            .put("combatEnemyAc", c.combatEnemyAc).put("combatRound", c.combatRound)
            .put("combatInitiative", c.combatInitiative).put("combatEnemyKind", c.combatEnemyKind)
            .put("combatPlayerDodging", c.combatPlayerDodging)
            .put("campaignMemory", c.campaignMemory).put("inventory", c.inventory)
            .put("conditions", c.conditions).put("lastActionIntent", c.lastActionIntent).put("npcMemory", c.npcMemory)
            .put("npcProfiles", c.npcProfiles)
            .put("updatedAt", c.updatedAt).put("messages", msgs)
            .put("eventLog", c.eventLog).put("worldFacts", c.worldFacts)
            .put("openThreads", c.openThreads).put("saveSchemaVersion", c.saveSchemaVersion)
            .put("deathSaveSuccesses", c.deathSaveSuccesses).put("deathSaveFailures", c.deathSaveFailures)
            .put("characterDead", c.characterDead)
    }

    private fun fromJson(o: JSONObject): Campaign {
        val msgs = mutableListOf<ChatMessage>()
        val arr = o.optJSONArray("messages") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            msgs += ChatMessage(m.optString("role"), m.optString("content"), m.optInt("turn"))
        }
        val statsObj = o.optJSONObject("stats")
        val stats = mutableMapOf(
            "СИЛ" to 12, "ЛОВ" to 12, "ТЕЛ" to 12,
            "ИНТ" to 12, "МДР" to 12, "ХАР" to 12
        )
        if (statsObj != null) {
            stats.keys.toList().forEach { k -> if (statsObj.has(k)) stats[k] = statsObj.optInt(k, 12) }
        }
        val level = o.optInt("level", 1)
        val tel = stats["ТЕЛ"] ?: 12
        val defaultHp = 8 + level * ((tel - 10) / 2 + 5).coerceAtLeast(4)
        return Campaign(
            id = o.optString("id"),
            title = o.optString("title", "Кампания"),
            worldName = o.optString("worldName", "Мир"),
            worldLore = o.optString("worldLore"),
            heroName = o.optString("heroName", "Герой"),
            race = o.optString("race", "человек"),
            raceTraits = o.optString("raceTraits"),
            heroClass = o.optString("heroClass", "воин"),
            classTraits = o.optString("classTraits"),
            multiclass = o.optString("multiclass"),
            level = level,
            maxLevel = o.optInt("maxLevel", 20),
            appearance = o.optString("appearance"),
            beauty = o.optInt("beauty", 5).coerceIn(1, 10),
            wealth = o.optInt("wealth", 3).coerceIn(1, 10),
            socialRank = o.optString("socialRank", "простолюдин"),
            alignment = o.optString("alignment", "нейтральный"),
            backstory = o.optString("backstory"),
            traits = o.optString("traits"),
            mythicalTraits = o.optString("mythicalTraits"),
            mythicalAscension = o.optString("mythicalAscension"),
            divineTier = o.optString("divineTier", "смертный"),
            stats = stats,
            skills = o.optString("skills"),
            mode = o.optString("mode", "adult"),
            landscape = o.optString("landscape", "лес"),
            season = o.optString("season", "осень"),
            culture = o.optString("culture", "смешанная"),
            customRules = o.optString("customRules"),
            customContracts = o.optString("customContracts"),
            masterSource = o.optString("masterSource", "offline"),
            model = o.optString("model"),
            apiKey = o.optString("apiKey"),
            baseUrl = o.optString("baseUrl"),
            messages = msgs,
            updatedAt = o.optLong("updatedAt", 0L),
            lastNpc = o.optString("lastNpc"),
            lastLocation = o.optString("lastLocation"),
            hp = o.optInt("hp", defaultHp),
            maxHp = o.optInt("maxHp", defaultHp),
            worldTension = o.optInt("worldTension", 15),
            worldProsperity = o.optInt("worldProsperity", 50),
            worldFear = o.optInt("worldFear", 10),
            lastDisasterTurn = o.optInt("lastDisasterTurn", -30),
            worldFlags = o.optString("worldFlags"),
            worldLog = o.optString("worldLog"),
            marriageLog = o.optString("marriageLog"),
            combatActive = o.optBoolean("combatActive", false),
            combatEnemyName = o.optString("combatEnemyName"),
            combatEnemyHp = o.optInt("combatEnemyHp", 0),
            combatEnemyMaxHp = o.optInt("combatEnemyMaxHp", 0),
            combatEnemyAc = o.optInt("combatEnemyAc", 13),
            combatRound = o.optInt("combatRound", 0),
            combatInitiative = o.optString("combatInitiative"),
            combatEnemyKind = o.optString("combatEnemyKind"),
            combatPlayerDodging = o.optBoolean("combatPlayerDodging", false),
            campaignMemory = o.optString("campaignMemory"),
            inventory = o.optString("inventory"),
            conditions = o.optString("conditions"),
            lastActionIntent = o.optString("lastActionIntent"),
            npcMemory = o.optString("npcMemory"),
            npcProfiles = o.optString("npcProfiles", "{}"),
            eventLog = o.optString("eventLog"),
            worldFacts = o.optString("worldFacts"),
            openThreads = o.optString("openThreads"),
            saveSchemaVersion = o.optInt("saveSchemaVersion", 1).coerceAtLeast(1),
            deathSaveSuccesses = o.optInt("deathSaveSuccesses", 0).coerceIn(0, 3),
            deathSaveFailures = o.optInt("deathSaveFailures", 0).coerceIn(0, 3),
            characterDead = o.optBoolean("characterDead", false)
        )
    }
}
