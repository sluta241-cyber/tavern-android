package com.tavern.dnd

/** Состояние мира партии: последствия, катастрофы, слухи. */
data class WorldEvent(
    val turn: Int,
    val text: String,
    val kind: String // rumor | consequence | disaster | social
)

data class WorldRuntime(
    var tension: Int = 0,          // 0–100 общая напряжённость
    var prosperity: Int = 50,      // 0–100
    var fear: Int = 10,
    var lastDisasterTurn: Int = -20,
    val events: MutableList<WorldEvent> = mutableListOf(),
    val flags: MutableSet<String> = mutableSetOf()
) {
    fun note(turn: Int, text: String, kind: String) {
        events.add(WorldEvent(turn, text, kind))
        if (events.size > 40) events.removeAt(0)
    }
}
