package com.tavern.dnd

import java.util.Locale

/** Durable campaign memory with query-aware retrieval over the bounded legacy journals. */
object CampaignMemory {
    private const val MAX_EVENT_LINES = 100
    private const val MAX_FACT_LINES = 80
    private const val MAX_THREAD_LINES = 40
    private const val MAX_MEMORY_LINES = 12

    fun context(c: Campaign, currentIntent: ActionInterpreter.Intent): String = buildString {
        val latestPlayerText = c.messages.lastOrNull { it.role == "user" }?.content.orEmpty()
        val query = listOf(latestPlayerText, currentIntent.summary, c.lastNpc, c.lastLocation).filter { it.isNotBlank() }.joinToString(" ")
        appendLine("АНАЛИЗ НАМЕРЕНИЯ (ориентир, не замена правил): ${currentIntent.summary}")
        appendLine("ЕДИНЫЕ ПРАВИЛА КАМПАНИИ И КАСТОМНЫХ МЕХАНИК:\n${CustomRuleEngine.context(c).promptBlock()}")
        appendLine(NpcBrain.guidance(c))
        appendLine(NarrativeDirector.guidance(currentIntent, c.combatActive))

        val relevant = retrieveRelevant(c, query)
        if (relevant.isNotBlank()) appendLine("РЕЛЕВАНТНАЯ ПАМЯТЬ КАМПАНИИ (сначала учитывай совпадения с текущим действием; старые записи не отменяют новые подтверждённые события):\n$relevant")
        if (c.worldFacts.isNotBlank()) appendLine("УСТОЙЧИВЫЕ ФАКТЫ МИРА:\n${c.worldFacts.lines().takeLast(12).joinToString("\n")}")
        if (c.npcMemory.isNotBlank()) appendLine("ПАМЯТЬ АКТИВНОГО NPC/СОСТОЯНИЕ ОФЛАЙН-ДВИЖКА:\n${c.npcMemory.lines().takeLast(8).joinToString("\n")}")
        val npcProfiles = NpcProfileMemory.context(c, query)
        if (npcProfiles.isNotBlank()) appendLine(npcProfiles)
        if (c.openThreads.isNotBlank()) appendLine("НЕЗАВЕРШЁННЫЕ СЮЖЕТНЫЕ ЛИНИИ:\n${c.openThreads.lines().takeLast(12).joinToString("\n")}")
        if (c.eventLog.isNotBlank()) appendLine("ПОСЛЕДНИЕ СОБЫТИЯ (для хронологии):\n${c.eventLog.lines().takeLast(8).joinToString("\n")}")
        appendLine("ОБЯЗАТЕЛЬНО: отличай объективные факты от слухов и убеждений персонажей; не приписывай NPC знания, которых они не получали; не создавай новую угрозу без причины в сцене; разрешай все части сложного действия по порядку.")
        appendLine("ПРОИСХОЖДЕНИЕ ЗНАНИЙ NPC: пометка observed означает, что персонаж лично наблюдал событие; told — ему сообщили указанным источником; rumor — он слышал слух; inferred — это лишь вывод; disproven — сведения опровергнуты. Не превращай слухи/выводы в факты и не передавай знание между NPC без события-источника.")
        appendLine("ПРАВИЛО ПАМЯТИ: запись в журнале хода означает, что сцена была описана, но сама по себе не доказывает каждую деталь как объективный факт. Новые выводы модели не становятся фактами автоматически. Предположения и слухи помечай как таковые. При конфликте сохраняй оба утверждения с источниками, пока игра не установит истину.")
        appendLine("ПРАВИЛО РЕЖИМА: учитывай выбранный кампанией режим повествования при формулировке ответа. Не изменяй c.mode, не сбрасывай настройки режима и не подменяй выбранный режим значением по умолчанию.")
    }

    /** Ranks saved lines by lexical overlap and recency. It retrieves; it never promotes narration to fact. */
    fun retrieveRelevant(c: Campaign, query: String, limit: Int = MAX_MEMORY_LINES): String {
        val candidates = mutableListOf<MemoryCandidate>()
        addCandidates(candidates, "ФАКТ", c.worldFacts, 5)
        addCandidates(candidates, "СЮЖЕТ", c.openThreads, 4)
        addCandidates(candidates, "ХРОНОЛОГИЯ", c.eventLog, 2)
        addCandidates(candidates, "ПАМЯТЬ", c.campaignMemory, 1)
        if (c.lastNpc.isNotBlank()) {
            val needle = c.lastNpc.lowercase(Locale.ROOT)
            c.eventLog.lines().forEachIndexed { index, line ->
                if (line.contains(needle, ignoreCase = true)) candidates += MemoryCandidate("NPC", line, 3, index)
            }
        }
        val queryTokens = tokens(query)
        val ranked = candidates.distinctBy { it.label + "|" + it.text }
            .map { candidate ->
                val textTokens = tokens(candidate.text)
                val textExpanded = expandTokens(textTokens)
                val exactOverlap = queryTokens.count { it in textTokens }
                val expandedOverlap = expandTokens(queryTokens).count { it in textExpanded }
                val fuzzyOverlap = queryTokens.count { q ->
                    q !in textTokens && q.length >= 5 && textTokens.any { t ->
                        t.length >= 5 && kotlin.math.abs(q.length - t.length) <= 2 && TextFuzzy.distance(q, t) <= 2
                    }
                }
                val overlap = exactOverlap + (expandedOverlap - exactOverlap).coerceAtLeast(0) / 2 + fuzzyOverlap
                val phraseBonus = if (query.isNotBlank() && candidate.text.contains(query.trim(), ignoreCase = true)) 5 else 0
                val recentBonus = (candidate.index.coerceAtMost(20) / 5)
                candidate to (candidate.base + overlap * 3 + phraseBonus + recentBonus)
            }
            .filter { (candidate, score) -> score > candidate.base || candidate.base >= 4 }
            .sortedWith(compareByDescending<Pair<MemoryCandidate, Int>> { it.second }.thenByDescending { it.first.index })
            .take(limit.coerceIn(1, 30))
        return ranked.joinToString("\n") { (item, score) -> "[${item.label}] ${item.text}" }
    }

    fun recordTurn(c: Campaign, turn: Int, playerText: String, reply: String) {
        val responseIsError = reply.startsWith("Ошибка:", ignoreCase = true) || reply.startsWith("Error:", ignoreCase = true)
        // API/runtime failures are chat diagnostics, not fictional events. Keep them in chat history
        // but do not contaminate the campaign chronology, compact memory, relationships, or NPC knowledge.
        if (responseIsError) {
            c.saveSchemaVersion = maxOf(c.saveSchemaVersion, 6)
            return
        }
        val user = clean(playerText, 260)
        val result = clean(reply, 340)
        val event = "Ход $turn | ${c.lastLocation.ifBlank { "локация не указана" }} | Игрок: $user | Результат: $result"
        c.eventLog = (c.eventLog.lines().filter { it.isNotBlank() } + event).takeLast(MAX_EVENT_LINES).joinToString("\n")
        val intent = c.lastActionIntent.ifBlank { ActionInterpreter.analyze(c, playerText).primary }
        c.campaignMemory = (c.campaignMemory.lines().filter { it.isNotBlank() } + "Ход $turn: $intent; HP ${c.hp}/${c.maxHp}; бой=${c.combatActive}.")
            .takeLast(40).joinToString("\n")
        val npcForTurn = NpcRelationshipEngine.resolveMentionedNpc(c, user, reply)
        if (npcForTurn != null) {
            NpcProfileMemory.recordInteraction(c, npcForTurn, user, result)
            NpcRelationshipEngine.apply(c, npcForTurn, user, reply)
        }
        // Extract only explicit knowledge-transfer/observation statements from the player's own
        // turn. Model narration is intentionally excluded as an extraction source to avoid
        // promoting hallucinated scene details into durable NPC knowledge.
        NpcKnowledgeExtractor.extract(user, NpcProfileMemory.knownNames(c)).forEach { claim ->
            // Generated narration cannot add knowledge; it can only veto an explicit claim if
            // it clearly says the transfer/observation failed.
            if (!NpcKnowledgeExtractor.replyExplicitlyVetoes(reply, claim)) {
                NpcProfileMemory.recordKnowledge(c, claim.npcName, claim.fact, claim.source, claim.certainty, turn)
            }
        }
        c.saveSchemaVersion = maxOf(c.saveSchemaVersion, 6)
    }

    fun appendFact(c: Campaign, fact: String) {
        if (fact.isBlank()) return
        val normalized = clean(fact, 300)
        if (c.worldFacts.lines().any { it.equals(normalized, ignoreCase = true) }) return
        c.worldFacts = (c.worldFacts.lines().filter { it.isNotBlank() } + normalized).takeLast(MAX_FACT_LINES).joinToString("\n")
    }

    fun appendThread(c: Campaign, thread: String) {
        if (thread.isBlank()) return
        val normalized = clean(thread, 240)
        if (c.openThreads.lines().any { it.equals(normalized, ignoreCase = true) }) return
        c.openThreads = (c.openThreads.lines().filter { it.isNotBlank() } + normalized).takeLast(MAX_THREAD_LINES).joinToString("\n")
    }

    /** Close only a matching existing thread; does not silently invent a replacement. */
    fun closeThread(c: Campaign, thread: String): Boolean {
        val target = clean(thread, 240)
        if (target.isBlank()) return false
        val lines = c.openThreads.lines().filter { it.isNotBlank() }
        val match = lines.indexOfLast { it.equals(target, ignoreCase = true) }
        if (match < 0) return false
        c.openThreads = lines.filterIndexed { index, _ -> index != match }.joinToString("\n")
        c.campaignMemory = (c.campaignMemory.lines().filter { it.isNotBlank() } + "Сюжетная линия закрыта: $target")
            .takeLast(40).joinToString("\n")
        return true
    }

    private data class MemoryCandidate(val label: String, val text: String, val base: Int, val index: Int = 0)

    private fun addCandidates(out: MutableList<MemoryCandidate>, label: String, source: String, base: Int) {
        source.lines().filter { it.isNotBlank() }.forEachIndexed { index, line ->
            out += MemoryCandidate(label, clean(line, 420), base, index)
        }
    }

    private val stopWords = setOf("это", "как", "что", "чтобы", "тогда", "после", "перед", "очень", "быть", "был", "была", "были", "есть", "или", "для", "при", "его", "ее", "её", "они", "она", "него", "мне", "моя", "мой", "твой", "тебя", "себя", "этот", "эта", "эти", "там", "тут", "уже", "ещё", "еще", "снова", "всего", "всё", "все", "над", "под", "без", "через", "между", "свой", "свои", "который", "которая", "которые", "могу", "может", "хочу", "хотел", "хотела", "сделай", "сделал", "сделала")

    private fun stem(token: String): String {
        if (token.length < 5) return token
        val suffixes = listOf("иями", "ями", "ами", "ого", "ему", "ому", "ыми", "ими", "иях", "ах", "ях", "ов", "ев", "ей", "ой", "ий", "ый", "ая", "яя", "ое", "ее", "ые", "ие", "ую", "юю", "ам", "ям", "ом", "ем", "ы", "и", "а", "я", "у", "ю", "е")
        val suffix = suffixes.firstOrNull { token.endsWith(it) && token.length - it.length >= 4 }
        return if (suffix == null) token else token.dropLast(suffix.length)
    }

    private val synonymGroups = listOf(
        setOf("нпс", "персонаж", "герой", "собеседник", "человек"),
        setOf("враг", "противник", "злодей", "вражина", "антагонист"),
        setOf("квест", "задание", "поручение", "миссия", "сюжет"),
        setOf("долг", "обещание", "клятва", "обязательство"),
        setOf("убежище", "приют", "укрытие", "тайник", "логово"),
        setOf("драка", "бой", "сражение", "битва", "схватка"),
        setOf("доверие", "доверять", "верность", "союз", "отношения"),
        setOf("слух", "слухи", "молва", "сплетня", "известие"),
        setOf("артефакт", "реликвия", "предмет", "талисман", "сокровище")
    )
    private fun expandTokens(input: Set<String>): Set<String> {
        val out = input.toMutableSet()
        for (token in input) {
            val root = stem(token)
            if (root.length >= 4) out += root
            synonymGroups.firstOrNull { group -> group.any { it == token || stem(it) == root } }?.let { out += it }
        }
        return out
    }

    private fun tokens(s: String): Set<String> = Regex("[\\p{L}\\p{N}]{3,}")
        .findAll(s.lowercase(Locale.ROOT).replace('ё', 'е'))
        .map { it.value }.filterNot { it in stopWords }
        .flatMap { listOf(it, stem(it)).asSequence() }
        .filter { it.length >= 3 }.toSet()

    private fun clean(s: String, max: Int) = s.replace(Regex("\\s+"), " ").trim().take(max)
}
