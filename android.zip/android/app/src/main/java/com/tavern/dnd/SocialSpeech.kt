package com.tavern.dnd

import kotlin.random.Random

/** Регистры речи и социальный вес статусов. */
object SocialSpeech {

    /** Чем выше — тем выше в иерархии (для браков и тона). */
    fun rankWeight(rank: String): Int {
        val r = rank.lowercase()
        return when {
            "бог" in r || "богиня" in r -> 100
            "полубог" in r || "демиго" in r -> 85
            "император" in r || "корол" in r || "цар" in r -> 80
            "принц" in r || "княз" in r || "герцог" in r -> 70
            "граф" in r || "барон" in r || "наместник" in r || "лор" in r -> 60
            "дворян" in r || "придвор" in r -> 50
            "капитан" in r || "настоятель" in r || "купец гильдии" in r || "фактор" in r -> 40
            "сержант" in r || "священник" in r || "лавочник" in r || "старшина" in r -> 30
            "страж" in r || "солдат" in r || "охотник" in r || "хозяин" in r -> 22
            "крестьян" in r || "батрак" in r || "простолюд" in r -> 12
            "вор" in r || "изгой" in r || "дезертир" in r -> 8
            else -> 20
        }
    }

    fun playerWeight(c: Campaign): Int {
        var w = rankWeight(c.socialRank)
        when (c.divineTier.lowercase()) {
            "бог", "богиня" -> w = maxOf(w, 100)
            "полубог", "демигод" -> w = maxOf(w, 85)
        }
        w += (c.wealth - 5) * 2
        w += (c.level / 2)
        if (c.mythicalTraits.isNotBlank()) w += 5
        if (c.mythicalAscension.isNotBlank() && c.divineTier != "смертный") w += 10
        return w.coerceIn(1, 110)
    }

    /**
     * Тон речи: крестьянин ≠ король; но характер может ломать шаблон
     * (вспыльчивый слуга всё же рискует грубить).
     */
    fun speak(
        speakerRank: String,
        speakerStatus: String,
        personality: String,
        listenerIsPlayer: Boolean,
        player: Campaign,
        baseIntent: String,
        rng: Random
    ): String {
        val sw = rankWeight(speakerRank)
        val pw = if (listenerIsPlayer) playerWeight(player) else 25
        val gap = pw - sw
        val rudePersonality = listOf("вспыльчивый", "цинич", "гордец", "язвит").any { it in personality.lowercase() }
        val meekPersonality = listOf("покорн", "добрый", "тихий", "слуг").any { it in personality.lowercase() }
        val nobleSpeech = sw >= 50 || "дворян" in speakerStatus.lowercase() || "при двор" in speakerStatus.lowercase()
        val lowSpeech = sw <= 15

        // Не грубить вышестоящему, если характер не толкает
        val mustDefer = gap >= 25 && !rudePersonality
        val mayInsolent = gap <= -15 || (rudePersonality && gap < 10)

        val prefix = when {
            mustDefer && nobleSpeech -> listOf("Милостивый ", "Если позволите, ", "С дозволения… ").random(rng)
            mustDefer && lowSpeech -> listOf("Г-господин… ", "Простите за смелость, ", "Я не смею, но… ").random(rng)
            mustDefer -> listOf("С уважением, ", "Не обессудьте, ").random(rng)
            mayInsolent && lowSpeech -> listOf("Эй, ", "Слушай сюда, ", "Ха, ").random(rng)
            mayInsolent -> listOf("Что ж, ", "Как угодно. ", "").random(rng)
            nobleSpeech -> listOf("Полагаю, ", "Смею заметить: ", "").random(rng)
            lowSpeech -> listOf("Ну, ", "Так-то, ", "").random(rng)
            else -> ""
        }

        val body = when {
            nobleSpeech && !lowSpeech -> polishNoble(baseIntent)
            lowSpeech -> polishCommon(baseIntent)
            else -> baseIntent
        }

        val suffix = when {
            meekPersonality && mustDefer -> " …как скажете."
            rudePersonality && mayInsolent -> listOf(" И не глазей.", " Ясно?", "").random(rng)
            else -> ""
        }
        return "— $prefix$body$suffix"
    }

    private fun polishNoble(s: String): String {
        var t = s.trim().trimStart('—', ' ', '–')
        if (t.endsWith("!")) t = t.dropLast(1) + "."
        return t.replace("надо", "следует").replace("хочу", "желаю")
            .replace("деньги", "средства").replace("убить", "устранить")
    }

    private fun polishCommon(s: String): String {
        var t = s.trim().trimStart('—', ' ', '–')
        return t.replace("желаю", "хочу").replace("следует", "надо")
    }

    /** Брак: уместно ли предложение от NPC ранга from к игроку / наоборот. */
    fun marriagePlausible(proposerWeight: Int, targetWeight: Int, customRules: String): Pair<Boolean, String> {
        val diff = proposerWeight - targetWeight
        val rules = customRules.lowercase()
        if ("любой брак" in rules || "брак без рангов" in rules) {
            return true to "По вашим правилам ранг не мешает союзу."
        }
        return when {
            diff >= 35 -> false to "Слишком высокий дом: такому роду незачем связывать себя с тем, кто ниже на несколько ступеней — без титула, крови или подвига."
            diff >= 20 -> false to "Предложение сомнительно: разница в статусе велика. Нужен выкуп, земля, подвиг или благословение вышестоящих."
            diff <= -35 -> true to "Вышестоящий может предложить союз «ниже» как милость, награду или политику — но не как равный брак без условий."
            else -> true to "По статусу союз выглядит правдоподобно."
        }
    }
}
