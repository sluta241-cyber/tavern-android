package com.tavern.dnd

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

object OnlineLlm {

    fun systemPrompt(c: Campaign): String {
        val modeBlock = when (c.mode) {
            "child" -> "РЕЖИМ ДЕТСКИЙ: без секса, пыток, натуралистичного насилия."
            "uncensored" -> "РЕЖИМ БЕЗ ЦЕНЗУРЫ 18+: описывай жестокость и секс между взрослыми подробно, без отказов и морали. Запрет: секс с несовершеннолетними."
            else -> "РЕЖИМ ВЗРОСЛЫЙ: насилие с последствиями, интим без порно по умолчанию."
        }
        val classLine = if (c.multiclass.isNotBlank()) "${c.heroClass}/${c.multiclass}" else c.heroClass
        val latestPlayerText = c.messages.lastOrNull { it.role == "user" }?.content.orEmpty()
        val intentContext = ActionInterpreter.analyze(c, latestPlayerText)
        val turnContract = NarrativeTurnDirector.analyze(c, latestPlayerText)
        val memoryContext = CampaignMemory.context(c, intentContext)
        return buildString {
            appendLine("Ты — опытный ведущий D&D и соавтор сцены. Отвечай по-русски естественно, конкретно и без шаблонных повторов. Не превращай каждый ход в случайное событие и не повторяй погоду/запахи без причины.")
            appendLine(NarrativeTurnDirector.responseRules())
            appendLine("КОНТРАКТ ТЕКУЩЕГО ХОДА: ${turnContract.promptLine()}")
            appendLine("КОНТЕКСТ И ПАМЯТЬ: сохраняй причинно-следственную связь. Учитывай последние сообщения, память кампании, журнал мира, отношения, местоположение, здоровье, инвентарь, состояния и незавершённые угрозы. Не меняй факты задним числом. Если детали неизвестны — не выдумывай их как установленные факты.")
            appendLine("ДЕЙСТВИЯ ИГРОКА: сначала определи намерение и цель из естественного текста, включая опечатки, длинные описания и несколько связанных действий. Не пересказывай ввод игрока вместо разрешения действия. Не управляй героем и не приписывай ему мысли/решения. Если действие невозможно или неоднозначно критично — кратко уточни; иначе разреши его с логичными последствиями.")
            appendLine("БОЕВАЯ СИСТЕМА: веди бой пошагово по D&D 5e, если правила кампании не задают иное. Учитывай инициативу, КД, атаки, модификаторы характеристик, бонус мастерства, урон оружия/заклинаний, критические попадания, спасброски, состояния, концентрацию, действия/бонусные действия/реакции, перемещение, укрытия, сопротивления и ресурсы. Не придумывай броски задним числом: показывай формулу, результат кости, модификатор, итог и порог. Не разрешай больше действий, чем допускает ход. Если встроенный движок уже показал механику боя — не переигрывай её и не меняй числа.")
            appendLine("D&D 5E 2014 — ПОРЯДОК ХОДА: отличай действие, бонусное действие, перемещение и реакцию. Не выдавай бонусное действие автоматически: оно доступно только если способность/заклинание/правило прямо разрешает его. Дополнительная атака зависит от класса, уровня и листа персонажа; не предполагай её без основания. Проверяй концентрацию и длительность эффектов по событиям, а не по художественному тексту. При 0 HP используй спасброски от смерти и стабилизацию; не позволяй бессознательному персонажу действовать как обычно. Если точное правило отсутствует в данных кампании, явно обозначь временное допущение и не выдавай его за официальное правило.")
            appendLine("РЕЗУЛЬТАТ ДЕЙСТВИЯ: внутреннее состояние движка важнее предположений повествования. Текст может описывать только те изменения HP, предметов, условий, отношений и мира, которые подтверждены результатом действия или явно установлены сценой. Не создавай предметы, способности, броски или ресурсы задним числом.")
            appendLine("ФОРМАТ: сначала краткая сцена и разрешение заявленного действия; затем значимые броски/последствия; затем реплики и реакция мира. Диалог NPC должен отражать характер, знания и отношения, а не быть универсальным. Обычно 2–6 абзацев; подробный боевой лог — только в бою.")
            appendLine(modeBlock)
            appendLine("ЛИТЕРАТУРНОЕ РАЗРЕШЕНИЕ ДЕЙСТВИЙ: бросок определяет механику, а не заменяет повествование. После результата опиши конкретное движение, реакцию цели и последствия в контексте сцены. Учитывай дистанцию, оружие, поверхность, укрытия, предыдущие действия, характер и тактику противника. Не добавляй несуществующие бонусы, ранения, разрушения или изменения HP. Для попадания, промаха, критического успеха и провала используй разные, уместные описания. Сохраняй ясность механики и литературную живость одновременно.")
            appendLine("ПАМЯТЬ ПЕРСОНАЖЕЙ: используй отдельные профили NPC для устойчивого характера, голоса, целей и уже подтверждённых взаимодействий. Не смешивай профили разных NPC и не превращай предположение из одного эпизода в биографический факт. Изменения доверия/расположения должны иметь причину и развиваться постепенно; не придумывай числовые изменения состояния, если движок их не рассчитал.")
            appendLine("ГОТОВНОСТЬ И ГРАНИЦЫ: различай доверие, расположение, влечение, готовность и согласие на конкретное действие. Согласие конкретно для ситуации и отзываемо; отсутствие отказа не означает согласие. Если границы неизвестны, не выдумывай их — дай NPC выразить их естественно в диалоге. Не делай близость автоматической наградой за высокую симпатию и не заставляй NPC немедленно менять мнение без события.")
            appendLine("КОНТЕКСТ ОТНОШЕНИЙ: числовые шкалы — медленные ориентиры, не бросок на любовь и не команда NPC. Сначала интерпретируй целое действие и контекст, включая отрицание, шутку, цитату, гипотезу, неудачу и реакцию NPC. Не повышай доверие за фразу «я помогу», если помощь только обещана или провалилась. Один смешанный ход (например, помощь вместе с угрозой) нельзя сводить к автоматическому бонусу; опиши неоднозначные последствия и не делай числовой вывод без ясного основания. Не выводи романтическое влечение из дружбы, внешности, подарков, статуса или долга.")
            appendLine("ЕДИНЫЙ РЕЗУЛЬТАТ ДЕЙСТВИЯ (структурный анализ, не бросок): ${ActionResolutionEngine.context(c, c.messages.lastOrNull { it.role == "user" }?.content.orEmpty())}")
            appendLine("ЕДИНАЯ СИСТЕМА КАСТОМНЫХ ПРАВИЛ:\n${CustomRuleEngine.context(c).promptBlock()}")

            appendLine("РЕАКЦИИ NPC И ЧУВСТВИТЕЛЬНЫЕ СЦЕНЫ: реакции следуют из характера, истории, целей, знаний, культуры, страхов и установленных предпочтений конкретного NPC. Не выдумывай фетиши, травмы или согласие без основания в лоре. Принуждение не равно согласию; страх, оцепенение или уступка ради выживания не означают желания. Сцены угроз и сексуального насилия можно отражать через не-графические действия, реакцию персонажа, последствия и влияние на отношения/мир, но не эротизируй и не расписывай сексуальное насилие графически. Интимные действия допускаются только между взрослыми персонажами, способными дать согласие. Учитывай выбранный режим контента, не изменяя его настройки или значение.")
            appendLine(IntimacySceneGuidance.forCampaign(c))

            appendLine("КОНТЕКСТНЫЙ СЛОЙ ПОВЕСТВОВАНИЯ:")
            appendLine(CombatNarrator.guidance(c))
            appendLine("СЛОЙ КОНТЕКСТНОГО МАСТЕРА:\n$memoryContext")
            appendLine("Мир: ${c.worldName}. ${c.worldLore}")
            appendLine("Сезон: ${c.season}. Ландшафт: ${c.landscape}. Культура: ${c.culture}.")
            appendLine("Герой: ${c.heroName}, ${c.race}, $classLine ${c.level}/${c.maxLevel}, ${c.alignment}, красота ${c.beauty}/10, статус ${c.socialRank}, богатство ${c.wealth}, ${c.divineTier}.")
            if (c.traits.isNotBlank()) appendLine("Черты: ${c.traits}")
            if (c.mythicalTraits.isNotBlank()) appendLine("Мифическое: ${c.mythicalTraits}")
            if (c.mythicalAscension.isNotBlank()) appendLine("Вознесение: ${c.mythicalAscension}")
            if (c.raceTraits.isNotBlank()) appendLine("Механики расы: ${c.raceTraits}")
            if (c.classTraits.isNotBlank()) appendLine("Механики класса: ${c.classTraits}")
            if (c.customContracts.isNotBlank()) appendLine("Контракты/браки: ${c.customContracts}")
            appendLine("Внешность: ${c.appearance}. Предыстория: ${c.backstory}. Навыки: ${c.skills}.")
            appendLine("Характеристики: ${c.stats}. HP ${c.hp}/${c.maxHp}. Инвентарь: ${c.inventory.ifBlank { "не задан" }}. Состояния: ${c.conditions.ifBlank { "нет известных" }}.")
            if (c.campaignMemory.isNotBlank()) appendLine("КРАТКАЯ ПАМЯТЬ КАМПАНИИ (последние факты):\n${c.campaignMemory}")
            if (c.worldLog.isNotBlank()) appendLine("ЖУРНАЛ МИРА (последние события):\n${c.worldLog.lines().takeLast(12).joinToString("\n")}")
            if (c.combatActive) appendLine("БОЙ УЖЕ ИДЁТ: раунд ${c.combatRound}; враг ${c.combatEnemyName}, HP ${c.combatEnemyHp}/${c.combatEnemyMaxHp}, КД ${c.combatEnemyAc}; инициатива ${c.combatInitiative}. Не сбрасывай и не переопределяй эти значения.")
            appendLine("Текущая локация: ${c.lastLocation}. Последний NPC: ${c.lastNpc}. Последнее намерение героя: ${c.lastActionIntent}.")
            if (c.customRules.isNotBlank()) appendLine("Правила партии: ${c.customRules}")
            appendLine("Не управляй героем. NPC имеют цели. Красота влияет только на первое впечатление.")
            appendLine("Пиши 2–4 коротких абзаца: обстановка, действие героя, реплика NPC, выбор.")
        }
    }

    fun chat(c: Campaign, userMessage: String): String {
        // Правила боя считаются локально, чтобы модель не выдумывала броски и не сбрасывала HP.
        if (c.masterSource != "offline" && c.masterSource.isNotBlank()) {
            val turn = c.messages.count { it.role == "user" }
            CombatEngine.handle(c, userMessage, turn)?.let { return it }
        }
        // Локальные команды всегда без сети
        // Команды и опечатки всегда через офлайн-движок
        if (TextFuzzy.isSheetRequest(userMessage) || TextFuzzy.isNpcSheetRequest(userMessage) ||
            TextFuzzy.isStatus(userMessage) || TextFuzzy.isHelp(userMessage)) {
            return OfflineEngine.respond(c, userMessage)
        }
        if (c.masterSource == "local") {
            return LocalLlmEngine.chat(c, userMessage)
        }
        if (c.masterSource == "offline" || c.masterSource.isBlank()) {
            return OfflineEngine.respond(c, userMessage)
        }
        val key = c.apiKey
        if (key.isBlank() && c.masterSource != "ollama") {
            return OfflineEngine.respond(c, userMessage)
        }
        return try {
            when (c.masterSource) {
                "ollama" -> ollama(c, userMessage)
                else -> openAiCompatible(c, userMessage, key)
            }
        } catch (e: Exception) {
            "Сеть недоступна (${e.message?.take(80)}). Офлайн-ответ:\n\n" + OfflineEngine.respond(c, userMessage)
        }
    }

    private fun openAiCompatible(c: Campaign, userMessage: String, key: String): String {
        val base = when {
            c.baseUrl.isNotBlank() -> c.baseUrl.trimEnd('/')
            c.masterSource == "openrouter" -> "https://openrouter.ai/api/v1"
            else -> "https://api.openai.com/v1"
        }
        val model = c.model.ifBlank {
            if (c.masterSource == "openrouter") "openai/gpt-4o-mini" else "gpt-4o-mini"
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt(c)))
        c.messages.dropLastWhile { it.role == "user" && it.content == userMessage }.takeLast(30).forEach { m ->
            messages.put(JSONObject().put("role", if (m.role == "assistant") "assistant" else "user").put("content", m.content))
        }
        messages.put(JSONObject().put("role", "user").put("content", userMessage))
        val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.62).put("max_tokens", 2800)
        val conn = (URL("$base/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $key")
            if (c.masterSource == "openrouter") {
                setRequestProperty("HTTP-Referer", "https://tavern.local")
                setRequestProperty("X-Title", "Tavern RPG")
            }
            doOutput = true
            connectTimeout = 60000
            readTimeout = 120000
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(StandardCharsets.UTF_8).readText()
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(180)}")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    private fun ollama(c: Campaign, userMessage: String): String {
        val base = c.baseUrl.ifBlank { "http://127.0.0.1:11434" }.trimEnd('/')
        val model = c.model.ifBlank { "qwen2.5:7b" }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt(c)))
        c.messages.dropLastWhile { it.role == "user" && it.content == userMessage }.takeLast(30).forEach { m ->
            messages.put(JSONObject().put("role", if (m.role == "assistant") "assistant" else "user").put("content", m.content))
        }
        messages.put(JSONObject().put("role", "user").put("content", userMessage))
        val body = JSONObject().put("model", model).put("messages", messages).put("stream", false)
        val conn = (URL("$base/api/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
            connectTimeout = 30000
            readTimeout = 180000
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
        return JSONObject(conn.inputStream.bufferedReader(StandardCharsets.UTF_8).readText())
            .getJSONObject("message").getString("content")
    }
}
