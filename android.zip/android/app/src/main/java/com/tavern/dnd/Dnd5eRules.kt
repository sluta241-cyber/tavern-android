package com.tavern.dnd

import kotlin.random.Random
import kotlin.math.floor

/** Small, testable D&D 5e (2014) rules primitives. This module never generates narration. */
object Dnd5eRules {
    data class Roll(val die: Int, val modifier: Int, val total: Int) {
        val natural: Int get() = die
        val criticalSuccess: Boolean get() = die == 20
        val criticalFailure: Boolean get() = die == 1
    }
    data class AttackResult(
        val roll: Roll,
        val armorClass: Int,
        val hit: Boolean,
        val critical: Boolean,
        val damageRolls: List<Int>,
        val flatDamage: Int,
        val totalDamage: Int
    )
    data class DeathSave(val roll: Int, val successes: Int, val failures: Int, val stable: Boolean, val dead: Boolean)
    data class CheckResult(
        val firstDie: Int,
        val secondDie: Int?,
        val chosenDie: Int,
        val modifier: Int,
        val total: Int,
        val dc: Int,
        val mode: CustomRuleEngine.RollMode,
        val success: Boolean
    )

    fun abilityModifier(score: Int): Int = floor((score - 10) / 2.0).toInt()
    fun proficiencyBonus(level: Int): Int = 2 + ((level.coerceIn(1, 20) - 1) / 4)
    fun rollDie(sides: Int, rng: Random = Random.Default): Int = rng.nextInt(1, sides.coerceAtLeast(2) + 1)
    fun d20(modifier: Int = 0, rng: Random = Random.Default): Roll {
        val d = rollDie(20, rng)
        return Roll(d, modifier, d + modifier)
    }
    fun check(score: Int, proficiency: Boolean, level: Int, dc: Int, rng: Random = Random.Default): Pair<Roll, Boolean> {
        val modifier = abilityModifier(score) + if (proficiency) proficiencyBonus(level) else 0
        val r = d20(modifier, rng)
        return r to (r.total >= dc)
    }
    /** Ability/skill check with real advantage/disadvantage: roll two d20 and keep high/low. */
    fun checkWithMode(
        score: Int, proficiency: Boolean, level: Int, dc: Int,
        mode: CustomRuleEngine.RollMode = CustomRuleEngine.RollMode.NORMAL,
        rng: Random = Random.Default
    ): CheckResult {
        val modifier = abilityModifier(score) + if (proficiency) proficiencyBonus(level) else 0
        val first = rollDie(20, rng)
        val second = if (mode == CustomRuleEngine.RollMode.NORMAL) null else rollDie(20, rng)
        val chosen = when (mode) {
            CustomRuleEngine.RollMode.ADVANTAGE -> maxOf(first, second ?: first)
            CustomRuleEngine.RollMode.DISADVANTAGE -> minOf(first, second ?: first)
            CustomRuleEngine.RollMode.NORMAL -> first
        }
        return CheckResult(first, second, chosen, modifier, chosen + modifier, dc.coerceIn(1, 30), mode, chosen + modifier >= dc.coerceIn(1, 30))
    }

    fun attack(
        attackBonus: Int, armorClass: Int, damageDiceCount: Int, damageDieSides: Int,
        flatDamage: Int = 0, rng: Random = Random.Default, criticalThreshold: Int = 20
    ): AttackResult {
        val r = d20(attackBonus, rng)
        val hit = r.natural == 20 || (r.natural != 1 && r.total >= armorClass)
        val critical = hit && r.natural >= criticalThreshold.coerceIn(2, 20)
        val count = if (!hit) 0 else damageDiceCount.coerceAtLeast(1) * if (critical) 2 else 1
        val dice = (0 until count).map { rollDie(damageDieSides, rng) }
        val total = if (hit) (dice.sum() + flatDamage).coerceAtLeast(1) else 0
        return AttackResult(r, armorClass, hit, critical, dice, flatDamage, total)
    }
    fun deathSave(successes: Int, failures: Int, rng: Random = Random.Default): DeathSave {
        val roll = rollDie(20, rng)
        var s = successes.coerceIn(0, 3)
        var f = failures.coerceIn(0, 3)
        if (roll == 20) s = 3 else if (roll == 1) f = (f + 2).coerceAtMost(3)
        else if (roll >= 10) s = (s + 1).coerceAtMost(3) else f = (f + 1).coerceAtMost(3)
        return DeathSave(roll, s, f, s >= 3 && f < 3, f >= 3)
    }
}
