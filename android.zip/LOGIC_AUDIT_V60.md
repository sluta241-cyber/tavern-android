# Tavern v5.7.2 — CMake and source audit

## Fixed
- Moved llama.cpp CMake options before upstream CMake configuration so tests/examples/server and optional GPU backends are disabled at the right time.
- Reworked FetchContent flow to fetch the pinned `b4517` source explicitly, validate its checkout, and print an actionable error when network/source setup fails.
- Kept `arm64-v8a` as the sole target ABI.
- Updated app metadata to versionName 5.7.2 / versionCode 25 and aligned the structural audit.
- Preserved the protected `modeBlock` in `OnlineLlm.kt` byte-for-byte relative to the previous archive.

## Checks
- `python tools/verify_project.py`: 0 failures, 72 checks/notes.
- `tools/test_npc_knowledge_extractor.sh`: 14 tests passed.
- `tools/test_relationship_logic.sh`: execution timed out in this environment; no pass is claimed.
- `tools/test_narrative_turn_director.sh`: not run because the preceding test timed out.
- ZIP integrity check passed after packaging.
- Full Gradle/NDK APK build was not available in this environment. The screenshot contains only Gradle's final CMake process failure, not the first CMake diagnostic, so the exact CI failure cannot be confirmed from the screenshot alone.

## Known major limitation
`android/app/src/main/cpp/tavern_llama.cpp` is still an explicit JNI placeholder and does not perform inference. This archive improves CMake configuration but is not yet a working local LLM build. Network access to GitHub is required when a local llama.cpp checkout is not supplied.
