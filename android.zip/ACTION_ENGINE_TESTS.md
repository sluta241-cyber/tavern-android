# Action Resolution Engine — regression checks

The action classifier is a structured intent/context layer, not a dice roller. Combat attacks and combat movement/defense must still be handled by `CombatEngine`; the classifier must never mutate HP, inventory, relationship scores, or world state.

## Cases to verify

| Input | Expected kind | Expected safety property |
|---|---|---|
| `Атакую гоблина мечом` | `ATTACK` | `NEEDS_RULES_ENGINE`; no generated roll here |
| `Я не атакую, а опускаю меч` | not `ATTACK` | negation wins over weapon mention |
| `Что будет, если я атакую стражника?` | not `ATTACK` | hypothetical does not trigger attack resolution |
| `Крадусь мимо стражника` | `STEALTH` | check is marked as needing resolution; suggested DC is explicitly provisional |
| `Пытаюсь убедить купца снизить цену` | `SOCIAL` | ability suggestion is Charisma (Persuasion), no state mutation |
| `Осматриваю комнату` | `OBSERVE` | narrative-only unless a concrete check is actually rolled |
| `Что мне делать?` | `OBSERVE` | no irreversible world changes |
| empty string | `UNKNOWN` | `CLARIFY` |

## Scope and limitations

- Target selection currently uses the active combatant, last NPC, then last location as contextual fallback; it does not perform entity resolution over arbitrary prose.
- Suggested DCs are heuristics, not canonical D&D 5e rules. The DM must adjust them to the scene and campaign rules.
- No out-of-combat dice roll is claimed by this class. Actual dice and mechanical effects must be implemented by an authoritative rules engine before being narrated as facts.
- `OnlineLlm.systemPrompt` includes this result as a constraint. This improves instruction grounding but is not a guarantee that a language model will always obey it.
