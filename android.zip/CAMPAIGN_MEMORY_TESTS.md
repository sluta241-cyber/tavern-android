# Campaign memory v48 tests

## Retrieval and continuity checks

1. Given many unrelated event-log entries and a query mentioning a named NPC, relevant entries containing that NPC and overlapping terms rank above unrelated entries.
2. When the query has no meaningful overlap, established world facts and open threads remain eligible for retrieval; recent chronology is still included separately.
3. A journal line is labeled as chronology, not silently promoted to an objective fact.
4. World facts, open threads, event log, campaign memory and NPC profiles remain bounded.
5. NPC profile context prioritizes the current NPC and relevant profile/event text; it never infers new facts or consent.
6. `appendFact` and `appendThread` are idempotent for exact case-insensitive duplicates.
7. `closeThread` removes only an exact existing thread and records closure in campaign memory; missing thread returns false.
8. Old saves with missing `eventLog`, `worldFacts`, `openThreads`, or `npcProfiles` retain safe defaults. No schema migration is required.
9. `modeBlock` in `OnlineLlm.kt` remains byte-identical to v42.

## Limits

Retrieval uses lexical overlap, not semantic embeddings. It can miss paraphrases and is not a database of verified propositions. The LLM must continue to distinguish facts, reports, beliefs and scene narration. Full Android Gradle build/APK remains unverified until Gradle Wrapper files or a Gradle installation are available.
