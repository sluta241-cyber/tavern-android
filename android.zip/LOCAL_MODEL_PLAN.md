# Tavern v5.4 — local model preparation

## Candidate
- `Qwen/Qwen2.5-0.5B-Instruct-GGUF`, `Q4_K_M`, upstream model card: https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF
- Upstream lists Q4_K_M at approximately 491 MB and Apache-2.0 licensing. Actual downloaded size must be verified at runtime.
- Model is not bundled into the APK. The user explicitly downloads it into app-private storage, keeping the installer small and avoiding silently consuming storage/data.
- This uses the additional 250 MB budget to move from very aggressive quantization to a more capable 4-bit variant, while leaving headroom for runtime and application files within a roughly 600 MB total budget.

## Honest implementation status
`LocalModelStore` downloads, bounds, validates and deletes a GGUF file. It does **not** run inference yet. The project still needs a native Android build of `llama.cpp` (arm64-v8a, with ABI/package size and license notices checked), a JNI/NDK bridge, streaming token callbacks, cancellation, memory-pressure handling, and integration with `OnlineLlm` routing. No model weights or native runtime are included in this source ZIP, and no fine-tuning has been performed.

## Recommended integration sequence
1. Build pinned `llama.cpp` native library for Android arm64-v8a with Android NDK/CMake; include upstream license and notices.
2. Add JNI adapter exposing `loadModel(path, contextSize)`, `generate(system, history, user, sampling, callback)`, `cancel()`, and `unload()`.
3. Route `masterSource == "local"` to that adapter; never silently fall back to an online provider.
4. Use a 2048–4096 context initially; limit output and report memory requirements. Model file size is not the same as runtime RAM requirement.
5. Run a fixed Russian RPG evaluation set before considering fine-tuning. Store train/dev/test splits separately to prevent leakage.

## License
Qwen2.5 model card states Apache-2.0. Preserve upstream model attribution and license text when redistributing model weights. Native runtime has its own license and notices; verify the pinned revision before packaging.
