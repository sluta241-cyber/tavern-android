# Tavern v5.2 — logic and consistency audit

## Issues found and corrected

1. **Unrelated NPC profiles could leak into prompt context.** Query matching previously used substring checks and common words, so generic text could select unrelated profiles. It now removes a conservative stop-word set, tokenizes both sides, uses exact token membership, and omits zero-score profiles.
2. **Active NPC labels could double-count the same character.** A label like `трактирщик Борис` and a stored profile named `Борис` could make attribution ambiguous and suppress relationship updates. The active label is not added as a second candidate when a profile with the same final name exists.
3. **Inflected Russian names were missed.** NPC attribution now checks common forms such as `Бориса` and `Борису`, including common forms for names ending in `-й`.
4. **Relationship deltas could create duplicate profile keys.** Relationship updates now resolve an existing profile key by its canonical name/final-name alias before creating a new profile.
5. **Repeated extracted claims could evade deduplication.** The turn number is stored in the dedicated `turn` field and is no longer appended to the source label.
6. **Profile display names could be overwritten by role-prefixed aliases.** Existing profile names are preserved when a role-prefixed label resolves to the same profile.
7. **Hypothetical wording could suppress a later real claim in the same message.** Extraction now checks hypothetical markers within the current clause rather than the whole recent prefix.
8. **Relationship attribution could target a bystander mentioned only by the model.** The resolver now prefers player-authored name mentions; reply-only fallback is limited to the active scene NPC.
9. **API failures could pollute the in-world event log.** Error replies now stay in chat history but do not get recorded as campaign events, compact memories, relationship updates, or NPC knowledge.
10. **NPC profile-cap eviction was inconsistent.** Some write paths did not enforce the 40-profile limit, and JSON key order was not a reliable age signal. All profile write paths now update a nested `updatedTurn` marker and evict the least-recently-updated unprotected profile.
11. **Knowledge deduplication missed `ё`/`е` and whitespace variants.** Fact/source comparison now normalizes these before deduplicating.
12. **Mode labels differed from the requested wording.** Visible labels are now `Детская`, `Взрослая`, and `Полное отсутствие цензуры`; internal values remain `child`, `adult`, and `uncensored`.

## Guardrails

- Automatic extraction reads only player-authored text and only recognizes explicit constructions such as `я рассказал NPC, что ...`, `NPC видел, как ...`, or `NPC слышал слух, что ...`.
- Quoted, negated, hypothetical, and ambiguous-name cases are skipped.
- Extracted `told` claims mean the NPC was told the claim, not that the claim is true. `rumor` and `observed` remain distinct certainty labels.
- Assistant-generated prose is not automatically promoted to a durable fact or NPC knowledge.
- Campaign save schema remains version 6; no new top-level campaign field was added.
- The protected `modeBlock` in `OnlineLlm.kt` was compared against v42 and is byte-identical.

## Verification status

- `tools/verify_project.py`: 0 failures (check count is reported by the script).
- `tools/test_npc_knowledge_extractor.sh`: passed 14 extraction assertions.
- `tools/test_relationship_logic.sh`: passed 4 resolver/classifier assertions using test-only JSON stubs; JSON persistence itself is not exercised by that harness.
- The changed memory/relationship Kotlin core compiled with lightweight JSON and service stubs; this is a syntax/type check for those files, not an Android build.
- ZIP integrity checked after packaging.
- Full Android/Compose build and device runtime tests remain **unverified** because the project archive does not contain `android/gradlew`, `android/gradlew.bat`, or `android/gradle/wrapper/gradle-wrapper.jar`, and no system Gradle executable is installed in this environment.
