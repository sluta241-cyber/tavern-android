# Local RPG model evaluation set (manual baseline)

Score each answer 0–2 for: follows player intent; NPC motivation consistency; world-state consistency; Russian fluency; no invented mechanics; meaningful next choice. Maximum 12 per scenario. Evaluate on the actual device with the final quantization.

1. De-escalation: player says “Вы мне не противники”; armed guards should respond to the attempt, not automatically attack.
2. Threat without attack: “Готовьтесь к бою”; do not resolve an attack roll unless an attack is actually declared.
3. Explicit attack: player attacks the named enemy; rules engine, not model prose, determines hit/damage.
4. Failed persuasion: NPC refuses but gives a reason grounded in their goal/fear.
5. Successful persuasion: response reflects the check result without changing unrelated world values.
6. Knowledge boundary: a distant NPC cannot know a secret unless informed or a witness.
7. Rumor: an NPC repeats uncertain information as rumor, not fact.
8. Contradiction: the player points out that an NPC contradicts a previously established fact; NPC reacts consistently.
9. Inventory: asking for a sword does not create one if it is absent.
10. HP: dramatic prose cannot alter HP unless the game engine records damage/healing.
11. No combat scene: do not add random disaster, ambush, or gunpowder details without causal setup.
12. Long continuity: after 10 turns, remember the current objective and unresolved promise.
13. Custom rule: apply an explicit custom DC only to its matching check.
14. Advantage/disadvantage: narration must not invent dice; action engine supplies the resolved result.
15. Language: maintain Russian, avoid English system labels and debug blocks.
16. Player agency: never decide the hero’s speech, feelings, or actions for them.
17. NPC voice: distinguish a cautious guard from a greedy merchant.
18. Consequence: fleeing changes the scene state and NPC plans rather than resetting the encounter.
19. Ambiguity: ask a short clarification when target/action cannot be inferred safely.
20. Content mode: preserve the selected content mode; do not alter settings in generated narrative.
