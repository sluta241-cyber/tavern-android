# Tavern Standalone — Android Studio project

Current package version: v5.2.0. The notes below retain the project history; see the latest v5.2 section for current behavior and verification status.

## v42 changes
- Added `CombatNarrator.kt`: guidance for cinematic, contextual narration after mechanics have already resolved.
- Improved `NarrativeDirector.kt` for varied action descriptions, physical continuity, character voice, and scene-specific pacing.
- Improved `NpcBrain.kt` for reactions grounded in established NPC traits, knowledge, motives, history, and agency.
- Added narrative and NPC-reaction guidance to `OnlineLlm.systemPrompt`.
- The three content modes and their selector values/labels are preserved. The existing `modeBlock` definition was not changed.
- Sensitive coercion/sexual-violence scenes are handled as non-graphic dramatic consequences; coercion is not framed as consent or automatically eroticized.

## Important
This pass improves the model's instructions and narrative scaffolding; it does not itself guarantee that every local model will follow them. Combat state and dice remain governed by the rules engine. A complete build should be verified in an Android/Gradle environment.


## v42 — NPC Memory & Readiness
- Отдельное хранилище профилей NPC, не конфликтующее с legacy-снимком активного NPC офлайн-движка.
- Профили хранят устойчивые известные черты, цели, манеру речи, границы и готовность как «не установлено», пока они не заданы явно.
- История взаимодействий ограничена по размеру и сохраняется в JSON вместе с кампанией.
- Промпты различают доверие, симпатию, влечение, готовность и согласие; отказ/неуверенность не превращаются в автоматическое согласие.
- Схема сохранения обновлена обратно-совместимо: старые кампании получают пустой профильный реестр.
- Параметры режимов контента и блок выбора режима не изменялись.


## v42 — Relationship Engine & Intimacy Scene Craft
- Добавлен отдельный слой сцен романтики/близости, не изменяющий выбор режима контента.
- Взрослые взаимные сцены получают конкретную последовательность действий, реакций, диалога и эмоциональных последствий вместо одних метафор или автоматического fade-to-black.
- Сцены остаются не-графическими в отношении анатомических деталей сексуального акта; режим CHILD не допускает сексуальных подробностей.
- Добавлен консервативный движок отношений: только явно выраженные сигналы игрока могут менять доверие/расположение/страх; значения ограничены -100..100, а причины записываются в историю NPC.
- Отдельно зафиксировано: рост доверия не равен влечению, готовности или согласию; эти вещи не выводятся автоматически из числовых шкал.
- Схема сохранения повышена до v5; старые кампании остаются совместимыми через значения по умолчанию.
- Блок выбора режима (`modeBlock`) не изменён.


## v42 — Context-aware relationship bookkeeping
- Relationship classifier now ignores common negation, hypothetical phrasing and quoted text.
- Relationship updates are applied with the NPC reply available, allowing obvious failed/rejected positive actions to be ignored.
- Mixed positive/negative signals in one turn do not automatically stack contradictory deltas.
- Relationship context explicitly separates trust, affection, attraction, readiness and consent; attraction stays unknown unless established.
- Added a manual test matrix for common false-positive cases.
- The content-mode selection block is unchanged.


## v42 — Conservative action bookkeeping and save resilience
- Relationship updates now require a current-turn mention of the NPC, rather than blindly applying to a stale `lastNpc`.
- Quoted actions are filtered per matched action; a quote elsewhere in the message no longer suppresses every relationship change.
- Negation is checked near each matched action, and the de-escalation phrase “не буду давить” remains a positive boundary-respecting signal.
- Positive relationship changes require completed-action phrasing; promises and ongoing help attempts do not automatically grant trust.
- Failed/error responses do not write NPC relationship/profile updates.
- Save listing skips a damaged individual campaign record instead of making the entire list fail.
- Numeric state invariants are repaired after turns; content-mode selection and its `modeBlock` remain untouched.
- App version bumped to 4.2.0 / versionCode 10.
- Build is not verified: no Gradle wrapper scripts/JAR are included and system Gradle is unavailable in the current environment.

- Follow-up static review fixed straight-quote filtering (including the consumed boundary character), made NPC profile keys locale-stable, and closes invalid active-combat records that have no valid enemy.


## v43 — Project reliability baseline
- Added `tools/verify_project.py`, a repeatable offline structural audit for required files, app/schema metadata, save compatibility markers, merge-conflict markers, and the protected content-mode selector.
- Bumped app metadata to 4.3.0 / versionCode 11.
- The selector block and its three values/labels were preserved exactly.
- This is a structural audit, not a successful Android build: the archive still lacks the Gradle Wrapper scripts/JAR, and this pass does not claim `assembleDebug` or device testing.

## v4.4.0 — Unified action intent layer

- Added `ActionResolutionEngine`: a structured classification of intent, likely target, resolution path, provisional check suggestions, and explicit state-change constraints.
- Wired the structured action context into the online master prompt. This is an intent contract, not a claim that a non-combat die roll has already happened.
- Combat mechanics remain owned by `CombatEngine`; no content-mode values or labels were changed.
- See `ACTION_ENGINE_TESTS.md` for regression cases and known limitations.

## v4.5.0 — Unified custom rules
- Connected existing campaign house rules and custom race/class mechanics through `CustomRuleEngine` for online and offline master prompts.
- Explicit campaign rules now have documented precedence over baseline D&D 5e rules; ambiguous mechanics must be clarified rather than invented.
- Explicit numeric DC overrides such as `СЛ скрытности 17` and `СЛ для убеждения: 9` feed into action classification.
- Existing content-mode labels and values remain unchanged.
- Added `CUSTOM_RULES_INTEGRATION_TESTS.md`; app metadata is 4.5.0 / versionCode 13.
- Free-text rules beyond the supported DC patterns are contextual instructions, not guaranteed executable mechanics.


## v4.7.0 — Executed custom check rolls
- Added a testable D&D 5e check primitive that actually rolls two d20 for advantage/disadvantage and selects high/low.
- Connected supported non-combat checks to the offline master; the result is shown and failed social checks no longer award the default trust increase.
- Skill proficiency is applied when the skill is listed in the campaign skills field.
- Existing content-mode selector is protected and unchanged.
- This remains a partial rules implementation; see `CUSTOM_RULES_EXECUTION_TESTS.md`.


## v48 — Campaign memory retrieval
The campaign memory context now ranks saved facts, unresolved threads, turn records and compact summaries against the current player input, intent, NPC and location. NPC profile context is relevance-ranked and bounded. See `CAMPAIGN_MEMORY_TESTS.md` for behavior and limitations. Retrieval is lexical, not semantic, and does not certify a narrated event as objective fact.


## v4.9.0 — memory retrieval and chat UI refresh
- Campaign memory search now uses normalized Russian tokens, conservative suffix stemming, small RPG-domain synonym groups and bounded fuzzy matching for longer tokens. Retrieval remains lexical and does not certify a journal entry as objective truth.
- Refreshed the Compose UI with a light neutral palette, blue accent, more generous spacing, rounded campaign cards and cleaner chat message surfaces, inspired by modern AI chat apps without copying DeepSeek branding.
- App version bumped to 4.9.0 / versionCode 17. Existing content-mode selector values and labels remain protected.
- See `MEMORY_AND_UI_V49_TESTS.md`. Full Android build/device test remains unverified if the Gradle wrapper is unavailable.


## v5.0.0 — theme toggle and in-app guide
- Added persistent white/near-black app theme switch in Settings. The preference is stored separately from campaign saves.
- Added a Russian in-app guide reachable from the home screen, with seven native illustrated interface diagrams and instructions for campaigns, chat, sheets, rules, modes, memory and theme.
- The guide illustrations are built from Compose UI elements, so they work offline and do not depend on remote images.
- Content mode selector and values are unchanged.
- See `THEME_AND_GUIDE_V50_TESTS.md`. Full Android build/device test remains unverified.


## v5.1 changes
- Added explicit provenance-aware NPC knowledge records (source, certainty, turn, location).
- Added search support for saved NPC knowledge and prompt instructions to avoid knowledge leakage between NPCs.
- NPC interaction chronology now labels turn and location.
- App version 5.1.0 (versionCode 19).
- No Campaign schema fields added; existing saves remain compatible.
See `NPC_KNOWLEDGE_AND_CHRONOLOGY_V51.md` and `MEMORY_AND_UI_V51_TESTS.md`.

## v5.2.0 — NPC knowledge extraction and logic audit
- Added conservative extraction of explicit knowledge transfer, witnessed-event, and rumor statements from the player's own text.
- Extraction ignores quoted, negated, hypothetical, and ambiguous-NPC cases; model-generated prose is not used as a knowledge source.
- Fixed NPC profile relevance scoring to use token equality and exclude unrelated zero-score profiles.
- Fixed canonical NPC attribution for role-prefixed labels and common Russian name inflections, avoiding duplicate profile keys.
- Fixed deduplication so turn number is stored in the `turn` field rather than changing the source label.
- Visible content-mode labels use the requested wording while internal values and the protected `OnlineLlm.modeBlock` remain unchanged.
- App version 5.2.0 / versionCode 20. Save schema remains v6.
- See `NPC_KNOWLEDGE_EXTRACTION_V52_TESTS.md` and `LOGIC_AUDIT_V52.md`. Run `tools/test_npc_knowledge_extractor.sh` and `tools/test_relationship_logic.sh` on a machine with `kotlinc` to repeat the isolated smoke tests.


## v5.3.0 — Narrative turn contract

- Added `NarrativeTurnDirector`: deterministic classification of de-escalation, negotiation, threats, explicit attacks, questions, and observations.
- The online master prompt now receives a per-turn contract with specific reaction requirements. A statement like “Вы мне не противники” is classified as de-escalation and must not start combat by itself. “Готовьтесь к бою” is a threat/declaration, not an attack roll.
- Added response rules to suppress raw diagnostic world-state blocks in ordinary narrative turns, prevent random filler catastrophes, and require a direct response to the player's actual words.
- Reduced online generation temperature from 0.78 to 0.62 to reduce scene drift (does not guarantee model quality).
- Added `tests/NarrativeTurnDirectorSmoke.kt` and `tools/test_narrative_turn_director.sh`.

Validation: narrative director smoke tests and NPC knowledge extraction tests passed; structural audit passed with 0 failures. Relationship test runner was started but did not finish within the allotted test window. Full Android/Gradle build and on-device test remain unverified because Gradle wrapper script/JAR are missing.
