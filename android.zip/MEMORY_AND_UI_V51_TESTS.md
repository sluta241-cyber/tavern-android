# v5.1 memory regression checklist

- [ ] `recordKnowledge` accepts only observed/told/rumor/inferred/disproven.
- [ ] Empty NPC name or fact is rejected.
- [ ] Duplicate fact + source + certainty is stored once.
- [ ] Distinct sources or certainty values remain distinct entries.
- [ ] Per-NPC knowledge is capped at 30 items.
- [ ] Knowledge text participates in profile retrieval.
- [ ] Prompt distinguishes observations, reports, rumors, inferences and disproven claims.
- [ ] NPC A's knowledge is never copied automatically to NPC B.
- [ ] Interaction history includes turn and location.
- [ ] Existing `npcProfiles` JSON and older saves remain readable.
- [ ] Light/dark theme persistence and in-app guide from v50 remain unchanged.
- [ ] `modeBlock` in `OnlineLlm.kt` remains byte-identical to the protected v42 baseline.

Full Android build and device UI checks are still required separately.
