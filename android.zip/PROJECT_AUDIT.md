# Tavern project audit — current v5.2

- Version bumped to 4.6.0 / code 14.
- Added a narrow executable house-rule parser for explicit DCs, player critical threshold, and advantage/disadvantage metadata.
- Player attack critical threshold is consumed by `Dnd5eRules` through `CombatEngine`; other arbitrary combat changes are intentionally not executed.
- Action resolution exposes roll mode for check actions but does not claim a check was rolled.
- Existing campaign editor fields and labels remain unchanged.
- Protected content-mode selector in `OnlineLlm.kt` must match the v42 baseline exactly.
- Static project audit and isolated Kotlin smoke tests are performed separately.
- Full Android Gradle build/APK is not claimed: wrapper scripts/JAR and installed Gradle are unavailable.


## v47 update
- Added executable non-combat check rolls with actual advantage/disadvantage selection.
- OfflineEngine displays the result and uses failed social checks to avoid default trust gains.
- Version metadata: 4.7.0 / versionCode 15.
- Full Android Gradle build has not been claimed; wrapper scripts/JAR are still absent.


## v48 update
- Added query-aware relevance retrieval across saved world facts, open threads, turn chronology, and compact campaign summaries.
- NPC profile context now ranks profiles by current NPC and lexical relevance, with a bounded selection.
- Added duplicate-safe open-thread insertion and an explicit exact-match `closeThread` operation.
- Context distinguishes chronology from objective facts and reiterates that narrated details are not automatically verified facts.
- Version metadata: 4.8.0 / versionCode 16.
- No campaign schema migration required; existing serialized memory fields are reused.
- Protected content-mode selector in `OnlineLlm.kt` must match v42 byte-for-byte.
- Static audit/ZIP checks are not a full Android build; full APK remains unverified.


## v5.1 update
Added explicit NPC knowledge provenance API and retrieval participation. The API does not auto-extract knowledge from narrative text; callers must provide source and certainty. Static project audit is not a full Android build.


## Automated v5.1 verification snapshot
- `tools/verify_project.py`: 0 failures, 47 checks/notes.
- `NpcProfileMemory.kt` plus `Models.kt` passed Kotlin syntax/type compilation against lightweight `org.json` stubs; this is not a full Android compilation or runtime test.
- Full Gradle/Android build remains unverified because the wrapper script and wrapper JAR are absent.


## Current v5.2 audit snapshot
- Static verifier: 0 failures; profile relevance, knowledge extraction, error-turn exclusion, relationship attribution, content labels, and version metadata are checked.
- 14 extractor smoke assertions and 4 relationship/classifier smoke assertions passed.
- Changed memory/relationship Kotlin core type-compiled with lightweight test stubs. This is not a full Android build.
- `OnlineLlm.modeBlock` remains byte-identical to the v42 baseline.
