# Tavern v5.0.0 — theme and in-app guide checks

## Implemented
- White and near-black theme switch in Settings.
- Theme preference stored separately in `tavern_ui/dark_theme`, not in campaign data.
- System status/navigation bar colors and contrast icons follow selected theme.
- Help screen reachable from the home screen, with seven illustrated guide cards made from native Compose shapes/text (no network/image dependency).
- Theme toggle does not modify campaign content mode or custom rules.

## Manual test checklist
1. Launch app fresh: white theme is default.
2. Open Settings, switch to black theme: surfaces, text, chat bubbles and system bars update.
3. Navigate home/chat/settings and verify theme remains consistent.
4. Force-stop and relaunch: selected theme is restored.
5. Switch back to white and relaunch: white theme is restored.
6. Open Help from home, scroll all seven sections, press Back and confirm home screen returns.
7. Open a campaign and send a message; verify chat input and bubbles remain readable in both themes.
8. Confirm campaign mode labels/values remain `child`, `adult`, `uncensored` and are not changed by theme selection.

## Verification boundary
This change is source-level implementation and static inspection. Full Android Gradle build and device/emulator testing must be performed in an Android build environment. The source archive does not include the complete Gradle Wrapper scripts/JAR.
