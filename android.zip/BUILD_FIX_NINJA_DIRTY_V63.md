# Tavern v5.7.4 — Ninja manifest dirty fix

## What the log says

`ninja: error: manifest 'build.ninja' still dirty after 100 tries` means Ninja repeatedly sees its generated build manifest as needing regeneration. The repeated `OpenSSL not found, HTTPS support disabled` messages are warnings, not the fatal error shown here.

## Change in this revision

`android/app/src/main/cpp/CMakeLists.txt` now uses `FetchContent_MakeAvailable(llama_cpp_upstream)` rather than manually calling `FetchContent_GetProperties` / `FetchContent_Populate` and then `add_subdirectory`. This lets CMake manage population and configuration in the standard supported flow.

## Important: clear the stale Android native build cache in CI

Before running Gradle in GitHub Actions, add this step:

```yaml
- name: Clean Android native CMake cache
  working-directory: extracted_project/android
  run: rm -rf app/.cxx app/build/intermediates/cxx
```

Then build:

```bash
./gradlew --no-daemon --stacktrace :app:assembleDebug
```

If your workflow extracts the project into a different directory, adjust `working-directory` to that project's `android` folder. Do not delete the whole Gradle cache unless needed; clearing `.cxx` and native intermediates is the targeted cleanup.

## Validation status

This source archive was checked structurally and its ZIP integrity verified. A full Android APK build was not run in this environment. If the same Ninja error persists after a clean native cache, preserve the first CMake regeneration output and the `build.ninja` / `CMakeFiles/rules.ninja` timestamps for diagnosis.
