# v5.2 — NPC knowledge extraction regression tests

## Automated isolated Kotlin smoke tests

`NpcKnowledgeExtractor.kt` was compiled with the available `kotlinc` compiler and exercised in a standalone harness. These tests cover:

1. `Я рассказал Борису, что дракон живёт в старой башне.` → one `told` claim.
2. `Борис видел, как разбойник украл ключ.` → one `observed` claim.
3. `Борис слышал слух, что мост обрушился ночью.` → one `rumor` claim.
4. `Борису сообщили, что караван прибудет завтра.` → one `told` claim.
5. `Я не рассказал Борису...` → no claim.
6. `Если бы я рассказал Борису...` → no claim.
7. A hypothetical clause followed by a separate explicit statement (period- and comma-separated) → only the latter is extracted.
8. A claim entirely inside quotation marks → no claim.
9. Two known NPC candidates sharing the same final name → no claim, avoiding ambiguous attribution.
10. Dative inflection for a name ending in `-й` (`Алексей` → `Алексею`) → one claim.
11. Empty known-NPC list → no claim.
12. An explicit NPC-specific denial vetoes the claim.
13. An error reply vetoes extraction.
14. Disbelief does not erase the fact that the NPC was told.

Result: **14 NPC knowledge-extractor smoke assertions passed**. A separate relationship-logic smoke suite passed 4 assertions using test-only JSON stubs (so it validates resolver/classifier logic, not JSON persistence).

## Integration and regression checks

- `CampaignMemory.recordTurn` passes only the player's text to the extractor. The LLM reply is deliberately not used as an extraction source.
- Extracted claims retain their `certainty` and stable `source`; turn and location are stored in their dedicated fields. The turn number is not appended to the source string, so repeated identical claims can be deduplicated across turns.
- API errors are excluded from campaign event/compact memory and NPC updates. Narrow, NPC-specific denial phrases can veto an extracted claim; generated narration is never used to create a claim.
- Existing `npcProfiles` JSON storage is reused; campaign schema remains v6. All profile mutation paths share the same 40-profile cap and preserve the profile currently being updated. Knowledge deduplication normalizes whitespace, case, and `ё`/`е`.
- The NPC profile prompt filters unrelated zero-score profiles and compares token equality instead of substring matches.
- NPC attribution supports common Russian name inflections and resolves a role-prefixed active label to an existing profile where possible. Relationship changes prefer names in player-authored text; an NPC mentioned only in generated narration is not selected unless it is the active scene NPC.
- Content mode values are unchanged; visible labels use the requested wording. The `modeBlock` code block matches the v42 baseline byte-for-byte.

## Limits

Extraction is intentionally rule-based and narrow. It does not parse arbitrary narration, infer witnesses from geography, determine whether a claim is objectively true, or infer knowledge from the assistant's generated prose. Unsupported phrasings should be added with regression tests before being enabled.
