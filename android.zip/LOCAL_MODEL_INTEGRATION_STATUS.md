# v5.4 implementation status

- [x] Candidate selected: Qwen2.5-0.5B-Instruct GGUF Q4_K_M (upstream card reports ~491 MB; Apache-2.0).
- [x] Explicit user-triggered download/storage manager added; no automatic network download.
- [x] Storage cap, free-space preflight, partial-file cleanup, GGUF magic check, and delete/status helpers.
- [x] 20-scenario Russian RPG evaluation plan added.
- [x] Version bumped to 5.4.0 / versionCode 22.
- [x] Content mode block left unchanged.
- [ ] Native llama.cpp Android library/JNI bridge is NOT included.
- [ ] Model weights are NOT bundled/downloaded during this build session.
- [ ] No fine-tuning performed; no new model weights created.
- [ ] Local model is NOT selectable as a working master in UI yet.
- [ ] Full APK build/device performance tests not performed.

This is an honest integration-preparation release, not a claim that local inference already works. Next engineering gate is to pin and build llama.cpp with Android NDK, then wire JNI into master routing and verify inference on a real device before labeling the feature “Local model”.
