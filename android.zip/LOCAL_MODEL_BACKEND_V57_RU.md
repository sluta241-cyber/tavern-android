# Tavern v5.7.2 — CMake troubleshooting

CMake now prefers `android/app/src/main/cpp/llama.cpp` if present and otherwise fetches the pinned upstream tag `b4517` via FetchContent. This requires network access to GitHub during native configuration. For offline/reproducible builds, vendor or checkout the same revision locally.

The JNI function remains a fail-closed placeholder and does not run inference. Do not describe this build as a working local LLM until the model load/tokenize/decode/sample/detokenize/free lifecycle is implemented and tested on device.
