# Relationship engine manual test matrix (v42)

The current implementation is intentionally conservative. It is a heuristic, not full natural-language understanding.

| Player text | Expected relationship change |
|---|---|
| `Я спас стражника от волка` | small positive trust/affection, only if the reply doesn't say the rescue failed |
| `Я не угрожаю ей` | no change |
| `Если бы я предал его, он бы мне не доверял` | no change |
| `Я угрожаю торговцу, требуя ключ` | negative trust/affection, increased fear, if that NPC is confirmed as the current target |
| `Я извинился за то, что сделал` | small positive trust, not automatic forgiveness |
| `Я обещаю помочь завтра` | no change; a promise is not completed help |
| `Я помогаю ей подняться` | no change by itself; ongoing/ambiguous action isn't treated as completed |
| `Я говорю: «я тебя предал» — это цитата из письма` | no change for quoted action |
| `Я пишу в письме: "я предал его"` | no change for action inside straight quotes |
| `Я не буду давить, останавливаюсь и отступаю` | small trust increase for explicit de-escalation |
| `Я не буду давить, останавливаюсь и отступаю` | small trust increase for explicit de-escalation |
| a response beginning `Ошибка:` | no NPC relationship/profile update |
| reply mentions a different NPC than stale `lastNpc` | don't attach the turn to stale NPC unless that NPC is actually mentioned |

## Remaining limitations
- No full Kotlin/Android build was run because the archive has no `gradlew`, wrapper JAR, and this environment has no system Gradle/Kotlin compiler.
- Regex heuristics can still misread sarcasm, complex syntax, or ambiguous Russian phrasing. The long-term fix is a structured action-resolution object produced by the game engine, with success/failure determined before relationship deltas are committed.
