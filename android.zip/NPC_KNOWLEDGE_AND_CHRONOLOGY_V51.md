# Tavern v5.1 — provenance-aware NPC knowledge and chronology

## Changes
- NPC profiles can store a knowledge item with `fact`, `source`, `certainty`, `turn`, and `location`.
- Allowed certainty values: `observed`, `told`, `rumor`, `inferred`, `disproven`. Invalid values are rejected.
- Identical fact/source/certainty records are deduplicated; the profile stores at most 30 knowledge items.
- Knowledge facts are included in NPC-profile search text, so a query can retrieve a profile based on a saved knowledge item.
- Recent interaction entries now include turn and location labels to make chronology easier to inspect.
- Prompt guidance explicitly prevents transferring knowledge between NPCs without a source event.
- No new Campaign fields were added; knowledge is embedded in the existing `npcProfiles` JSON field, preserving old-save compatibility.

## Important limitation
This version adds the provenance-aware storage/retrieval API but does not automatically extract and verify knowledge from free-form model prose. The game or a future structured event pipeline must call `NpcProfileMemory.recordKnowledge(...)` with a grounded source and certainty. Narration is not automatically promoted to knowledge.

## Suggested checks
- Store an observed fact for NPC A and verify NPC B does not receive it in their profile.
- Store a rumor and verify prompt context labels it as `rumor`.
- Reject unsupported certainty values.
- Add the same fact/source/certainty twice and verify only one entry remains.
- Verify turn and location appear in recent NPC interactions.
- Open a v5.0 save and verify it still loads with empty knowledge arrays until entries are explicitly recorded.
