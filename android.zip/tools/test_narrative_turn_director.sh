#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/android/app/src/main/java/com/tavern/dnd/Models.kt" \
  "$ROOT/android/app/src/main/java/com/tavern/dnd/NarrativeTurnDirector.kt" \
  "$ROOT/tests/NarrativeTurnDirectorSmoke.kt" \
  -include-runtime -d "$OUT/test.jar"
java -jar "$OUT/test.jar"
