#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc \
  "$ROOT/android/app/src/main/java/com/tavern/dnd/NpcKnowledgeExtractor.kt" \
  "$ROOT/tests/NpcKnowledgeExtractorSmoke.kt" \
  -include-runtime -d "$TMP/npc-knowledge-tests.jar"
java -Dfile.encoding=UTF-8 -jar "$TMP/npc-knowledge-tests.jar"
