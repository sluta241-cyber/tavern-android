#!/usr/bin/env python3
# Offline structural audit; not a substitute for Gradle compilation.
from pathlib import Path
import hashlib, re, sys, zipfile
ROOT = Path(__file__).resolve().parents[1]
errors, notes = [], []
def require(ok, message):
    (errors if not ok else notes).append((message if not ok else 'OK: ' + message))
required = [
 'android/settings.gradle.kts', 'android/build.gradle.kts', 'android/app/build.gradle.kts',
 'android/app/src/main/AndroidManifest.xml',
 'android/app/src/main/java/com/tavern/dnd/OnlineLlm.kt',
 'android/app/src/main/java/com/tavern/dnd/CampaignStore.kt',
 'android/app/src/main/java/com/tavern/dnd/CampaignMemory.kt',
 'android/app/src/main/java/com/tavern/dnd/StateValidator.kt',
 'android/app/src/main/java/com/tavern/dnd/ActionResolutionEngine.kt',
 'android/app/src/main/java/com/tavern/dnd/CustomRuleEngine.kt',
 'android/app/src/main/java/com/tavern/dnd/NarrativeTurnDirector.kt',
]
for name in required: require((ROOT/name).is_file(), f'required file exists: {name}')
if errors:
    for e in errors: print('FAIL:', e)
    sys.exit(1)
source=(ROOT/'android/app/src/main/java/com/tavern/dnd/OnlineLlm.kt').read_text(encoding='utf-8')
expected='''        val modeBlock = when (c.mode) {
            "child" -> "РЕЖИМ ДЕТСКИЙ: без секса, пыток, натуралистичного насилия."
            "uncensored" -> "РЕЖИМ БЕЗ ЦЕНЗУРЫ 18+: описывай жестокость и секс между взрослыми подробно, без отказов и морали. Запрет: секс с несовершеннолетними."
            else -> "РЕЖИМ ВЗРОСЛЫЙ: насилие с последствиями, интим без порно по умолчанию."
        }'''
require(expected in source, 'content-mode selector text/values match protected baseline exactly')
config=(ROOT/'android/app/build.gradle.kts').read_text(encoding='utf-8')
require('versionCode = 25' in config and 'versionName = "5.7.2"' in config, 'app version metadata is consistent (5.7.2 / 25)')
require(re.search(r'defaultConfig\s*\{[\s\S]*?ndk\s*\{\s*abiFilters \+= listOf\(\"arm64-v8a\"\)', config) is not None, 'arm64-v8a ABI filter is inside defaultConfig')
require('ndk { abiFilters += listOf("arm64-v8a") }' not in re.sub(r'defaultConfig\s*\{[\s\S]*?\n    }', '', config), 'no misplaced top-level NDK ABI filter')
cmake=(ROOT/'android/app/src/main/cpp/CMakeLists.txt').read_text(encoding='utf-8')
require('FetchContent_Populate(llama_cpp_upstream)' in cmake and 'add_subdirectory("${llama_cpp_upstream_SOURCE_DIR}" llama-build)' in cmake and cmake.index('set(LLAMA_BUILD_TESTS OFF') < cmake.index('FetchContent_Populate(llama_cpp_upstream)'), 'llama.cpp fetch is explicit and build-size options are set before upstream CMake configuration')
native=(ROOT/'android/app/src/main/cpp/tavern_llama.cpp').read_text(encoding='utf-8')
require('before inference backend is implemented' in native, 'JNI placeholder is explicitly marked as non-inference')
models=(ROOT/'android/app/src/main/java/com/tavern/dnd/Models.kt').read_text(encoding='utf-8')
require('saveSchemaVersion: Int = 6' in models, 'campaign schema default is present')
npc_memory=(ROOT/'android/app/src/main/java/com/tavern/dnd/NpcProfileMemory.kt').read_text(encoding='utf-8')
require('fun recordKnowledge' in npc_memory and 'certainty' in npc_memory and 'source' in npc_memory, 'NPC knowledge stores source and certainty explicitly')
require('knowledgeSearchText(p)' in npc_memory and 'ПРОИСХОЖДЕНИЕ ЗНАНИЙ NPC' in (ROOT/'android/app/src/main/java/com/tavern/dnd/CampaignMemory.kt').read_text(encoding='utf-8'), 'NPC knowledge participates in retrieval and prompt guidance')
extractor=(ROOT/'android/app/src/main/java/com/tavern/dnd/NpcKnowledgeExtractor.kt').read_text(encoding='utf-8')
require('fun extract(' in extractor and 'insideQuotes' in extractor and 'isNegatedOrHypothetical' in extractor, 'explicit NPC-knowledge extraction guards quotes, negation, and hypotheticals')
require('NpcKnowledgeExtractor.extract(user, NpcProfileMemory.knownNames(c))' in (ROOT/'android/app/src/main/java/com/tavern/dnd/CampaignMemory.kt').read_text(encoding='utf-8'), 'automatic knowledge extraction uses player-authored text only')
require('filter { it.third > 0 }' in npc_memory and 'searchableTokens' in npc_memory, 'NPC profile context excludes unrelated zero-score profiles and uses token equality')
require('private fun trimProfiles' in npc_memory and 'updatedTurn' in npc_memory and 'trimProfiles(root, key)' in npc_memory, 'NPC profile cap evicts least-recently-updated profiles while protecting the current profile')
require('normalizeKnowledge(old.optString("fact"))' in npc_memory, 'knowledge deduplication normalizes case, whitespace, and Russian ё/е variants')
relationship=(ROOT/'android/app/src/main/java/com/tavern/dnd/NpcRelationshipEngine.kt').read_text(encoding='utf-8')
require('fun hasNpcMention' in relationship and 'fun resolveProfileKey' in relationship, 'NPC attribution supports inflected names and canonical profile keys')
ui=(ROOT/'android/app/src/main/java/com/tavern/dnd/MainActivity.kt').read_text(encoding='utf-8')
require('"child" to "Детская"' in ui and '"adult" to "Взрослая"' in ui and '"uncensored" to "Полное отсутствие цензуры"' in ui, 'visible content-mode labels match the requested labels')
require((ROOT/'tests/NpcKnowledgeExtractorSmoke.kt').is_file() and (ROOT/'tools/test_npc_knowledge_extractor.sh').is_file(), 'standalone NPC knowledge extractor regression test and runner exist')
require((ROOT/'tests/RelationshipLogicSmoke.kt').is_file() and (ROOT/'tools/test_relationship_logic.sh').is_file(), 'relationship attribution regression test and runner exist')
require('replyExplicitlyVetoes(reply, claim)' in (ROOT/'android/app/src/main/java/com/tavern/dnd/CampaignMemory.kt').read_text(encoding='utf-8'), 'explicit failure responses veto extracted knowledge claims')
memory_source=(ROOT/'android/app/src/main/java/com/tavern/dnd/CampaignMemory.kt').read_text(encoding='utf-8')
require(memory_source.index('if (responseIsError)') < memory_source.index('c.eventLog ='), 'API errors are excluded from campaign chronology and compact memory')
require('playerTextNormalized' in relationship and 'activeCandidate.takeIf' in relationship, 'relationship attribution prioritizes player mentions and limits reply-only fallback to active NPC')
require('NPC_KNOWLEDGE_EXTRACTION_V52_TESTS.md' in (ROOT/'README.md').read_text(encoding='utf-8'), 'v5.2 knowledge-extraction tests are documented in README')
store=(ROOT/'android/app/src/main/java/com/tavern/dnd/CampaignStore.kt').read_text(encoding='utf-8')
require('optInt("saveSchemaVersion", 1)' in store, 'legacy save schema has a fallback')
engine=(ROOT/'android/app/src/main/java/com/tavern/dnd/ActionResolutionEngine.kt').read_text(encoding='utf-8')
require('data class ActionResult' in engine and 'stateChangesAllowed' in engine, 'structured action result and state-change guard exist')
require('ActionResolutionEngine.context' in source, 'online master prompt consumes structured action context')
require('NarrativeTurnDirector.responseRules()' in source and 'NarrativeTurnDirector.analyze' in source, 'online prompt includes deterministic turn contract and narrative response protocol')
require('.put("temperature", 0.62)' in source, 'online generation temperature reduced for better continuity')
custom=(ROOT/'android/app/src/main/java/com/tavern/dnd/CustomRuleEngine.kt').read_text(encoding='utf-8')
require('fun resolveDc' in custom and 'fun promptBlock' in custom and 'fun parseOverrides' in custom, 'custom rules have shared context, DC parser, and executable override parser')
require('CustomRuleEngine.resolveDc' in engine and 'rollMode' in engine, 'action checks apply explicit DC and roll-mode overrides')
require('fun executeCheck' in engine and 'checkWithMode' in (ROOT/'android/app/src/main/java/com/tavern/dnd/Dnd5eRules.kt').read_text(encoding='utf-8'), 'non-combat checks have a real advantage/disadvantage roll path')
require('ActionResolutionEngine.executeCheck' in (ROOT/'android/app/src/main/java/com/tavern/dnd/OfflineEngine.kt').read_text(encoding='utf-8'), 'offline master executes supported non-combat checks')
require('CustomRuleEngine.context(c).promptBlock()' in source, 'online prompt receives unified campaign/race/class rules')
validator=(ROOT/'android/app/src/main/java/com/tavern/dnd/StateValidator.kt').read_text(encoding='utf-8')
require('fun repairNumericInvariants' in validator and 'c.mode =' not in validator, 'numeric repair does not rewrite the selected mode')
wrapper=ROOT/'android/gradlew'
jar=ROOT/'android/gradle/wrapper/gradle-wrapper.jar'
if not wrapper.is_file() or not jar.is_file():
    notes.append('BUILD LIMITATION: Gradle Wrapper script/JAR missing; assembleDebug was not run by this audit.')
# lightweight source hygiene: reject accidental conflict markers
for path in (ROOT/'android/app/src/main/java/com/tavern/dnd').glob('*.kt'):
    text=path.read_text(encoding='utf-8')
    require(not any(x in text for x in ('<<<<<<< ', '=======\n', '>>>>>>> ')), f'no merge-conflict markers: {path.name}')
for n in notes: print(n)
for e in errors: print('FAIL:', e)
print(f'RESULT: {len(errors)} failure(s), {len(notes)} check(s)/note(s)')
sys.exit(1 if errors else 0)
