#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc \
  "$ROOT/tests/support/JsonStubs.kt" \
  "$ROOT/android/app/src/main/java/com/tavern/dnd/Models.kt" \
  "$ROOT/android/app/src/main/java/com/tavern/dnd/NpcRelationshipEngine.kt" \
  "$ROOT/tests/RelationshipLogicSmoke.kt" \
  -include-runtime -d "$TMP/relationship-tests.jar"
java -Dfile.encoding=UTF-8 -jar "$TMP/relationship-tests.jar"
